/* Developer Name : Mayur Patel , Jira Ticket : HWDRSTD-39, Date : 24-11-20 ,Comments : Client Comments 23/11/2020  */
/* Developer Name : Mayur Patel , Jira Ticket : HWDRSTD-39, Date : 25-11-20 ,Comments : Client Comments 23/11/2020  */
/* Developer Name : Mayur Patel , Jira Ticket : HWDRSTD-39, Date : 26-11-20 ,Comments : Client Comments 23/11/2020  */
/* Developer Name : Mayur Patel , Jira Ticket : HWDRSTD-39, Date : 27-11-20 ,Comments : Client Comments 23/11/2020  */
/* Developer Name : Mayur Patel , Jira Ticket : HWDRSTD-41, Date : 03-12-20 ,Comments : Client Comments 01/12/2020  */
/* Developer Name : Mayur Patel , Jira Ticket : HWDRSTD-41,Date : 07-12-20 ,Comments : Client Comments 01-12-20 */

jQuery(window).on('load', function() { // makes sure the whole site is loaded 
    jQuery('#status').fadeOut(); // will first fade out the loading animation 
    jQuery('#preloader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website. 
    jQuery('body').delay(350).css({'overflow':'visible'});
 });
function averageGeolocation(coords) {
    var coords = JSON.parse(coords);
    if (coords.length === 1) {
        return {
            latitude: coords[0].lat,
            longitude: coords[0].lng
        };
    }
    let x = 0.0;
    let y = 0.0;
    let z = 0.0;

    for (let coord of coords) {
        let latitude = coord.lat * Math.PI / 180;
        let longitude = coord.lng * Math.PI / 180;

        x += Math.cos(latitude) * Math.cos(longitude);
        y += Math.cos(latitude) * Math.sin(longitude);
        z += Math.sin(latitude);
    }

    let total = coords.length;

    x = x / total;
    y = y / total;
    z = z / total;

    let centralLongitude = Math.atan2(y, x);
    let centralSquareRoot = Math.sqrt(x * x + y * y);
    let centralLatitude = Math.atan2(z, centralSquareRoot);

    return {
        latitude: centralLatitude * 180 / Math.PI,
        longitude: centralLongitude * 180 / Math.PI
    };
}

jQuery(document).on('click','#share_link_btn',function(){
    ////debugger;
    var send_link=jQuery('#send_link').val();
    window.location.href = 'mailto:?subject=Share URL&body='+encodeURIComponent(send_link);
});

        var facility_total_loc=jQuery('.location_result .desktop_view .table_content  .tr').length;
        jQuery('.location_result .location_count span').html(facility_total_loc);
        var facility_total_fac=jQuery('.facility_result  .desktop_view .table_content  .tr').length;
        jQuery('.facility_result .location_count span').html(facility_total_fac);
                    
                    
function myMap() {
    jQuery('#googleMap').show();
    var lat_longss = JSON.parse(lat_longs);
    if (lat_longss) {
        var avg_lat = averageGeolocation(lat_longs);

        var default_view = {
            lat: avg_lat.latitude,
            lng: avg_lat.longitude
        };

        var map = new google.maps.Map(document.getElementById('googleMap'), {
            zoom: 6,
            center: default_view,
            disableDefaultUI: true,
            styles: [{
                stylers: [{
                    saturation: -100
                }]
            }],
            // disableDefaultUI: true,
            zoomControl: true,
        });

var latlngbounds = new google.maps.LatLngBounds();

        jQuery(lat_longss).each(function(i, v) {
            const contentString =
                '<div id="content">' +
                '<div id="siteNotice">' +
                "</div>" +
                '<h4 id="firstHeading" class="firstHeading">' + v['place'] + '</h4>' +
                '<div id="bodyContent">' +
                "<p></p>" +
                "</div>" +
                "</div>";
            var marker = new google.maps.Marker({
                position: {
                    lat: v['lat'],
                    lng: v['lng']
                },
                map: map,
                title: v['place'],
                icon: new google.maps.MarkerImage(r2_config.home_url+'/wp-content/plugins/find-facilities/images/icon-50px.png',
                    null, null, null, new google.maps.Size(50,50)),
            });
            
            latlngbounds.extend(marker.position);

            const infowindow = new google.maps.InfoWindow({
                content: contentString,
            });

            marker.addListener("mouseover", () => {
                infowindow.open(map, marker);
            });
            marker.addListener("mouseout", () => {
                infowindow.close();
            });
        });
         var bounds = new google.maps.LatLngBounds();
 
        //Center map and adjust Zoom based on the position of all markers.
        map.setCenter(latlngbounds.getCenter());
        map.fitBounds(latlngbounds);

    } else {
        jQuery('#googleMap').hide();
        return false;
    }
}
jQuery(document).on('click','#features_tab',function(){
    //debugger;
    //jQuery('.remove_when_search').removeAttr('id');
   // jQuery('.remove_when_search').attr('id', 'googleMap_facility');
    jQuery('.facility_result_add').hide();
    jQuery('.search_with_list #more_info_alias').hide();
    //debugger;
    jQuery('#search_from_address')[0].reset();
    jQuery('#search_from_address select').trigger('change');
    jQuery('#filter_from_address select').trigger('change');
    
    
    
    
    
     if (jQuery('.facility_result').is(':visible') || jQuery('#more_info_alias').is(':visible')) {
        jQuery('#googleMap_facility').html(' ');
        jQuery('.facility_cnc').html(' ');
        jQuery('.facility_result').hide();
         jQuery('#more_info_alias').hide();
         
         jQuery('#fetures_filter')[0].reset();
         jQuery('#regions').trigger('change');
         jQuery('.search_by_facility').show();
         jQuery('.facility_features_section').show();
         window.history.pushState("object or string", "Title",window.location.origin+window.location.pathname);
         
         var certificate_list='';
        if(localStorage.getItem("certificate") != ''){
        certificate_list=localStorage.getItem("certificate");
        var array = certificate_list.split(",");        
        jQuery.each(array, function(i, val){
           jQuery("input[value='" + val + "']").prop('checked', true);
        });
        }
        
        
        if(localStorage.getItem("workflow") != ''){
        certificate_list=localStorage.getItem("workflow");
        var array = certificate_list.split(",");        
        jQuery.each(array, function(i, val){
           jQuery("input[value='" + val + "']").prop('checked', true);
        });
        }
        
        if(localStorage.getItem("process_require") != ''){
        certificate_list=localStorage.getItem("process_require");
        var array = certificate_list.split(",");        
        jQuery.each(array, function(i, val){
           jQuery("input[value='" + val + "']").prop('checked', true);
        });
        }
        
        if(localStorage.getItem("versions") != ''){
        certificate_list=localStorage.getItem("versions");
        var array = certificate_list.split(",");        
        jQuery.each(array, function(i, val){
           jQuery("input[value='" + val + "']").prop('checked', true);
        });
        }
        
        if(localStorage.getItem("drop_off") != ''){
        certificate_list=localStorage.getItem("drop_off");
        var array = certificate_list.split(",");        
        jQuery.each(array, function(i, val){
           jQuery("input[value='" + val + "']").prop('checked', true);
        });
        }
        
        if(localStorage.getItem("regions") != ''){
        certificate_list=localStorage.getItem("regions");
            jQuery('#regions').val(certificate_list).trigger('change');
            
        }
        
       
        
            // if(localStorage.getItem("country_features") != ''){
            // certificate_list=localStorage.getItem("country_features");
            //     //jQuery('#country_features').val(certificate_list).trigger('change');
                
            //     jQuery('#country_features').val(certificate_list).select2();
            // }
            // if(localStorage.getItem("state_features") != ''){
            // certificate_list=localStorage.getItem("state_features");
            //   // jQuery('#state_features').val(certificate_list).trigger('change');
            //     jQuery('#state_features').val(certificate_list).select2();
            // }
            // if(localStorage.getItem("city_town_features") != ''){
            // certificate_list=localStorage.getItem("city_town_features");
            //   //  jQuery('#city_town_features').val(certificate_list).trigger('change');
            //     jQuery('#city_town_features').val(certificate_list).select2();
            // }
       
        
        if(localStorage.getItem("day_number") != ''){
        certificate_list=localStorage.getItem("day_number");
            jQuery('.day_filter').val(certificate_list);
            
        }
        
        



        
        
        
     }
});

jQuery(document).on('click','#geographic_tab',function(){
          jQuery('.facility_result_add').hide();
          jQuery('.display_facilites').hide();
          jQuery('.search_with_list #more_info_alias').hide();
          
    jQuery('#reset_fetures').trigger('click');
    
    jQuery('.location_navigation').html('');
    
    
    
     if (jQuery('.location_result').is(':visible') || jQuery('#more_info_detail').is(':visible')) {
        jQuery('#search_from_address')[0].reset();
        jQuery('#country').trigger('change');
        jQuery('#measurements').trigger('change');
        jQuery('#measurements_value').trigger('change');
        jQuery('#filter_from_address')[0].reset();
        jQuery('#region').trigger('change');
        jQuery('#location_details').show();
        jQuery('.location_result').hide();
        jQuery('#more_info_detail').hide();
        jQuery('.googleMap').html(' ');
        jQuery('.locations_content').html(' ');
        jQuery('.more_info_result').html(' ');
        jQuery('.facility_result_add').hide();
        jQuery('.search_with_list #more_info_alias').hide();
        jQuery('.display_facilites').hide();
        
        window.history.pushState("object or string", "Title",window.location.origin+window.location.pathname);
     }
});

// jQuery(document).on('click','#share_link_btn',function(){
//     //debugger;
//     var send_link=jQuery('#send_link').val();
//     window.location.href = 'mailto:address@dmail.com?subject=Share URL&body='+send_link;
// });
jQuery(document).on('click','.link_to_fetures,.link_to_search,.link_search_list',function(){
    var link=jQuery(this).data('url');
    jQuery('#send_link').val(encodeURI(link));
    jQuery('#link_sharing_modal').show();
});
jQuery(document).on('click','.share_close',function(){
    jQuery('#link_sharing_modal').hide();
    jQuery('#send_link').val('');
});
jQuery(document).keypress(function(e) { 
    if (e.keyCode === 27) { 
        jQuery("#link_sharing_modal").fadeOut(500);
        //or
        window.close();
    } 
});
function copyText() {
  var copyText = document.getElementById("send_link");
  copyText.select();
  copyText.setSelectionRange(0, 99999)
  document.execCommand("copy");
}
function facilityMap() {
    jQuery('#googleMap_facility').show();
    var lat_longss = JSON.parse(f_lat_longs);
    if (lat_longss) {
        var avg_lat = averageGeolocation(f_lat_longs);

        var default_view = {
            lat: avg_lat.latitude,
            lng: avg_lat.longitude
        };

        var map = new google.maps.Map(document.getElementById('googleMap_facility'), {
            zoom: 5,
            center: default_view,
            disableDefaultUI: true,
            styles: [{
                stylers: [{
                    saturation: -100
                }]
            }],
            // disableDefaultUI: true,
            zoomControl: true,
        });
         var latlngbounds = new google.maps.LatLngBounds();
        jQuery(lat_longss).each(function(i, v) {

            var university_of_waterloo = new google.maps.Marker({
                position: {
                    lat: v['lat'],
                    lng: v['lng']
                },
                map: map,
                title: v['place'],
                icon: new google.maps.MarkerImage(r2_config.home_url+'/wp-content/plugins/find-facilities/images/icon-50px.png',
                    null, null, null, new google.maps.Size(50,50)),
            });
            
            latlngbounds.extend(university_of_waterloo.position);

            const infowindow = new google.maps.InfoWindow({
                content: v['place'],
            });

        });
         var bounds = new google.maps.LatLngBounds();
 
        //Center map and adjust Zoom based on the position of all markers.
      map.setCenter(latlngbounds.getCenter());
    map.fitBounds(latlngbounds);
    } else {
        jQuery('#googleMap_facility').hide();
        return false;
    }
}

function facilityMap_add() {
    jQuery('#googleMap_facility_add').show();
    var lat_longss = JSON.parse(f_lat_longs);
    if (lat_longss) {
        var avg_lat = averageGeolocation(f_lat_longs);

        var default_view = {
            lat: avg_lat.latitude,
            lng: avg_lat.longitude
        };

        var map = new google.maps.Map(document.getElementById('googleMap_facility_add'), {
            zoom: 5,
            center: default_view,
            disableDefaultUI: true,
            styles: [{
                stylers: [{
                    saturation: -100
                }]
            }],
            // disableDefaultUI: true,
            zoomControl: true,
        });
         var latlngbounds = new google.maps.LatLngBounds();
        jQuery(lat_longss).each(function(i, v) {

            var university_of_waterloo = new google.maps.Marker({
                position: {
                    lat: v['lat'],
                    lng: v['lng']
                },
                map: map,
                title: v['place'],
                icon: new google.maps.MarkerImage(r2_config.home_url+'/wp-content/plugins/find-facilities/images/icon-50px.png',
                    null, null, null, new google.maps.Size(50,50)),
            });
            
            latlngbounds.extend(university_of_waterloo.position);

            const infowindow = new google.maps.InfoWindow({
                content: v['place'],
            });

        });
         var bounds = new google.maps.LatLngBounds();
 
        //Center map and adjust Zoom based on the position of all markers.
        map.setCenter(latlngbounds.getCenter());
        map.fitBounds(latlngbounds);
    } else {
        jQuery('#googleMap_facility_add').hide();
        return false;
    }
}


jQuery(document).ready(function() {

jQuery('input:checkbox[name="version"]').change(function(){
    //debugger;
    var r2_vr = [];
    jQuery("input:checkbox[name='version']:checked").each(function() { 
                r2_vr.push(jQuery(this).val()); 
    });
    var l = jQuery(this).val();
    if(l == 'All' && r2_vr.includes('All')){
        jQuery("input:checkbox[name='version']").prop( 
                      "checked",true)
    }
    else if(r2_vr.includes('R2:2013') && r2_vr.includes('R2v3') && l != 'All'){
        jQuery("input:checkbox[name='version']").prop( 
                      "checked",true);
        r2_vr = [];
    }
    else if(r2_vr.length > 0 && l != 'All'){
        jQuery("input:checkbox[name='version']").prop( 
                      "checked",false);
        jQuery(this).prop( 
                      "checked",true);
        r2_vr = [];
    }
    else{
        jQuery("input:checkbox[name='version']").prop( 
                      "checked",false);
    }
});
    
var urlParams = new URLSearchParams(window.location.search);
var appids = urlParams.get('appids');
if (appids) {
    // jQuery('.location_result').css('display', 'none');
    // jQuery('#location_details').css('display', 'none');
    // jQuery('#more_info_detail').css('display', 'block');
    if(urlParams.get('tab')==11 || urlParams.get('tab')==12 || urlParams.get('tab')==13 ){
        more_info_listing();
    }
    if(urlParams.get('tab')==2){
        more_info_facility();
    }
    if(urlParams.get('tab')==3){
        more_info_facility_add();
    }
    
}
else if(urlParams.get('type')=='location'){
    var position = {"coords":{"latitude":urlParams.get('latitude'),"longitude":urlParams.get('longitude')},"area":urlParams.get('area'),"areain":urlParams.get('areain')};
    showPosition(position);
}
 else if(urlParams.get('type')=='byaddress'){
    search_by_address();
 }
 else if(urlParams.get('type')=='byarea'){
     filter_by_area();
 }
 else if(urlParams.get('type')=='byalias'){
     //debugger;
     filter_by_alias();
 }
 else if(urlParams.get('type')=='bydetails'){
     filter_by_details();
 }
else {
    jQuery('.location_result').css('display', 'none');
    jQuery('#location_details').css('display', 'block');
    jQuery('#more_info_detail').css('display', 'none');
}
    jQuery("#measurements").select2();
    jQuery('#measurements_value').select2();
    jQuery('#country').select2({
        placeholder: "Country",
        showSearchBox: true,
        allowClear: true,
        
    });
jQuery(document).on('change','#city',function(){
    if(jQuery('#city').val()){
        jQuery('#city').removeClass('error_select');
    }
});

jQuery(document).on('change','#postalcode',function(){
    if(jQuery('#postalcode').val()){
        jQuery('#postalcode').removeClass('error_select');
    }
});

function filter_by_alias(){
    //debugger;
    var urlParameters = new URLSearchParams(window.location.search);
    if (urlParameters.get('alias')) {
       jQuery('.nav-tabs .facility_tab a[href="#3"]').tab('show');
            jQuery('.r2_loader').show();
            
            var formdata = new FormData();
            var current_tab=jQuery('.facility_tab.active').attr('id');
            formdata.append('current_tab', current_tab);
            formdata.append('by_name_alias', urlParameters.get('alias'));
            formdata.append('action', 'filter_by_facility');
            jQuery('.link_to_fetures').attr('data-url',window.location.origin+window.location.pathname+'?type=byalias&alias='+urlParameters.get('alias'));
            window.history.pushState("object or string", "Title",window.location.origin+window.location.pathname+'?type=byalias&alias='+urlParameters.get('alias'));
            jQuery.ajax({
                type: "POST",
                url: r2_config.ajax_url,
                data: formdata,
                cache: false,
                contentType: false,
                processData: false,
                success: function(data) {
                    //debugger;
                    jQuery('.r2_loader').hide();
                    jQuery('.search_by_facility').hide();
                    //jQuery('.facility_features_section').hide();
                    jQuery('.display_facilites').hide();
                    jQuery('.facility_result_add').show();
                    jQuery('.facility_result_add .facility_cnc').html(data);
                    
                    facilityMap_add();
                    jQuery(".table_content").mCustomScrollbar({
                        theme: "minimal"
                    });
                    
                    var facility_total_loc=jQuery('.location_result .desktop_view .table_content  .tr').length;
                    jQuery('.location_result .location_count span').html(facility_total_loc);
                    
                    var facility_total_fac=jQuery('.facility_result_add  .desktop_view .table_content  .tr').length;
                    jQuery('.facility_result_add .location_count span').html(facility_total_fac);
                    
                    
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    jQuery('.r2_loader').hide();
                    console.log(jqXHR + " :: " + textStatus + " :: " + errorThrown);
                }
            });
            return false;
        }
}

function filter_by_details(){
    var urlParameters = new URLSearchParams(window.location.search);
      jQuery('.nav-tabs .facility_tab a[href="#2"]').tab('show');
      jQuery('.r2_loader').show();
        var formdata = new FormData();
         formdata.append('action', 'filter_by_facility');
         formdata.append('certificate', urlParameters.get('certificate'));
         formdata.append('workflow', urlParameters.get('workflow'));
         formdata.append('process_require', urlParameters.get('process_require'));
         formdata.append('versions', urlParameters.get('versions'));
         formdata.append('regions', urlParameters.get('regions'));
         formdata.append('country_features', urlParameters.get('country_features'));
         formdata.append('state_features', urlParameters.get('state_features'));
          formdata.append('city_town_features', urlParameters.get('city_town_features'));
           formdata.append('drop_off', urlParameters.get('drop_off'));
           formdata.append('day_number', urlParameters.get('days'));
         
           jQuery('.link_to_fetures').attr('data-url',window.location.origin+window.location.pathname+
          '?type=bydetails&certificate='+urlParameters.get('certificate')+'&workflow='+urlParameters.get('workflow')+'&process_require='
          + urlParameters.get('process_require')+'&versions='+urlParameters.get('versions')+'&regions='+urlParameters.get('regions')+'&country_features='+urlParameters.get('country_features')
          +'&state_features='+urlParameters.get('state_features')+'&city_town_features='+urlParameters.get('city_town_features')+'&drop_off='+urlParameters.get('drop_off')+'&days='+urlParameters.get('days'));
          
          window.history.pushState("object or string", "Title",window.location.origin+window.location.pathname+
          '?type=bydetails&certificate='+urlParameters.get('certificate')+'&workflow='+urlParameters.get('workflow')+'&process_require='
          + urlParameters.get('process_require')+'&versions='+urlParameters.get('versions')+'&regions='+urlParameters.get('regions')+'&country_features='+urlParameters.get('country_features')
          +'&state_features='+urlParameters.get('state_features')+'&city_town_features='+urlParameters.get('city_town_features')+'&drop_off='+urlParameters.get('drop_off')+'&days='+urlParameters.get('days'));
          
          jQuery.ajax({
            type: "POST",
            url: r2_config.ajax_url,
            data: formdata,
            cache: false,
            contentType: false,
            processData: false,
            success: function(data) {
                jQuery('.r2_loader').hide();
                //jQuery('.search_by_facility').hide();
                jQuery('.facility_features_section').hide();
                jQuery('.facility_result').show();
                jQuery('.facility_cnc').html(data);
                
                facilityMap();
                jQuery(".table_content").mCustomScrollbar({
                    theme: "minimal"
                });
              var facility_total_loc=jQuery('.location_result .desktop_view .table_content  .tr').length;
                    jQuery('.location_result .location_count span').html(facility_total_loc);
                    
                    var facility_total_fac=jQuery('.facility_result  .desktop_view .table_content  .tr').length;
                    jQuery('.facility_result .location_count span').html(facility_total_fac);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                jQuery('.r2_loader').hide();
                console.log(jqXHR + " :: " + textStatus + " :: " + errorThrown);
            }
        });
        return false;
}

    jQuery(document).on('click', '#search_alias', function() {
        if (jQuery('#by_name_alias').val()) {
    //debugger;
            jQuery('.r2_loader').show();
            var form = jQuery("#saerch_by_f_name")[0];
            var formdata = new FormData(form);
            var dis = 50;
            var type = 'M';
            var current_tab=jQuery('.facility_tab.active').attr('id');
            formdata.append('current_tab', current_tab);
            formdata.append('action', 'filter_by_facility');
            
            
            
            jQuery('.link_to_fetures').attr('data-url',window.location.origin+window.location.pathname+'?type=byalias&alias='+jQuery('#by_name_alias').val());
            window.history.pushState("object or string", "Title",window.location.origin+window.location.pathname+'?type=byalias&alias='+jQuery('#by_name_alias').val());
            jQuery.ajax({
                type: "POST",
                url: r2_config.ajax_url,
                data: formdata,
                cache: false,
                contentType: false,
                processData: false,
                success: function(data) {
                    //debugger;
                    jQuery('.r2_loader').hide();
                    //jQuery('.search_by_facility').hide();
                    //jQuery('.facility_features_section').hide();
                    jQuery('.display_facilites').hide();
                    jQuery('.facility_result_add').show();
                    jQuery('.facility_result_add .facility_cnc').html(data);
                    
                    facilityMap_add();
                    jQuery(".table_content").mCustomScrollbar({
                        theme: "minimal"
                    });
                  var facility_total_loc=jQuery('.location_result .desktop_view .table_content  .tr').length;
                    jQuery('.location_result .location_count span').html(facility_total_loc);
                    
                    var facility_total_fac=jQuery('.facility_result_add  .desktop_view .table_content  .tr').length;
                    jQuery('.facility_result_add .location_count span').html(facility_total_fac);
                    jQuery('#saerch_by_f_name')[0].reset();
                    
                    //jQuery('.nav-tabs .facility_tab a[href="#2"]').tab('show');
                    
                    
                    
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    jQuery('.r2_loader').hide();
                    console.log(jqXHR + " :: " + textStatus + " :: " + errorThrown);
                }
            });
            return false;
        } else {
            return false;
        }
    });

    jQuery(document).on('click', '#more_features', function() {
        //debugger;
        jQuery('.error_filter').remove();
        if(jQuery('.day_filter').val() == '' && jQuery('.workflow:checkbox:checked').length == 0 
        && jQuery('.certifications:checkbox:checked').length == 0
        && jQuery('.process_requirements:checkbox:checked').length == 0
        && jQuery('.f_version:checkbox:checked').length == 0 && jQuery('.f_dropoff:radio:checked').length==0){
             if(jQuery('#regions').val()=="" && jQuery('#country_features').val()=="" && jQuery('#state_features').val()=="" && jQuery('#city_town_features').val()==""){
                 jQuery('#fetures_filter').after('<span class="error_filter">Select atleast one filter value.</span>');
                return false;
            }
        }
        jQuery('.r2_loader').show();
        var form = jQuery("#fetures_filter")[0];
        var formdata = new FormData(form);
        var l = [];
            jQuery("input:checkbox[name='certificate_status']:checked").each(function() { 
                l.push(jQuery(this).val()); 
            });
            var certificate = l.join(',');
         formdata.append('certificate', certificate);
         localStorage.setItem("certificate", certificate); 
         
         
         
         
         
         
        var bw = [];
            jQuery("input:checkbox[name='business_workflow']:checked").each(function() { 
                bw.push(jQuery(this).val()); 
            });
        var business_workflow = bw.join(',');
        formdata.append('workflow', business_workflow);
        localStorage.setItem("workflow", business_workflow);
        
        var r2_pr = [];
        jQuery("input:checkbox[name='process_req']:checked").each(function() {
                r2_pr.push(jQuery(this).val()); 
            });
        var process_require = r2_pr.join(',');
        formdata.append('process_require', process_require);
        localStorage.setItem("process_require", process_require);
        // Change Request Process 
        
                var r2_pr = [];
        jQuery("input:checkbox[name='process_req']:checked").each(function() {
                r2_pr.push(jQuery(this).attr('data-app')); 
            });
        var process_app = r2_pr.join(',');
        formdata.append('process_app', process_app);
        
        
        
        
        var r2_vr = [];
        jQuery("input:checkbox[name='version']:checked").each(function() { 
                r2_vr.push(jQuery(this).val()); 
            });
        var r2_version = r2_vr.join(',');
        formdata.append('versions', r2_version);
        
        localStorage.setItem("versions", r2_version);
        
        
        
      
        var d_off=jQuery("input:radio[name='drop_off']:checked").val();
         
        
        
          localStorage.setItem("drop_off", d_off);
       
        
        if(!jQuery('#regions').val()){
           localStorage.setItem("regions",'');
        }else{
            localStorage.setItem("regions", jQuery('#regions').val());
        }
        
        
        if(!jQuery('#country_features').val()){
           localStorage.setItem("country_features","");
        }else{
            localStorage.setItem("country_features", jQuery('#country_features').val());
        }
        
         if(!jQuery('#state_features').val()){
           localStorage.setItem("state_features","");
        }else{
            localStorage.setItem("state_features", jQuery('#state_features').val());
        }
        
        
         if(!jQuery('#city_town_features').val()){
           localStorage.setItem("city_town_features","");
        }else{
            localStorage.setItem("city_town_features", jQuery('#city_town_features').val());
        }
         
        //  localStorage.setItem("regions", jQuery('#regions').val());
        //  localStorage.setItem("country_features", jQuery('#country_features').val());
        //  localStorage.setItem("state_features", jQuery('#state_features').val());
        //  localStorage.setItem("city_town_features", jQuery('#city_town_features').val());
       
        var day_number=jQuery('.day_filter').val();
        formdata.append('day_number', day_number);
        localStorage.setItem("day_number", day_number);
        
        formdata.append('action', 'filter_by_facility');
        
          jQuery('.link_to_fetures').attr('data-url',window.location.origin+window.location.pathname+
          '?type=bydetails&certificate='+certificate+'&workflow='+business_workflow+'&process_require='
          +process_require+'&versions='+r2_version+'&regions='+jQuery('#regions').val()+'&country_features='+jQuery('#country_features').val()
          +'&state_features='+jQuery('#state_features').val()+'&city_town_features='+jQuery('#city_town_features').val()+'&drop_off='+d_off+'&days='+day_number);
          
            window.history.pushState("object or string", "Title",window.location.origin+window.location.pathname+
          '?type=bydetails&certificate='+certificate+'&workflow='+business_workflow+'&process_require='
          +process_require+'&versions='+r2_version+'&regions='+jQuery('#regions').val()+'&country_features='+jQuery('#country_features').val()
          +'&state_features='+jQuery('#state_features').val()+'&city_town_features='+jQuery('#city_town_features').val()+'&drop_off='+d_off+'&days='+day_number);
          
        jQuery.ajax({
            type: "POST",
            url: r2_config.ajax_url,
            data: formdata,
            cache: false,
            contentType: false,
            processData: false,
            success: function(data) {
                jQuery('.r2_loader').hide();
                //jQuery('.search_by_facility').hide();
                jQuery('.facility_features_section').hide();
                jQuery('.facility_result').show();
                
                var certificate_list='';
                if(localStorage.getItem("certificate") != ''){
                    certificate_list+='<div><h4>Certificate Status</h4><span>'+localStorage.getItem("certificate")+'</span></div>';
                }
                
                if(localStorage.getItem("workflow") != ''){
                    certificate_list+='<div><h4>Business Workflow</h4><span>'+localStorage.getItem("workflow")+'</span></div>';
                }
                
                if(localStorage.getItem("process_require") != ''){
                    certificate_list+='<div><h4>R2 Process Requirements</h4><span>'+localStorage.getItem("process_require")+'</span></div>';
                }
                
                if(localStorage.getItem("versions") != ''){
                    certificate_list+='<div><h4>R2 Version</h4><span>'+localStorage.getItem("versions")+'</span></div>';
                }
                
                if(localStorage.getItem("drop_off") != 'undefined'){
                    certificate_list+='<div><h4>Drop off</h4><span>'+localStorage.getItem("drop_off")+'</span></div>';
                }
                
                if(localStorage.getItem("regions") != ''){
                    certificate_list+='<div><h4>Region</h4><span>'+localStorage.getItem("regions")+'</span></div>';
                }
                
                if(localStorage.getItem("country_features") != '' ){
                    certificate_list+='<div><h4>Country</h4><span>'+localStorage.getItem("country_features")+'</span></div>';
                }
                
                if(localStorage.getItem("state_features") != ''){
                    certificate_list+='<div><h4>State/Province</h4><span>'+localStorage.getItem("state_features")+'</span></div>';
                }
                
                if(localStorage.getItem("city_town_features") != ''){
                    certificate_list+='<div><h4>City/Town</h4><span>'+localStorage.getItem("city_town_features")+'</span></div>';
                }
                
                if(localStorage.getItem("day_number") != ''){
                    certificate_list+='<div><h4>Days</h4><span>'+localStorage.getItem("day_number")+'</span></div>';
                }
                
                
                
                certificate_list+='<div class="featured_btn"><a id="features_tab" href="javascript:void(0)">Modify</a></div>';
                



                
                
                jQuery('.location_navigation').html(certificate_list);
                
                
                
                
                jQuery('.facility_cnc').html(data);
                
                facilityMap();
                jQuery(".table_content").mCustomScrollbar({
                    theme: "minimal"
                });
         var facility_total_loc=jQuery('.location_result .desktop_view .table_content  .tr').length;
                    jQuery('.location_result .location_count span').html(facility_total_loc);
                    
                    var facility_total_fac=jQuery('.facility_result  .desktop_view .table_content  .tr').length;
                    jQuery('.facility_result .location_count span').html(facility_total_fac);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                jQuery('.r2_loader').hide();
                console.log(jqXHR + " :: " + textStatus + " :: " + errorThrown);
            }
        });
        return false;

    });
     jQuery(document).on('change', '#region', function() {
       // if (jQuery('#region').val()) {
            var fd = new FormData();
            jQuery('.r2_loader').show();
            fd.append("action", 'get_country');
            fd.append('country', jQuery('#region').val());
            jQuery.ajax({
                type: 'POST',
                url: r2_config.ajax_url,
                data: fd,
                cache: false,
                contentType: false,
                processData: false,
                success: function(res) {
                    jQuery('.r2_loader').hide();
                    jQuery("#country_name").html('');
                    jQuery("#state_province").html('');
                    jQuery("#city_town").html('');
                    jQuery("#country_name").html(res);
                    jQuery('#country_name').select2({
                        placeholder: "Country",
                        allowClear: true
                    });
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    jQuery('.r2_loader').hide();
                    console.log('something went wrong. ', textStatus, errorThrown);
                }
            });
       // }
        
    });
    jQuery(document).on('change', '#regions', function() {
      //  if (jQuery('#regions').val()) {
            var fd = new FormData();
            jQuery('.r2_loader').show();
            fd.append("action", 'get_country');
            fd.append('country', jQuery('#regions').val());
            jQuery.ajax({
                type: 'POST',
                url: r2_config.ajax_url,
                data: fd,
                cache: false,
                contentType: false,
                processData: false,
                success: function(res) {
                    jQuery('.r2_loader').hide();
                    jQuery("#country_features").html('');
                    jQuery("#state_features").html('');
                    jQuery("#city_town_features").html('');
                    jQuery("#country_features").html(res);
                    jQuery('#country_features').select2({
                        placeholder: "Country",
                        allowClear: true
                    });
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    jQuery('.r2_loader').hide();
                    console.log('something went wrong. ', textStatus, errorThrown);
                }
            });
       // }
    });


    jQuery(document).on('change', '#country_features', function() {
        if (jQuery('#country_features').val()) {
            var fd = new FormData();
            jQuery('.r2_loader').show();
            fd.append("action", 'getState');
            fd.append('country', jQuery('#country_features').val());
            jQuery.ajax({
                type: 'POST',
                url: r2_config.ajax_url,
                data: fd,
                cache: false,
                contentType: false,
                processData: false,
                success: function(res) {
                    jQuery('.r2_loader').hide();
                    jQuery("#state_features").html('');
                    jQuery("#city_town_features").html('')
                    jQuery("#state_features").html(res);
                    jQuery('#state_features').select2({
                        placeholder: "State/Province",
                        allowClear: true
                    });
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    jQuery('.r2_loader').hide();
                    console.log('something went wrong. ', textStatus, errorThrown);
                }
            });
        }
    });


    jQuery(document).on('change', '#state_province', function() {
        if (jQuery('#state_province').val()) {
            var fd = new FormData();
            jQuery('.r2_loader').show();
            fd.append("action", 'getCityTown');
            fd.append('country', jQuery('#state_province').val());
            jQuery.ajax({
                type: 'POST',
                url: r2_config.ajax_url,
                data: fd,
                cache: false,
                contentType: false,
                processData: false,
                success: function(res) {
                    jQuery('.r2_loader').hide();
                    jQuery("#city_town").html('')
                    jQuery("#city_town").html(res);
                    jQuery('#city_town').select2({
                        placeholder: "City/Town",
                        allowClear: true
                    });
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    jQuery('.r2_loader').hide();
                    console.log('something went wrong. ', textStatus, errorThrown);
                }
            });
        }
    });

    jQuery(document).on('change', '#country_name', function() {
        if (jQuery('#country_name').val()) {
            jQuery('#select2-country_name-container').removeClass('error_select');
            var fd = new FormData();
            jQuery('.r2_loader').show();
            fd.append("action", 'getState');
            fd.append('country', jQuery('#country_name').val());
            jQuery.ajax({
                type: 'POST',
                url: r2_config.ajax_url,
                data: fd,
                cache: false,
                contentType: false,
                processData: false,
                success: function(res) {
                    jQuery('.r2_loader').hide();

                    jQuery("#state_province").html('');
                    jQuery("#city_town").html('');
                    jQuery("#state_province").html(res);
                    jQuery('#state_province').select2({
                        placeholder: "State/Province",
                        allowClear: true
                    });
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    jQuery('.r2_loader').hide();
                    console.log('something went wrong. ', textStatus, errorThrown);
                }
            });
        }
    });

    jQuery('#reset_fetures').click(function() {
        jQuery('#fetures_filter')[0].reset();
        jQuery("#country_features").val([]).trigger('change');
        jQuery("#state_features").val([]).trigger('change');
        jQuery("#city_town_features").val([]).trigger('change');
        jQuery("#regions").val([]).trigger('change');
    });

// Add reset search on Geographic search screen
  jQuery('#reset_geosearch_select').click(function() {
        jQuery("#filter_from_address select").val([]).trigger('change');
    });

  jQuery('#reset_geosearch_form').click(function() {
     jQuery('#search_from_address')[0].reset();       
        jQuery("#search_from_address select").val([]).trigger('change');
    });

 

    jQuery(document).on('change', '#state_features', function() {
        if (jQuery('#state_features').val()) {
            var fd = new FormData();
            jQuery('.r2_loader').show();
            fd.append("action", 'getCityTown');
            fd.append('country', jQuery('#state_features').val());
            jQuery.ajax({
                type: 'POST',
                url: r2_config.ajax_url,
                data: fd,
                cache: false,
                contentType: false,
                processData: false,
                success: function(res) {
                    jQuery('.r2_loader').hide();
                    jQuery("#city_town_features").html('')
                    jQuery("#city_town_features").html(res);
                    jQuery('#city_town_features').select2({
                        placeholder: "City/Town",
                        allowClear: true
                    });
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    jQuery('.r2_loader').hide();
                    console.log('something went wrong. ', textStatus, errorThrown);
                }
            });
        }
    });


    jQuery(document).on('change', '#country', function() {
        
        jQuery('#select2-country-container').removeClass('error_select');
        var fd = new FormData();
        jQuery('.r2_loader').show();
        fd.append("action", 'get_states');
        fd.append('country', jQuery('#country').val());
        jQuery.ajax({
            type: 'POST',
            url: r2_config.ajax_url,
            data: fd,
            cache: false,
            contentType: false,
            processData: false,
            success: function(res) {
                jQuery('.r2_loader').hide();
                jQuery("#state").html(res);
                jQuery('#state').select2({
                    placeholder: "State/Province",
                    allowClear: true
                });
            },
            error: function(jqXHR, textStatus, errorThrown) {
                jQuery('.r2_loader').hide();
                console.log('something went wrong. ', textStatus, errorThrown);
            }
        });
    });
    jQuery(document).on('change', '#state', function() {
        jQuery('#select2-state-container').removeClass('error_select');
    });
    jQuery('#state').select2({
        placeholder: "State/Province",
        allowClear: true,
       language: {
          noResults: function() {
            return 'Select Country';
          },
        },
    });
    jQuery("#region").select2({
        placeholder: "Region",
        allowClear: true
    });
    jQuery("#regions").select2({
        placeholder: "Region",
        allowClear: true
    });

    jQuery("#country_features").select2({
        placeholder: "Country",
        allowClear: true
    });

    jQuery("#state_features").select2({
        placeholder: "State/Province",
        allowClear: true,
           language: {
      noResults: function() {
        return 'Select Country';
      },
    },
    });

    jQuery("#city_town_features").select2({
        placeholder: "City/Town",
        allowClear: true,
             language: {
      noResults: function() {
        return 'Select State/Province';
      },
    },
    });


    jQuery("#country_name").select2({
        placeholder: "Country",
        allowClear: true
    });
    jQuery("#state_province").select2({
        placeholder: "State/Province",
        allowClear: true,
        language: {
      noResults: function() {
        return 'Select Country';
      },
    },
    });
    jQuery("#city_town").select2({
        placeholder: "City/Town",
        allowClear: true,
            language: {
      noResults: function() {
        return 'Select State/Province';
      },
    },
    });

    jQuery(document).on('click', '.use_current_loc', function() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(showPosition);
        }
    });

    // jQuery(document).on('click', '.back_to_search_result', function() {
    //     //debugger;
    //     if (navigator.geolocation) {
    //         navigator.geolocation.getCurrentPosition(showPosition);
    //     }
    //     jQuery('#more_info_detail').css('display', 'none');
    //     //jQuery('.location_result').css('display','block');
    // });




    jQuery('.for_filter').on('change', function(e) {
        //debugger;
        var tag = jQuery('.search_tag').text();
        if (jQuery('#filter_on').val() == 1 && tag == "Search By Location") {
            jQuery('#searchbyloc').trigger('click');
        }
        if (jQuery('#filter_on').val() == 1 && tag == "Use Current Location") {
            jQuery('.use_current_loc').trigger('click');
        }
        if (jQuery('#filter_on').val() == 1 && tag == "Search By Area") {
            jQuery('#filterby').trigger('click');
        }

    });

    function isMyScriptLoaded(url) {
        var url = "https://maps.googleapis.com/maps/api/js?key=AIzaSyAI0jKzxLynvP9-KQEsTevGARQpfY5CyNs&callback=myMap";
        var scripts = document.getElementsByTagName('script');
        for (var i = scripts.length; i--;) {
            if (scripts[i].src == url) return true;
        }
        return false;
    }
   function printel(elem) {
    var divToPrint = elem;
    var popupWin = window.open('', '_blank', 'width=800,height=600');
    var css_link=jQuery('#front_css').val();
    popupWin.document.open();
    popupWin.document.write('<html><head><title></title>');
    popupWin.document.write('<link rel="stylesheet" href="'+css_link+'" type="text/css" />');
    popupWin.document.write('</head>');
    popupWin.document.write('<body onload="window.print()">');
    popupWin.document.write(divToPrint);
    popupWin.document.write('</body></html>');
       setTimeout(function () {
    popupWin.document.close();
    popupWin.focus();
    popupWin.print();
    //popupWin.close(); 
}, 1000);
}
jQuery('.print_fetures').click(function(){
    if (jQuery('.facility_cnc .desktop_view').is(':visible')) {
            var tab = 'desktop_view';
        } else {
            var tab = 'mobile_view';
        }
        var list_of_ids = jQuery('.facility_cnc .' + tab + ' .tr.active').map(function() { return jQuery(this).find('.more_info_click').attr('data-appid'); }).get().join(',');

        if (list_of_ids == '') {
            jQuery('.fetures_error').html('<span style="color:red">Please Select Location.</span>');
            setTimeout(function() {
                jQuery('.fetures_error').html('')
            }, 3000);
            return false;
        }
        
         if (jQuery('.facility_cnc .desktop_view').is(':visible')) {
            var obj = [];
            var i = 0;
            jQuery('.desktop_view .tr.active').each(function(){
                var c_name = jQuery(this).children(':nth-child(2)').text();
                    c_add = jQuery(this).children(':nth-child(3)').text();
                    c_cert = jQuery(this).children(':nth-child(4)').text();
                obj.push({
                    company_name: c_name, 
                    company_address: c_add,
	                company_cert: c_cert, 
                   
                });
            })
     } 
     else{
         var obj = [];
         var i = 0;
         jQuery('.mobile_view .tr.active').each(function(){
            var c_name = jQuery(this).find('.c_name').text();
                c_add = jQuery(this).find('.address').text();
                c_cert = jQuery(this).find('.status').text();
               
             obj.push({
                company_name: c_name, 
                company_address: c_add,
	            company_cert: c_cert, 
              });
          });
     }
    
    var table = jQuery('.print_on_map').html()+'<table border="1px"><tr><th>Company Name</th><th>Company Address</th><th>Company Certi</th></tr>';
    obj.forEach(function(el){
       var elem = '<tr><td>'+ el['company_name'] +'</td><td>'+ el['company_address'] +'</td><td>'+ el['company_cert'] +'</td></tr>';
        table = table + elem;
    });
     
    printel(table);
        
});
jQuery('.print_table').click(function(){
        if (jQuery('.locations_content .desktop_view').is(':visible')) {
            var tab = 'desktop_view';
        } else {
            var tab = 'mobile_view';
        }
        var list_of_ids = jQuery('.locations_content .' + tab + ' .tr.active').map(function() { return jQuery(this).find('.more_info_click').attr('data-appid'); }).get().join(',');

        if (list_of_ids == '') {
            jQuery('.location_error').html('<span style="color:red">Please Select Location Result.</span>');
            setTimeout(function() {
                jQuery('.location_error').html('')
            }, 3000);
            return false;
        }
    if (jQuery('.locations_content .desktop_view').is(':visible')) {
            var obj = [];
            var i = 0;
            jQuery('.desktop_view .tr.active').each(function(){
                var c_name = jQuery(this).children(':nth-child(2)').text();
                    c_add = jQuery(this).children(':nth-child(3)').text();
                    c_cert = jQuery(this).children(':nth-child(4)').text();
                    c_dist = jQuery(this).children(':nth-child(5)').text();
                obj.push({
                    company_name: c_name, 
                    company_address: c_add,
	                company_cert: c_cert, 
                    company_dist: c_dist
                });
            })
     } 
     else{
         var obj = [];
         var i = 0;
         jQuery('.mobile_view .tr.active').each(function(){
            var c_name = jQuery(this).find('.c_name').text();
                c_add = jQuery(this).find('.address').text();
                c_cert = jQuery(this).find('.status').text();
                c_dist = jQuery(this).find('.distance').text();
             obj.push({
                company_name: c_name, 
                company_address: c_add,
	            company_cert: c_cert, 
                company_dist: c_dist
              });
          });
     }
     if(jQuery('.search_tag').text()=='Search By Area'){
    var table = jQuery('.print_on_map').html()+'<table border="1px"><tr><th>Company Name</th><th>Company Address</th><th>Company Certi</th></tr>';
    obj.forEach(function(el){
       var elem = '<tr><td>'+ el['company_name'] +'</td><td>'+ el['company_address'] +'</td><td>'+ el['company_cert'] +'</td></tr>';
        table = table + elem;
    });
     }
     else{
          var table = jQuery('.print_on_map').html()+'<table border="1px"><tr><th>Company Name</th><th>Company Address</th><th>Company Certi</th><th>Company Distance</th></tr>';
    obj.forEach(function(el){
       var elem = '<tr><td>'+ el['company_name'] +'</td><td>'+ el['company_address'] +'</td><td>'+ el['company_cert'] +'</td><td>'+ el['company_dist']+'</td></tr>';
        table = table + elem;
    });
     }
    printel(table);
});
jQuery('.download_list_loc').on('click',function(){
        var urlParameters = new URLSearchParams(window.location.search);
        var appids = urlParameters.get('appids');
         if(appids){
            jQuery('.r2_loader').show();
            var fd = new FormData();
            fd.append("action", 'download_xls_file');
            fd.append('ac_ids', appids);
            jQuery.ajax({
                type: 'POST',
                url: r2_config.ajax_url,
                data: fd,
                cache: false,
                contentType: false,
                processData: false,
                //  dataType: "JSON",
                success: function(res) {
                    jQuery('.r2_loader').hide();
                    var a = document.createElement('a');
                    var url = res;
                    a.href = url;
                    a.download = 'selected-facilities.xlsx';
                    document.body.append(a);
                    a.click();
                    a.remove();
                    window.URL.revokeObjectURL(url);
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    jQuery('.r2_loader').hide();
                    console.log('something went wrong. ', textStatus, errorThrown);
                }
            });
         }
         else{
             return false;
         }
    });
    jQuery('.download_on_map').on('click', function() {
        //debugger;
        if (jQuery('.locations_content .desktop_view').is(':visible')) {
            var tab = 'desktop_view';
        } else {
            var tab = 'mobile_view';
        }
        var list_of_ids = jQuery('.locations_content .' + tab + ' .tr.active').map(function() { return jQuery(this).find('.more_info_click').attr('data-appid'); }).get().join(',');

        if (list_of_ids == '') {
            jQuery('.location_error').html('<span style="color:red">Please Select Location Result.</span>');
            setTimeout(function() {
                jQuery('.location_error').html('')
            }, 3000);
        } else {
            jQuery('.r2_loader').show();
            var fd = new FormData();
            fd.append("action", 'download_xls_file');
            fd.append('ac_ids', list_of_ids);
            jQuery.ajax({
                type: 'POST',
                url: r2_config.ajax_url,
                data: fd,
                cache: false,
                contentType: false,
                processData: false,
                //  dataType: "JSON",
                success: function(res) {
                    //debugger;
                    jQuery('.r2_loader').hide();
                    var a = document.createElement('a');
                    var url = res;
                    a.href = url;
                    a.download = 'selected-facilities.xlsx';
                    document.body.append(a);
                    a.click();
                    a.remove();
                    window.URL.revokeObjectURL(url);
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    jQuery('.r2_loader').hide();
                    console.log('something went wrong. ', textStatus, errorThrown);
                }
            });

        }
    });
    jQuery('.download_list_fet').on('click',function(){
         var urlParameters = new URLSearchParams(window.location.search);
        var appids = urlParameters.get('appids');
         if(appids){
             jQuery('.r2_loader').show();
            var fd = new FormData();
            fd.append("action", 'download_features_xls');
            fd.append('ac_ids', appids);
            jQuery.ajax({
                type: 'POST',
                url: r2_config.ajax_url,
                data: fd,
                cache: false,
                contentType: false,
                processData: false,
                //  dataType: "JSON",
                success: function(res) {
                    jQuery('.r2_loader').hide();
                    var a = document.createElement('a');
                    var url = res;
                    a.href = url;
                    a.download = 'selected-features.xlsx';
                    document.body.append(a);
                    a.click();
                    a.remove();
                    window.URL.revokeObjectURL(url);
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    jQuery('.r2_loader').hide();
                    console.log('something went wrong. ', textStatus, errorThrown);
                }
            });
         }
         else{
             return false;
         }
    })
    jQuery('.download_selected_fetures').on('click', function() {
        //debugger;
        if (jQuery('.facility_cnc .desktop_view').is(':visible')) {
            var tab = 'desktop_view';
        } else {
            var tab = 'mobile_view';
        }
        var list_of_ids = jQuery('.facility_cnc .' + tab + ' .tr.active').map(function() { return jQuery(this).find('.more_info_click').attr('data-appid'); }).get().join(',');

        if (list_of_ids == '') {
            jQuery('.fetures_error').html('<span style="color:red">Please Select Location.</span>');
            setTimeout(function() {
                jQuery('.fetures_error').html('')
            }, 3000);
        } else {
            jQuery('.r2_loader').show();
            var fd = new FormData();
            fd.append("action", 'download_features_xls');
            fd.append('ac_ids', list_of_ids);
            jQuery.ajax({
                type: 'POST',
                url: r2_config.ajax_url,
                data: fd,
                cache: false,
                contentType: false,
                processData: false,
                //  dataType: "JSON",
                success: function(res) {
                    jQuery('.r2_loader').hide();
                    var a = document.createElement('a');
                    var url = res;
                    a.href = url;
                    a.download = 'selected-features.xlsx';
                    document.body.append(a);
                    a.click();
                    a.remove();
                    window.URL.revokeObjectURL(url);
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    jQuery('.r2_loader').hide();
                    console.log('something went wrong. ', textStatus, errorThrown);
                }
            });

        }


    });

    function showPosition(position) {
        var latitude = position.coords.latitude;
        var longitude = position.coords.longitude;
        var fd = new FormData();
        jQuery('#filter_on').val(0);
        if (!jQuery('.location_result').is(':visible')) {
            var dis_val = 50;
            var dis_type = 'M';
            if(position.area){
              var dis_type =position.area;
              var dis_val = position.areain;
             }
            fd.append('change_m', dis_type);
            fd.append('change_mv', dis_val);
            jQuery('.link_to_search').attr('data-url',window.location.origin+window.location.pathname+'?type=location&latitude='+latitude+'&longitude='+longitude+'&area='+dis_type+'&areain='+dis_val);
            window.history.pushState("object or string", "Title", window.location.origin+window.location.pathname+'?type=location&latitude='+latitude+'&longitude='+longitude+'&area='+dis_type+'&areain='+dis_val);
        } else {
            var dis_type = jQuery("#measurements_filter").find("option:selected").val();
            var dis_val = jQuery("#measurements_filter_value").find("option:selected").val();
             
            fd.append('change_m', dis_type);
            fd.append('change_mv', dis_val);
            jQuery('.link_to_search').attr('data-url',window.location.origin+window.location.pathname+'?type=location&latitude='+latitude+'&longitude='+longitude+'&area='+dis_type+'&areain='+dis_val);
            window.history.pushState("object or string", "Title", window.location.origin+window.location.pathname+'?type=location&latitude='+latitude+'&longitude='+longitude+'&area='+dis_type+'&areain='+dis_val);
        }
        fd.append("action", 'filter_result');
        fd.append("latitude", latitude);
        fd.append("longitude", longitude);
        jQuery('.r2_loader').show();
        jQuery.ajax({
            type: 'POST',
            url: r2_config.ajax_url,
            data: fd,
            cache: false,
            contentType: false,
            processData: false,
            //  dataType: "JSON",
            success: function(res) {
                jQuery('.r2_loader').hide();
                jQuery('#location_details').hide();
                jQuery('.search_tag').text('Use Current Location');
                jQuery('.location_result').show();
                jQuery('.locations_content').html(res);
                jQuery("#measurements_filter").select2();
                jQuery("#measurements_filter_value").select2();

                jQuery("#measurements_filter").val(dis_type);
                jQuery("#measurements_filter_value").val(dis_val);

                jQuery("#measurements_filter").trigger('change');
                jQuery("#measurements_filter_value").trigger('change');

                jQuery(".table_content").mCustomScrollbar({
                    theme: "minimal"
                });
                jQuery('#filter_on').val(1);
               
                myMap();
                
                var facility_total_loc=jQuery('.location_result .desktop_view .table_content  .tr').length;
                jQuery('.location_result .location_count span').html(facility_total_loc);
                var facility_total_fac=jQuery('.facility_result  .desktop_view .table_content  .tr').length;
                jQuery('.facility_result .location_count span').html(facility_total_fac);
            
            },
            error: function(jqXHR, textStatus, errorThrown) {
                jQuery('.r2_loader').hide();
                console.log('something went wrong. ', textStatus, errorThrown);
            }
        });

    }

    jQuery(".table_content").mCustomScrollbar({
        theme: "minimal"
    });

    jQuery('.facility_tab').on('click', function() {
//debugger;
        var tab = this.id;
        jQuery(".facility_tab").removeClass( "active");
        
        //if (tab == 'disp_facility' && jQuery('.facility_table').length == 0) {
          if (tab == 'disp_facility'){
           // jQuery('.remove_when_search').removeAttr('id');
            //debugger;
            jQuery('.r2_loader').show();
            var fd = new FormData();
            fd.append("action", 'display_all_facilites');
            jQuery.ajax({
                type: 'POST',
                url: r2_config.ajax_url,
                data: fd,
                cache: false,
                contentType: false,
                processData: false,
                //  dataType: "JSON",
                success: function(res) {
                    jQuery('.r2_loader').hide();
                    //jQuery('.search_by_facility').show();
                    //debugger;
                    jQuery('.facility_result_add').hide();
                    jQuery('.search_with_list #more_info_alias').hide();
                    
                    jQuery('.display_facilites').html(res);
                    jQuery('.display_facilites').show();
                   
                    jQuery('#saerch_by_f_name')[0].reset();
                    jQuery(".table_content").mCustomScrollbar({
                        theme: "minimal"
                    });
                    
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    jQuery('.r2_loader').hide();
                    console.log('something went wrong. ', textStatus, errorThrown);
                }
            });
        }
    });
    function search_by_address(){
        var urlParameters = new URLSearchParams(window.location.search);
        var formdata = new FormData();
         var dis = urlParameters.get('measurements_value');
        var type = urlParameters.get('measurements');
         formdata.append('measurements', type);
         jQuery("#measurements").val(urlParameters.get('measurements'));
         formdata.append('measurements_value',dis);
         jQuery("#measurements_value").val(urlParameters.get('measurements_value'));
         formdata.append('address',urlParameters.get('address'));
         jQuery("#address").val(urlParameters.get('address'));
         formdata.append('city',urlParameters.get('city'));
         jQuery("#city").val(urlParameters.get('city'));
         formdata.append('postalcode',urlParameters.get('postalcode'));
         jQuery("#postalcode").val(urlParameters.get('postalcode'));
         formdata.append('country',urlParams.get('country')); 
         jQuery("#country").val(urlParameters.get('country'));
         jQuery("#country").trigger('change');
          formdata.append('state',urlParams.get('state'));
          jQuery("#state").val(urlParameters.get('state'));
          formdata.append('action', 'filter_by_address');
         jQuery('.r2_loader').show();
          jQuery('.link_to_search').attr('data-url',window.location.origin+window.location.pathname+'?type=byaddress&address='+urlParameters.get('address')+'&city='+urlParameters.get('city')+'&postalcode='+urlParameters.get('postalcode')+'&country='+urlParameters.get('country')+'&state='+urlParameters.get('state')+
        '&measurements='+urlParameters.get('measurements')+'&measurements_value='+urlParameters.get('measurements_value'));
        
        window.history.pushState("object or string", "Title", window.location.origin+window.location.pathname+'?type=byaddress&address='+urlParameters.get('address')+'&city='+urlParameters.get('city')+'&postalcode='+urlParameters.get('postalcode')+'&country='+urlParameters.get('country')+'&state='+urlParameters.get('state')+
        '&measurements='+urlParameters.get('measurements')+'&measurements_value='+urlParameters.get('measurements_value'));
       
        jQuery('#filter_on').val(0);
        jQuery.ajax({
            type: "POST",
            url: r2_config.ajax_url,
            data: formdata,
            cache: false,
            contentType: false,
            processData: false,
            success: function(data) {

                jQuery('.r2_loader').hide();
                jQuery('#location_details').hide();
                jQuery('.search_tag').text('Search By Location');
                jQuery('.location_result').show();
                jQuery('.locations_content').html(data);
                jQuery("#measurements_filter").select2();
                jQuery("#measurements_filter_value").select2();

                jQuery("#measurements_filter").val(type);
                jQuery("#measurements_filter_value").val(dis);

                jQuery("#measurements_filter").trigger('change');
                jQuery("#measurements_filter_value").trigger('change');

                jQuery(".table_content").mCustomScrollbar({
                    theme: "minimal"
                });
                jQuery('#filter_on').val(1);
               
                myMap();
                var facility_total_loc=jQuery('.location_result .desktop_view .table_content  .tr').length;
                jQuery('.location_result .location_count span').html(facility_total_loc);
                var facility_total_fac=jQuery('.facility_result  .desktop_view .table_content  .tr').length;
                jQuery('.facility_result .location_count span').html(facility_total_fac);
               
            },
            error: function(jqXHR, textStatus, errorThrown) {
                jQuery('.r2_loader').hide();
                console.log(jqXHR + " :: " + textStatus + " :: " + errorThrown);
            }
        });
        return false;
    }
    jQuery('#searchbyloc').on('click', function() {
        //debugger;
         
            //if (jQuery('#state').val() == "" || jQuery('#country').val() == "" || jQuery('#city').val() == "" || jQuery('#postalcode').val() == "" ) {
              if (jQuery('#state').val() == "" || jQuery('#country').val() == "" || jQuery('#city').val() == "" ) {
                jQuery('#searchbyloc').after('<span class="error">Please fill the required field.</span>');
                if(jQuery('#country').val() == ""){
                jQuery('#select2-country-container').addClass('error_select');
                }
                if(jQuery('#state').val() == ""){
                jQuery('#select2-state-container').addClass('error_select');
                }
                if(jQuery('#city').val() == ""){
                    jQuery('#city').addClass('error_select');
                }
                //  if(jQuery('#postalcode').val() == ""){
                //     jQuery('#postalcode').addClass('error_select');
                // }
                window.setTimeout(function() {
                    jQuery('.error').fadeOut('slow');
                    jQuery('.error').remove();
                }, 4000);
                return false;
            }
  
        
        jQuery('.r2_loader').show();
        jQuery('#filter_on').val(0);
        var form = jQuery("#search_from_address")[0];
        var formdata = new FormData(form);
        var dis = jQuery("select[name='measurements_value']").find("option:selected").val();
        var type = jQuery("select[name='measurements']").find("option:selected").val();
        var urlParameters = new URLSearchParams(window.location.search);
         if(urlParameters.get('state')){
              formdata.append('state', urlParameters.get('state'));
              var state_data=urlParameters.get('state');
        }
        else{
            var state_data=jQuery('#state').val();
        }
        if (jQuery('.location_result').is(':visible')) {
            var filter_m = jQuery("#measurements_filter").find("option:selected").val();
            var filter_mv = jQuery("#measurements_filter_value").find("option:selected").val();
            formdata.append('change_m', filter_m);
            formdata.append('change_mv', filter_mv);
            var dis = jQuery("#measurements_filter_value").find("option:selected").val();
            var type = jQuery("#measurements_filter").find("option:selected").val();
            
        }
        jQuery('.link_to_search').attr('data-url',window.location.origin+window.location.pathname+'?type=byaddress&address='+jQuery('#address').val()+'&city='+jQuery('#city').val()+'&postalcode='+jQuery('#postalcode').val()+'&country='+jQuery('#country').val()+'&state='+state_data+
        '&measurements='+type+'&measurements_value='+dis);
        
        window.history.pushState("object or string", "Title",window.location.origin+window.location.pathname+'?type=byaddress&address='+jQuery('#address').val()+'&city='+jQuery('#city').val()+'&postalcode='+jQuery('#postalcode').val()+'&country='+jQuery('#country').val()+'&state='+state_data+
        '&measurements='+type+'&measurements_value='+dis);
        
        formdata.append('action', 'filter_by_address');
        jQuery.ajax({
            type: "POST",
            url: r2_config.ajax_url,
            data: formdata,
            cache: false,
            contentType: false,
            processData: false,
            success: function(data) {

                jQuery('.r2_loader').hide();
                jQuery('#location_details').hide();
                jQuery('.search_tag').text('Search By Location');
                jQuery('.location_result').show();
                jQuery('.locations_content').html(data);
                jQuery("#measurements_filter").select2();
                jQuery("#measurements_filter_value").select2();

                jQuery("#measurements_filter").val(type);
                jQuery("#measurements_filter_value").val(dis);

                jQuery("#measurements_filter").trigger('change');
                jQuery("#measurements_filter_value").trigger('change');

                jQuery(".table_content").mCustomScrollbar({
                    theme: "minimal"
                });
                jQuery('#filter_on').val(1);
               
                myMap();
                var facility_total_loc=jQuery('.location_result .desktop_view .table_content  .tr').length;
                jQuery('.location_result .location_count span').html(facility_total_loc);
                var facility_total_fac=jQuery('.facility_result  .desktop_view .table_content  .tr').length;
                jQuery('.facility_result .location_count span').html(facility_total_fac);
               
            },
            error: function(jqXHR, textStatus, errorThrown) {
                jQuery('.r2_loader').hide();
                console.log(jqXHR + " :: " + textStatus + " :: " + errorThrown);
            }
        });
        return false;
    });
    function filter_by_area(){
         jQuery('.r2_loader').show();
          var urlParameters = new URLSearchParams(window.location.search);
        var formdata = new FormData();
        formdata.append('action', 'filter_by_area');
        jQuery('#filter_on').val(0);
        formdata.append('region', urlParameters.get('region'));
        formdata.append('country_name', urlParameters.get('country_name'));
         formdata.append('State/Province', urlParameters.get('state_province'));
         formdata.append('city_town',urlParameters.get('city_town'));
         jQuery('.link_to_search').attr('data-url',window.location.origin+window.location.pathname+
         '?type=byarea&region='+urlParameters.get('region')+'&country_name='+urlParameters.get('country_name')
         +'&state_province='+urlParameters.get('state_province')+'&city_town='+urlParameters.get('city_town'));
         
          window.history.pushState("object or string", "Title",window.location.origin+window.location.pathname+
         '?type=byarea&region='+urlParameters.get('region')+'&country_name='+urlParameters.get('country_name')
         +'&state_province='+urlParameters.get('state_province')+'&city_town='+urlParameters.get('city_town'));
         
        jQuery.ajax({
            type: "POST",
            url: r2_config.ajax_url,
            data: formdata,
            cache: false,
            contentType: false,
            processData: false,
            success: function(data) {

                jQuery('.r2_loader').hide();
                jQuery('#location_details').hide();
                jQuery('.search_tag').text('Search By Area');
                jQuery('.location_result').show();
                jQuery('.locations_content').html(data);
                
                jQuery('.location_result_right').hide();
                jQuery(".table_content").mCustomScrollbar({
                    theme: "minimal"
                });
                jQuery('#filter_on').val(1);

                myMap();
                
                var facility_total_loc=jQuery('.location_result .desktop_view .table_content  .tr').length;
                jQuery('.location_result .location_count span').html(facility_total_loc);
                var facility_total_fac=jQuery('.facility_result  .desktop_view .table_content  .tr').length;
                jQuery('.facility_result .location_count span').html(facility_total_fac);
                
                
            },
            error: function(jqXHR, textStatus, errorThrown) {
                jQuery('.r2_loader').hide();
                console.log(jqXHR + " :: " + textStatus + " :: " + errorThrown);
            }
        });
        return false;
    }
    jQuery(document).on('click', '#filterby', function() {
        //debugger;
        if (jQuery('#region').val()=="") {
        if (jQuery('#country_name').val() == "") {
            jQuery('#filterby').after('<span class="error">Select Country is required.</span>');
            jQuery('#select2-country_name-container').addClass('error_select');
            window.setTimeout(function() {
                jQuery('.error').fadeOut('slow');
                jQuery('.error').remove();
            }, 4000);
            return false;
        }
        }
        jQuery('.r2_loader').show();
        var form = jQuery("#filter_from_address")[0];
        var formdata = new FormData(form);
        jQuery('#filter_on').val(0);
        formdata.append('action', 'filter_by_area');
        jQuery('.link_to_search').attr('data-url',window.location.origin+window.location.pathname+
         '?type=byarea&region='+jQuery('#region').val()+'&country_name='+jQuery('#country_name').val()
         +'&state_province='+jQuery('#state_province').val()+'&city_town='+jQuery('#city_town').val());
         
         window.history.pushState("object or string", "Title",window.location.origin+window.location.pathname+
         '?type=byarea&region='+jQuery('#region').val()+'&country_name='+jQuery('#country_name').val()
         +'&state_province='+jQuery('#state_province').val()+'&city_town='+jQuery('#city_town').val());
         
        jQuery.ajax({
            type: "POST",
            url: r2_config.ajax_url,
            data: formdata,
            cache: false,
            contentType: false,
            processData: false,
            success: function(data) {

                jQuery('.r2_loader').hide();
                jQuery('#location_details').hide();
                jQuery('.search_tag').text('Search By Area');
                jQuery('.location_result').show();
                jQuery('.locations_content').html(data);
                jQuery('.location_result_right').hide();
                jQuery(".table_content").mCustomScrollbar({
                    theme: "minimal"
                });
                jQuery('#filter_on').val(1);

                myMap();
                var facility_total_loc=jQuery('.location_result .desktop_view .table_content  .tr').length;
                jQuery('.location_result .location_count span').html(facility_total_loc);
                var facility_total_fac=jQuery('.facility_result  .desktop_view .table_content  .tr').length;
                jQuery('.facility_result .location_count span').html(facility_total_fac);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                jQuery('.r2_loader').hide();
                console.log(jqXHR + " :: " + textStatus + " :: " + errorThrown);
            }
        });
        return false;
    });

    jQuery(document).on('click', '.scroll_sort', function() {
        var click_id = this.id;
        if (click_id == 'sorting_not') {
            // jQuery(".mCustomScrollBox").scrollTop(0);
            jQuery('.scroll_sort').removeClass('active');
            jQuery(".body").mCustomScrollbar("scrollTo", "top");
            return false;
        }
        if (jQuery("." + click_id).hasClass('current_offest')) {
            return false;
        }
        jQuery('.scroll_sort').removeClass('active');
        jQuery(this).addClass('active');
       
        jQuery('#' + click_id).css('disabled', true);
        jQuery('.tr').removeClass('current_offest');
        jQuery("." + click_id).addClass('current_offest');
         jQuery('.facility_table .mCustomScrollBox .mCSB_container').each(function(i, v) {
             var elTop=jQuery("#" + this.id).offset().top-jQuery("#" + this.id + " ." + click_id).offset().top;
             jQuery("#" + this.id).css("top", elTop+"px");
            // jQuery("#" + this.id).animate({ scrollTop: jQuery("#" + this.id + " ." + click_id).position().top - 0 }, 500, 'swing');
            // jQuery("#mCSB_1").animate({scrollTop: jQuery("#mCSB_1 ." + click_id).position().top -0}, 500, 'swing');
        });


    });

});

jQuery(document).on('click', '.location_result input:checkbox', function() {
    //debugger;
    if (jQuery(this).is(':checked')) {
        jQuery(this).parents('.tr').addClass('active');
    } else {
        jQuery(this).parents('.tr').removeClass('active');
    }
});

jQuery(document).on('click', '.facility_result input:checkbox', function() {
    //debugger;
    if (jQuery(this).is(':checked')) {
        jQuery(this).parents('.tr').addClass('active');
    } else {
        jQuery(this).parents('.tr').removeClass('active');
    }
});


jQuery(document).on('click', '.facility_result_add input:checkbox', function() {
    //debugger;
    if (jQuery(this).is(':checked')) {
        jQuery(this).parents('.tr').addClass('active');
    } else {
        jQuery(this).parents('.tr').removeClass('active');
    }
});


// More Info Details Click Event (23-09-20)



jQuery(document).on('click', '.download_links .all_list', function() {
    if (jQuery('.locations_content .desktop_view').is(':visible')) {
        var tab = 'desktop_view';
    } else {
        var tab = 'mobile_view';
    }
    var list_of_ids = jQuery('.locations_content .' + tab + ' .tr.active').map(function() { return jQuery(this).find('.more_info_click').attr('data-appid'); }).get().join(',');

    if (list_of_ids == '') {
        jQuery('.location_error').html('<span style="color:red">Please Select Location.</span>');
        setTimeout(function() {
            jQuery('.location_error').html('')
        }, 3000);
    } else {
        var search_tag=jQuery('.search_tag').text();
        if(search_tag=='Use Current Location'){
           var tab=11;
        }
        else if(search_tag=='Search By Location'){
         var  tab=12; 
        }
        else if(search_tag=='Search By Area'){
            var tab=13; 
        }
        

        var newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?appids=' + list_of_ids+'&tab='+tab;
        window.location.href = newurl;
    }
});

jQuery(document).on('click', '.facility_result .download_links .all_list_facility', function() {
    //debugger;
    if (jQuery('.facility_cnc .desktop_view').is(':visible')) {
        var tab = 'desktop_view';
    } else {
        var tab = 'mobile_view';
    }
    var list_of_ids = jQuery('.facility_result .facility_cnc .' + tab + ' .tr.active').map(function() { return jQuery(this).find('.more_info_click').attr('data-appid'); }).get().join(',');

    if (list_of_ids == '') {
        jQuery('.facility_result_add .location_error').html('<span style="color:red">Please Select Location.</span>');
        setTimeout(function() {
            jQuery('.facility_result_add .location_error').html('')
        }, 3000);
    } else {
       var tab=2;  
        var newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?appids=' + list_of_ids+'&tab='+tab;
        window.location.href = newurl;
        
    }
});


jQuery(document).on('click', '.facility_result_add .download_links .all_list_facility', function() {
    //debugger;
    if (jQuery('.facility_result_add .facility_cnc .desktop_view').is(':visible')) {
        var tab = 'desktop_view';
    } else {
        var tab = 'mobile_view';
    }
    var list_of_ids = jQuery('.facility_result_add .facility_cnc .' + tab + ' .tr.active').map(function() { return jQuery(this).find('.more_info_click').attr('data-appid'); }).get().join(',');

    if (list_of_ids == '') {
        jQuery('.facility_result_add .location_error').html('<span style="color:red">Please Select Location.</span>');
        setTimeout(function() {
            jQuery('.facility_result_add .location_error').html('')
        }, 3000);
    } else {
       var tab=3;  
        var newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?appids=' + list_of_ids+'&tab='+tab;
        window.location.href = newurl;
        
    }
});






jQuery(document).on('click', '.download_links_detail .print_list', function() {
    PrintDiv();
});

function PrintDiv() {
    //debugger;

    var divToPrint = document.getElementsByClassName('more_information_print')[0];
    var popupWin = window.open('', '', 'width=800,height=600');
    
    var css_link=jQuery('#front_css').val();
    popupWin.document.open();
    popupWin.document.write('<html><head><title></title>');
    popupWin.document.write('<link rel="stylesheet" href="'+css_link+'" type="text/css" />');
    popupWin.document.write('</head>');
    popupWin.document.write('<body onload="window.print()">');
    popupWin.document.write(jQuery('.more_information_print').find('.mCSB_container').html());
    popupWin.document.write('</body></html>');
   
   
   setTimeout(function () {
    popupWin.document.close();
    popupWin.focus();
    popupWin.print();
    popupWin.close(); 
}, 1000);
   
    
    
}
function more_info_facility(){
     jQuery.ajax({
        type: "POST",
        url: r2_config.ajax_url,
        data: {
            action: 'display_certified_facility',
        },
        success: function(data) {
            //debugger;
            jQuery('.nav-tabs .facility_tab a[href="#2"]').tab('show');
            jQuery('#more_info_alias').show();
            //jQuery('.search_by_facility').hide();
           jQuery('.facility_features_section').hide();
            jQuery('.more_info_alias').html(data);
            jQuery(".table_content").mCustomScrollbar({
                theme: "minimal"
            });
            var parameters = new URLSearchParams(window.location.search);
            var tabid=parameters.get('tab');
            if(tabid==2){
            jQuery('.detail_title').text("Search By Facility Features");
            }
           
            if(window.location.href.indexOf("backto")==-1){
            var str=document.referrer;
            window.history.pushState("object or string", "Title", window.location.href+'&backto='+str);
            }
            var href = window.location.href;
            var split = href.split("&backto=");
            jQuery('.back_to_search_result').attr('href',split[1]);
            jQuery('.link_search_list').attr('data-url',window.location.href);
        },
    });  
}


function more_info_facility_add(){
     jQuery.ajax({
        type: "POST",
        url: r2_config.ajax_url,
        data: {
            action: 'display_certified_facility',
        },
        success: function(data) {
            //debugger;
            jQuery('.nav-tabs .facility_tab a[href="#3"]').tab('show');
             jQuery('.display_facilites').hide();
             jQuery('.facility_result_add').hide();
            jQuery('.search_with_list #more_info_alias').show();
            //jQuery('.search_by_facility').hide();
           //jQuery('.facility_features_section').hide();
          
           
            jQuery('.search_with_list #more_info_alias .more_info_alias').html(data);
            jQuery(".table_content").mCustomScrollbar({
                theme: "minimal"
            });
            var parameters = new URLSearchParams(window.location.search);
            var tabid=parameters.get('tab');
            if(tabid==3){
            jQuery('.search_with_list #more_info_alias .detail_title').text("Search by Facility Name");
            }
           
            if(window.location.href.indexOf("backto")==-1){
            var str=document.referrer;
            window.history.pushState("object or string", "Title", window.location.href+'&backto='+str);
            }
            var href = window.location.href;
            var split = href.split("&backto=");
            jQuery('.back_to_search_result').attr('href',split[1]);
            jQuery('.link_search_list').attr('data-url',window.location.href);
        },
    });  
}





function more_info_listing() {
    jQuery.ajax({
        type: "POST",
        url: r2_config.ajax_url,
        data: {
            action: 'display_certified_facility',
        },
        success: function(data) {
            //debugger;
            jQuery('.more_info_result').html(data);
            jQuery(".table_content").mCustomScrollbar({
                theme: "minimal"
            });
            var parameters = new URLSearchParams(window.location.search);
            var tabid=parameters.get('tab');
            if(tabid==11){
            jQuery('.detail_title').text("USE CURRENT LOCATION");
            }
            if(tabid==12){
                jQuery('.detail_title').text("SEARCH BY LOCATION");
            }
            if(tabid==13){
                jQuery('.detail_title').text("SEARCH BY AREA");
            }
            if(window.location.href.indexOf("backto")==-1){
            var str=document.referrer;
            window.history.pushState("object or string", "Title", window.location.href+'&backto='+str);
            }
            var href = window.location.href;
            var split = href.split("&backto=");
            jQuery('.back_to_search_result').attr('href',split[1]);
            jQuery('.link_search_list').attr('data-url',window.location.href);
                
             jQuery('.location_result').css('display', 'none');
             jQuery('#location_details').css('display', 'none');
             jQuery('#more_info_detail').css('display', 'block');
        },
    });
}

jQuery(document).on('click', '.location_data .th.select_all span', function() {
    //debugger;
    if (jQuery(this).hasClass('not_checked')) {
        jQuery(this).addClass('all_checked');
        jQuery(this).removeClass('not_checked');
        jQuery.each(jQuery("input[name='filter_single_loc[]']:not(:checked)"), function() {
            // jQuery(this).trigger('click');
            jQuery(this).prop('checked', true);
            jQuery(this).parents('.tr').addClass('active');
        });
    } else {
        jQuery(this).addClass('not_checked');
        jQuery(this).removeClass('all_checked');
        jQuery.each(jQuery("input[name='filter_single_loc[]']:checked"), function() {
            jQuery(this).prop('checked', false);
            jQuery(this).parents('.tr').removeClass('active');
        });
    }
});
jQuery(document).on('click', '.features_data .th.select_all_facility span', function() {
    //debugger;
    if (jQuery(this).hasClass('not_checked')) {
        jQuery(this).addClass('all_checked');
        jQuery(this).removeClass('not_checked');
        jQuery.each(jQuery("input[name='filter_single_facility[]']:not(:checked)"), function() {
            // jQuery(this).trigger('click');
            jQuery(this).prop('checked', true);
            jQuery(this).parents('.tr').addClass('active');
        });
    } else {
        jQuery(this).addClass('not_checked');
        jQuery(this).removeClass('all_checked');
        jQuery.each(jQuery("input[name='filter_single_facility[]']:checked"), function() {
            jQuery(this).prop('checked', false);
            jQuery(this).parents('.tr').removeClass('active');
        });
    }
});


jQuery(document).on('keydown', function(event) {
       if (event.key == "Escape") {
           jQuery('#link_sharing_modal').hide();
       }
   });
   
 jQuery(document).on('click', function(event) {
if(event.target.id=="link_sharing_modal")
{ 
    document.getElementById("link_sharing_modal").style.display="none";
}
});
