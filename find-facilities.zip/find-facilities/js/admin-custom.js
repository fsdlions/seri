jQuery(document).ready(function () {
  

        jQuery("#page_settings").click(function () {
           
            var form = jQuery("#facilities_content")[0];
            var formdata = new FormData(form);
            formdata.append('action', 'save_settings');

            jQuery.ajax({
                type: "POST",
                url: r2_config.ajax_url,
                data: formdata,
                dataType: "json",
                contentType: false,
                processData: false,
                success: function (data) {
                    if (data['error'] == '') {
                        $("#edit_movie").after('<span class="text-success err_msg ">Updated successfully...</span>');
                        $('.loader').hide();
                        window.setTimeout(function () {
                            var url = $('#list_url').val();
                            window.location = url;
                        }, 3000);
                    } else {
                        $("#edit_movie").after('<span class="text-danger err_msg ">' + data['error'] + '</span>');
                        $('.loader').hide();
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    $("#edit_movie").after('<span class="text-danger err_msg ">Something went wrong. please try again later.</span>');
                    $('.loader').hide();
                    console.log(jqXHR + " :: " + textStatus + " :: " + errorThrown);
                }
            });

            return false;
        });

    });