<?php

/*
  Plugin Name: R2 Certified Faculties
  Description: This plugin is developed to SERI API
  Version: 1.0.0
  Author: Empirical Edge INC
 */
define('FIND_FACILITIES_PLUGIN_URL', plugins_url('', __FILE__));

function find_facilities_include() {
    require_once plugin_dir_path(__FILE__) . '/include/facilities-functions.php';
    require_once plugin_dir_path(__FILE__) . '/include/facilities-ajax-admin.php';
}
add_action('init', 'find_facilities_include');
