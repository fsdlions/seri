<?php
//  23-11-2020 Ashik Marsonia HWDRSTD-39
//  Developer Name : Mayur Patel , Jira Ticket : HWDRSTD-39, Date : 24-11-20 ,Comments : Client Comments 23/11/2020
//  Developer Name : Mayur Patel , Jira Ticket : HWDRSTD-39, Date : 25-11-20 ,Comments : Client Comments 23/11/2020
//  Developer Name : Mayur Patel , Jira Ticket : HWDRSTD-39, Date : 26-11-20 ,Comments : Client Comments 23/11/2020
//  Developer Name : Mayur Patel , Jira Ticket : HWDRSTD-39, Date : 27-11-20 ,Comments : Client Comments 23/11/2020
//  Developer Name : Mayur Patel , Jira Ticket : HWDRSTD-41 , Date : 03-12-20 ,Comments : Client Comments 01-12-20
//  Developer Name : Mayur Patel , Jira Ticket : HWDRSTD-41 , Date : 07-12-20 ,Comments : Client Comments 01-12-20

function currenciesBeautifier($value, int $modBase = 50) {
    $roundedValue = round($value);
    $count = strlen((int) str_replace('.', '', $roundedValue));
    $numberOfZeros = $count - 3;
    $mod = str_pad($modBase, $numberOfZeros + 1, '0', STR_PAD_RIGHT);
    return $roundedValue - ($roundedValue % $mod);
}
function roundNearestHundredUp($number) {

    $t = floor($number / 100) * 100;
    if ($number > ($t + 50)) {
        return $t + 50;
    } elseif ($number > $t) {
        return $t;
    } elseif (($number % 100) == 0) {
        return $t - 50;
    }
}


function compare_lastname($a, $b)
  {
    return strnatcmp($a['Name'], $b['Name']);
  }
  
function set_data_in_cache() {
    if (get_user_meta(1, 'access_token', true) && get_user_meta(1, 'expires', true)) {

        $token = get_user_meta(1, 'access_token', true);
        $exp = get_user_meta(1, 'expires', true);
        $rfc_1123_date = gmdate('D, d M Y H:i:s T', time());
        $date1 = date_create($rfc_1123_date);
        $date2 = date_create($exp);
        $diff = date_diff($date1, $date2);
        if ($diff->h <= 1) {
            get_access_token_seri();
            $token = get_user_meta(1, 'access_token', true);
            $exp = get_user_meta(1, 'expires', true);
        } else {
            $token = get_user_meta(1, 'access_token', true);
            $exp = get_user_meta(1, 'expires', true);
        }
    } else {
        get_access_token_seri();
        $token = get_user_meta(1, 'access_token', true);
        $exp = get_user_meta(1, 'expires', true);
    }

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "http://seriapi.azurewebsites.net/api/sfdata/GetSFData",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer " . $token,
        ),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    if (get_option('cron_set')) {

        $time = get_option('cron_set');
    } else {
        $time = 7200;
    }
    wp_cache_set('r2_facilities_curl', $response, '', $time);

    $curl_country = curl_init();
    curl_setopt_array($curl_country, array(
        CURLOPT_URL => "http://seriapi.azurewebsites.net/api/sfdata/GetPicklistValues",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer " . $token,
        ),
    ));
    $response_countrydata = curl_exec($curl_country);
    curl_close($curl_country);
    $response_countrydata = json_decode($response_countrydata, true);
    wp_cache_set('GetPicklistValues', $response_countrydata, '', $time);
}
add_shortcode('get_count', 'get_count_callback');

function get_count_callback() {
    if (get_user_meta(1, 'access_token', true) && get_user_meta(1, 'expires', true)) {
        $token = get_user_meta(1, 'access_token', true);
        $exp = get_user_meta(1, 'expires', true);
        $rfc_1123_date = gmdate('D, d M Y H:i:s T', time());
        $date1 = date_create($rfc_1123_date);
        $date2 = date_create($exp);
        $diff = date_diff($date1, $date2);
        if ($diff->h <= 1) {
            get_access_token_seri();
            $token = get_user_meta(1, 'access_token', true);
            $exp = get_user_meta(1, 'expires', true);
        } else {
            $token = get_user_meta(1, 'access_token', true);
            $exp = get_user_meta(1, 'expires', true);
        }
    } else {
        get_access_token_seri();
        $token = get_user_meta(1, 'access_token', true);
        $exp = get_user_meta(1, 'expires', true);
    }

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "http://seriapi.azurewebsites.net/api/sfdata/GetSFData",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer " . $token,
        ),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $response = json_decode($response, true);
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "http://seriapi.azurewebsites.net/api/sfdata/GetPicklistValues",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer " . $token,
        ),
    ));

    $response_re = curl_exec($curl);

    curl_close($curl);
    $response_re = json_decode($response_re, true);

    foreach ($response['records'] as $res) {
        
        //print_r($res['Country']);
        
        if (@!in_array(strtolower($res['Country']), $country_data)){
          if($res['CertificationStatus'] == 'Active'){
            $country_data[] = strtolower($res['Country']);
          }
        }
    }
  
  
    $country = count($country_data);
    
    foreach ($response['records']  as $region_c) {
        
        if (@!in_array($region_c['Region'], $region_c_data) && @!is_null($region_c['Region'])){
            if($region_c['CertificationStatus'] == 'Active'){
             $region_c_data[] = $region_c['Region'];
            }
        }
            
            
    }
     
    $regions = count($region_c_data);
    // Change Count Facilities
    $count_active_facilities=array();
    foreach($response['records'] as $total_facilities){
        if($total_facilities['CertificationStatus'] == 'Active'){
            $count_active_facilities[]=$total_facilities['CertificationStatus'];
        }
    }
    $count_f=count($count_active_facilities);
    
    // if($response['totalSize']>950){
    //     $count_f=950;
    // }
    // else{
    //     $count_f=$response['totalSize'];
    // }
    @$html.='';
    // $html.='<div class="facilities_middle">
    //         <div class="facilities_content">
    //         <h2 class="number">' . $count_f . '<sup>+</sup></h2>
    //         <h3 class="title">Facilities</h3>
    //         </div>
    //         <div class="facilities_content">
    //         <h2 class="number">' . $country . '</h2>
    //         <h3 class="title">Countries</h3>
    //         </div>
    //         <div class="facilities_content">
    //         <h2 class="number">' . $regions . '</h2>
    //         <h3 class="title">Regions</h3>
    //         </div>
    //         </div>';
    
        $html.='<div class="facilities_middle">
            <div class="facilities_content">
            <h2 class="number">' . $count_f . '</h2>
            <h3 class="title">Facilities</h3>
            </div>
            <div class="facilities_content">
            <h2 class="number">' . $country . '</h2>
            <h3 class="title">Countries</h3>
            </div>
            <div class="facilities_content">
            <h2 class="number">' . $regions . '</h2>
            <h3 class="title">Regions</h3>
            </div>
            </div>';
    
    
    return $html;
}

add_shortcode('display_all_facilities', 'display_all_facilities_callback');

function display_all_facilities_callback() {
    $html = '';
    $footer_after_tabs = get_option('footer_after_tabs', true);
    $footer_after_tabs = html_entity_decode($footer_after_tabs);
    $footer_after_tabs = stripslashes($footer_after_tabs);

    $header_content = get_option('header_before_tabs', true);

    $header_content = html_entity_decode($header_content);

    $header_content = stripslashes($header_content);
    $header_content = apply_filters('the_content', $header_content);


$front_css=FIND_FACILITIES_PLUGIN_URL . '/css/front_style.css';
    $icon = FIND_FACILITIES_PLUGIN_URL . '/images/location_icon.png';
    $map_icon = FIND_FACILITIES_PLUGIN_URL . '/images/r2_pin.svg';
$preloader = FIND_FACILITIES_PLUGIN_URL . '/images/loader.gif';
    $html.=' <div id="preloader" style="background-image: url('.$preloader.');">
        <div id="status"></div>
    </div><div id="location" class="">' . $header_content . '
  <div class="panel panel-default"> 
    <div class="panel-heading">
      <div class="panel-title">
        <ul class="nav nav-tabs">
          <li class="active facility_tab" id="geographic_tab">
            <a href="#1" data-toggle="tab">Geographic Search</a>
          </li>
          <li class="facility_tab" id="features_tab">
           <a href="#2" data-toggle="tab">Advanced Search</a>
          </li>
          <li class="facility_tab" id="disp_facility">
            <a href="#3" data-toggle="tab">Search by Name</a>
          </li>
        </ul>
      </div>
    </div>
    
    <div class="panel-body" id=""><input type="hidden" id="filter_on" value="0">
      <div class="tab-content "><div class="r2_loader" style="display:none;"><div class="r2_main"></div></div>
        <div class="tab-pane active" id="1">
        <input type="hidden" id="map_icon" value="' . $map_icon . '">
         <input type="hidden" id="front_css" value="' . $front_css . '">
        <div id="location_details">
        <div class="row">
        <div class="col-sm-6">
          <div class="m_location_center"><img src="' . $icon . '"><a href="javascript:void(0)" class="use_current_loc">Use Current Location</a></div>
          <span class="or_line">OR</span>
          <h4>ENTER AN ADDRESS TO FIND NEARBY Facilities</h4>
          <form class="filter_form" name="search_from_address" id="search_from_address" method="post">
            <div class="form_control">
              <input type="text" name="address" id="address">
              <label>Address</label>
            </div>
            <div class="col-sm-8"><div class="form_control">
               <input type="text" name="city" id="city">
               <label>City</label>
            </div></div>
            <div class="col-sm-4"><div class="form_control">
               <input type="text" name="postalcode" id="postalcode">
               <label>Postal Code</label>
            </div></div>';
    $GetPicklistValues = wp_cache_get('GetPicklistValues');
    if (false === $GetPicklistValues) {
        set_data_in_cache();
        $GetPicklistValues = wp_cache_get('GetPicklistValues');
    } else {
        $GetPicklistValues = wp_cache_get('GetPicklistValues');
    }
    if ($GetPicklistValues) {
        $GetPicklistValues = $GetPicklistValues['records'];
    }
    usort($GetPicklistValues, 'sortByOrder_country');
    $html.='<select class="" name="country" id="country">';
    $html.='<option value="" disable>Select Country</option>';
    
      global $wpdb;

  $table_name = $wpdb->prefix . "country_facilities";

  $user = $wpdb->get_results( "SELECT * FROM $table_name" );
  
  foreach ($user as $row){
         $html.='<option value="' .  $row->country_name . '">' . $row->country_name . '</option>';
  }
    
    // if($GetPicklistValues){
    //     $country_data=array();
    // foreach ($GetPicklistValues as $country) {
    //     //if (!in_array($country['BillingCountry'], array_map("strtolower", $country_data))) {
    //     if (!in_array(strtolower($country['BillingCountry']), $country_data)) {
    //         $country_data[] = strtolower($country['BillingCountry']);
    //         $html.='<option value="' . $country['BillingCountry'] . '">' . $country['BillingCountry'] . '</option>';
    //         }
    //     }
    // }
    $html.="</select>";
    $html.='<select class="" name="state" id="state">';
    $html.='<option value="" disable>State/Province</option>';
    $html.="</select>";
    $html.='<div class="select_miles">
                 <select class="" name="measurements" id="measurements"><option value="M">Miles</option><option value="K">Kilometers</option></select>
              </div>
              <div class="select_value">
                 <select class="" name="measurements_value" id="measurements_value"><option value="20">20</option><option value="50">50</option><option value="100">100</option><option value="250">250</option></select>
              </div>
              <div class="submit_btn">
              <input type="submit" name="submit" value="Search By Location" id="searchbyloc">
              <a href="javascript:void(0)" id="reset_geosearch_form">Reset</a>
              </div>
          </form>
          </div>
         
          <div class="col-sm-6">
          <span class="or_line m_block">OR</span>
          <h4>View list of R2 Certified Facilities by:</h4>
          <form class="filter_form" name="search_from_address" id="filter_from_address" method="post">
              <select class="" name="region" id="region">
                 <option value="">Region</option>';
                 usort($GetPicklistValues, 'sortByOrder_rigions');
    foreach ($GetPicklistValues as $region_data) {
        if (@!in_array($region_data['Region__c'], $region) && @!is_null($region_data['Region__c'])) {
            $region[] = $region_data['Region__c'];
            $html.='<option value="' . $region_data['Region__c'] . '">' . $region_data['Region__c'] . '</option>';
        }
    }
    $html.='</select>';

    $html.='<select class="" name="country_name" id="country_name">';
    $html.='<option value="">Country</option>';
    if($GetPicklistValues){
         usort($GetPicklistValues, 'sortByOrder_country');
        $country_name=array();
    foreach ($GetPicklistValues as $country) {
        if (!in_array(strtolower($country['BillingCountry']), $country_name)) {
            $country_name[] = strtolower($country['BillingCountry']);
            $html.='<option value="' . $country['BillingCountry'] . '">' . $country['BillingCountry'] . '</option>';
        }
    }
    }
     if(isset($_GET['appids'])){
    $appids=$_GET['appids'];
    $appids = explode(',', $appids);
    if(@is_array($appids) && @$appids[1]){
        $title_print='Print List';
    }
    else{
        $title_print='Print Profile';
    }
    }
    $html.='</select>
              
              </select>
              <select class="" name="State/Province" id="state_province"><option value=""></option></select>
              <select class="" name="city_town" id="city_town"><option value=""></option></select>
              <input type="submit" name="submit" value="Filter By Area" id="filterby">
              <a href="javascript:void(0)" id="reset_geosearch_select">Reset</a>
          </form>
          </div>
          </div>
           </div>
                  <div class="location_result" style="display:none;"><h4 class="search_tag"></h4>
                  <div class="reset_btn"><a href="'.get_permalink().'">Reset Search</a></div>
                  <div id="googleMap" style="width:100%;height:400px;"></div>
                  <div class="location_result_left location_lefts">
                 
                  <div class="location_count"><span></span> Facilities Found</div>
                  <div class="location_navigation"></div>
                  </div>
                  <div class="location_result_right">
                      <div class="select_miles">
                        <select class="for_filter" name="measurements" name="measurements_filter" id="measurements_filter"><option value="M">Miles</option><option value="K">Kilometers</option></select>
                       </div>
                       <div class="select_value">
                        <select class="for_filter" name="measurements_filter_value" id="measurements_filter_value"><option value="20">20</option><option value="50" selected>50</option><option value="100">100</option><option value="250">250</option></select>
                       </div>
                   </div>
                    <div class="locations_content"></div>
                    
                    <div class="download_links">
                        <a class="action_links all_list" href="javascript:void(0)">View All Selected</a>
                        <a class="action_links download_on_map" href="javascript:void(0)">Download List</a>
                        <a class="action_links print_table print_list" href="javascript:void(0)">Print Selected</a>
                        <a class="action_links link_to_search" href="javascript:void(0)">Link to Search</a>
                    </div>
                    <div class="location_error"></div>    
                    
                  </div>
                 
                 <div id="more_info_detail" style="display:none;">
                    <div class="f_detail_head">
                        <h4 class="detail_title"></h4>
                        <div class="search_buttons">
                        <a href="'.get_permalink().'">Reset Search</a>
                        <a href="javascript:void(0)" class="back_to_search_result">BACK TO SEARCH RESULTS</a>
                        </div>
                    </div>
                    <div class="more_info_result" id="print_for_id">
                    </div>
                    <div class="download_links_detail">
                        <a class="action_links download_list_loc" href="javascript:void(0)">Download List</a>
                        <a class="action_links print_list" href="javascript:void(0)">'.@$title_print.'</a>
                        <a class="action_links link_search_list" href="javascript:void(0)">Link to Search</a></div>
                 </div>
        </div>
        <div class="tab-pane" id="2">
            
            <div class="facility_features_section">
               
                <div class="row">
                <form name="fetures_filter" id="fetures_filter" method="post">
                    <div class="border_right col-sm-6">
                        <h4>SEARCH BY FACILITY FEATURES:</h4>
                            <div class="certificate_status">
                                <h4>Certificate Status</h4>
                                <div class="status_btn col-sm-6">
                                <label class="radio_btn">
                                    <input type="checkbox" value="Active"  name="certificate_status" class="certifications">
                                    <font>Active</font>
                                    <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" value="Suspended" name="certificate_status" class="certifications">
                                   <font>Suspended</font>
                                  <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" value="Revoked" name="certificate_status" class="certifications">
                                  <font>Revoked</font>
                                  <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" value="Expired" name="certificate_status" class="certifications">
                                  <font>Expired</font>
                                  <span class="checkmark_check"></span>
                                </label>
                            </div>
                        </div>
                        <div class="certificate_status">
                            <div class="status_btn col-sm-6">
                                <label class="radio_btn">
                                    <input type="checkbox" name="certificate_status" value="Voluntarily Withdrawn" class="certifications">
                                    <font>Discontinued</font>
                                    <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" name="certificate_status" value="Facility Closed" class="certifications">
                                   <font>Closed</font>
                                  <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" name="certificate_status" value="Facility Moved" class="certifications">
                                   <font>Moved</font>
                                  <span class="checkmark_check"></span>
                                </label>
                            </div>
                        </div>
                        <div class="certificate_status business_workflow">
                            <h4>R2v3 Business Workflow</h4>
                                <div class="status_btn">
                                <label class="radio_btn">
                                    <input type="checkbox"  value="Returns/Warranty/Trade-Ins" name="business_workflow" class="workflow">
                                    <font>Returns/ Warranty/ Trade-Ins</font>
                                    <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" value="ITAD/Remarketing" name="business_workflow" class="workflow">
                                  <font>ITAD/Remarketing</font>
                                  <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" value="Escrap/Recycling" name="business_workflow" class="workflow">
                                  <font>E-Scrap/Recycling</font>
                                  <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" value="Telecom/Medical/Commercial" name="business_workflow" class="workflow">
                                  <font>Telecom/ Medical/ Commercial</font>
                                  <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" value="Data Destruction" name="business_workflow" class="workflow">
                                  <font>Data Destruction</font>
                                  <span class="checkmark_check"></span>
                                </label>
                            </div>
                        </div>
                        
                         <div class="certificate_status process_req">
                            <h4>R2v3 Process Requirements</h4>
                            <div class="requirement_name">
                                <h5>Appendix</h5>
                                <h5>Description</h5>
                            </div>
                                <div class="status_btn">
                                <label class="radio_btn">
                                    <input type="checkbox" value="Downstream Recycling Chain" data-app="AppendixA" name="process_req" class="process_requirements">
                                    <font><span class="appendix">A</span> Downstream Recycling chain</font>
                                    <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" value="Logical Data Erasure" data-app="AppendixBLogicalErasure" name="process_req" class="process_requirements">
                                   <font><span class="appendix">B</span> Logical Data Erasure</font>
                                  <span class="checkmark_check"></span>

                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" value="Physical Destruction" data-app="AppendixBPhysicalDest" name="process_req" class="process_requirements">
                                   <font><span class="appendix"></span>Physical Destruction</font>
                                  <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" value="Test and Repair"  data-app="AppendixC" name="process_req" class="process_requirements">
                                   <font><span class="appendix">C</span>Test & Repair</font>
                                  <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" value="Speciality Equipment" data-app="AppendixD" name="process_req" class="process_requirements">
                                   <font><span class="appendix">D</span>Speciality Equipment</font>
                                  <span class="checkmark_check"></span>
                                </label>
                                 <label class="radio_btn">
                                  <input type="checkbox" value="Materials Recovery" data-app="AppendixE" name="process_req" class="process_requirements">
                                   <font><span class="appendix">E</span>Materials Recovery</font>
                                  <span class="checkmark_check"></span>
                                </label>
                                 <label class="radio_btn">
                                  <input type="checkbox" value="Brokering" data-app="AppendixF" name="process_req" class="process_requirements">
                                   <font><span class="appendix">F</span>Brokering</font>
                                  <span class="checkmark_check"></span>
                                </label>
                            </div>
                        </div>
                        
                        <div class="certificate_status r_verstions">
                         <div class="status_btn col-sm-6">
                            <h4>R2 Version</h4>
                                <label class="radio_btn">
                                    <input type="checkbox"  value="All" name="version" class="f_version">
                                    <font>All</font>
                                    <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" value="R2:2013" name="version" class="f_version">
                                  <font>R2:2013</font>
                                  <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="checkbox" value="R2v3" name="version" class="f_version">
                                  <font>R2v3</font>
                                  <span class="checkmark_check"></span>
                                </label>
                            </div>
                            
                            <div class="status_btn col-sm-6">
                            <h4>Drop off</h4>
                                <label class="radio_btn">
                                    <input type="radio"  value="Yes"  name="drop_off" class="f_dropoff">
                                    <font>Yes</font>
                                    <span class="checkmark_check"></span>
                                </label>
                                <label class="radio_btn">
                                  <input type="radio" value="No" name="drop_off" class="f_dropoff">
                                  <font>No</font>
                                  <span class="checkmark_check"></span>
                                </label>
                            </div>
                            <div class="status_btn col-sm-12">
                            <h4>Status Changes in Last X Days</h4>
                            <input type="number" class="day_filter">
                            </div>
                        </div>
                        
                    </div>
                    <div class="col-sm-6">
                        <h4>NARROW SEARCH RESULTS GEOGRAPHICALLY:</h4> 
                        
            <select name="regions" id="regions">
            <option value="">Region</option>';
            if($GetPicklistValues){
                $region_data=array();
                usort($GetPicklistValues, 'sortByOrder_rigions');
            foreach ($GetPicklistValues as $region_data) {
                if (@!in_array(strtolower($region_data['Region__c']), $regions) && @!is_null($region_data['Region__c'])) {
                    $regions[] = strtolower($region_data['Region__c']);
                    $html.='<option value="' . $region_data['Region__c'] . '">' . $region_data['Region__c'] . '</option>';
                }
            }
            }
            $html.='</select>';

    $html.='<select name="country_features" id="country_features">';
    $html.='<option value="">Country</option>';
    if($GetPicklistValues){
        usort($GetPicklistValues, 'sortByOrder_country');
        $country_fdata=array();
    foreach ($GetPicklistValues as $country) {
        if (!in_array(strtolower($country['BillingCountry']), $country_fdata)) {
            $country_fdata[] = strtolower($country['BillingCountry']);
            $html.='<option value="' . $country['BillingCountry'] . '">' . $country['BillingCountry'] . '</option>';
        }
    }
    }
    if(isset($_GET['appids'])){
    $appids=$_GET['appids'];
    $appids = explode(',', $appids);
     if(is_array($appids) && $appids[1]){
         $title_print='Print List';
    }
    else{
        $title_print='Print Profile';
    }
    }
    $html.='</select>
                            
                            <select name="state_features" id="state_features">
                                <option value="">state/province</option>
                               
                            </select>
                            
                            <select name="city_town_features" id="city_town_features">
                                <option value="">City/Town</option>
                                
                            </select>
                            <div class="features_btn">
                                <input type="submit" name="search" value="search" id="more_features">
                                <a href="javascript:void(0)" id="reset_fetures">Reset</a>
                            </div>
                    </div>
                    </form>
                </div>
            </div>
            <div class="facility_result" style="display:none;">
                <h4 class="facility_tag">Search By Facility Features</h4>
                <div class="reset_btn"><a href="'.get_permalink().'">Reset Search</a></div>
                <div class="remove_when_search" id="googleMap_facility" style="width:100%;height:400px;"></div>
                 <div class="location_result_left location_lefts">
                 
                  <div class="location_count"><span></span> Facilities Found</div>
                  <div class="location_navigation"></div>
                  </div>
                  
                  <div class="location_result_right">
                  </div>
                  <div class="facility_cnc"></div>
                  
                  <div class="download_links">
                       <a class="all_list_facility action_links" href="javascript:void(0)">View All Selected</a>
                       <a class="download_selected_fetures action_links" href="javascript:void(0)">Download List</a>
                       <a class="print_list print_fetures action_links" href="javascript:void(0)">Print Selected</a>
                       <a class="link_to_fetures action_links" href="javascript:void(0)">Link to Search</a>
                   </div>
                    <div class="fetures_error"></div>   
            </div>
            <div id="more_info_alias" style="display:none;">
                    <div class="f_detail_head">
                        <h4 class="detail_title"></h4>
                        <div class="reset_button">
                        <a href="'.get_permalink().'">Reset Search</a>
                        <a href="javascript:void(0)" class="back_to_search_result">BACK TO SEARCH RESULTS</a>
                        </div>
                    </div>
                    <div class="more_info_alias table_content" id="print_for_id">
                    </div>
                    <div class="download_links_detail">
                        <a class="action_links download_list_fet" href="javascript:void(0)">Download List</a>
                        <a class="action_links print_list" href="javascript:void(0)">'.@$title_print.'</a>
                        <a class="action_links link_search_list" href="javascript:void(0)">Link to Search</a></div>
                 </div>
        
        
        </div>
            
        <div class="tab-pane search_with_list"  id="3">
        
        
        
        
        
        <div id="more_info_alias" style="display:none;">
                    <div class="f_detail_head">
                        <h4 class="detail_title"></h4>
                        <div class="reset_button">
                        <a href="'.get_permalink().'">Reset Search</a>
                        <a href="javascript:void(0)" class="back_to_search_result">BACK TO SEARCH RESULTS</a>
                        </div>
                    </div>
                    <div class="more_info_alias table_content" id="print_for_id">
                    </div>
                    <div class="download_links_detail">
                        <a class="action_links download_list_fet" href="javascript:void(0)">Download List</a>
                        <a class="action_links print_list" href="javascript:void(0)">'.@$title_print.'</a>
                        <a class="action_links link_search_list" href="javascript:void(0)">Link to Search</a></div>
                 </div>
        
        
        
        <div class="facility_result_add" style="display:none;">
                <h4 class="facility_tag">Search by Facility Name</h4>
                <div class="reset_btn"><a href="'.get_permalink().'">Reset Search</a></div>
                <div id="googleMap_facility_add" style="width:100%;height:400px;"></div>
                 <div class="location_result_left location_lefts">
                 
                  <div class="location_count"><span></span> Facilities Found</div>
                  
                  </div>
                  
                  <div class="location_result_right">
                  </div>
                  <div class="facility_cnc"></div>
                  
                  <div class="download_links">
                       <a class="all_list_facility action_links" href="javascript:void(0)">View All Selected</a>
                       <a class="download_selected_fetures action_links" href="javascript:void(0)">Download List</a>
                       <a class="print_list print_fetures action_links" href="javascript:void(0)">Print Selected</a>
                       <a class="link_to_fetures action_links" href="javascript:void(0)">Link to Search</a>
                   </div>
                    <div class="fetures_error"></div>   
            </div>
        
        
        
        
        <div class="display_facilites">';
 $print_header = get_option('print_header', true);
      $print_header = html_entity_decode($print_header);
      $print_header = stripslashes($print_header);
    $html.='</div></div>
      </div>
    </div>
  </div>
</div>
<div class="print_on_map" style="display:none;">'.$print_header.'</div>
<div class="popup_class">
<div id="link_sharing_modal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
    <div class="modal_close">
      <span class="share_close"><font>Close</font>&times;</span>
      </div>
      <h3>Link to Search</h3>
      <p>Below is a link to your customized search parameters for R2 recyclers</p>
    </div>
    <div class="modal-body">
      <input type="text" class="link_sharing" name="send_link" id="send_link" readonly>
    </div>
    <div class="modal-footer">
     <button onclick="copyText()" class="copy_link_btn">Copy Link</button>
     <button class="copy_link_btn" id="share_link_btn">Share Link</button>
    </div>
  </div>

</div>
</div>
<div class="footer_section">' . $footer_after_tabs . '</div>';
    return $html;
}

function get_access_token_seri() {

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "http://seriapi.azurewebsites.net/token",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => "grant_type=password&username=website@seriapi.com&password=SeriAPI@2020",
        CURLOPT_HTTPHEADER => array(
            "Accept: application/json",
            "Content-Type: application/x-www-form-urlencoded",
        ),
    ));

    $response = curl_exec($curl);
    curl_close($curl);
    $response = json_decode($response, true);
    $token = $response["access_token"];
    $exp = $response[".expires"];

    update_user_meta(1, 'access_token', $token);
    update_user_meta(1, 'expires', $exp);
}



function sortByOrder_city($x, $y) {
    return strcasecmp($x['BillingCity'], $y['BillingCity']);
}

function sortByOrder_rigions($x, $y) {
    return strcasecmp($x['Region__c'], $y['Region__c']);
}
function sortByOrder_states($x, $y) {
    return strcasecmp($x['BillingState'], $y['BillingState']);
}
function sortByOrder_country($x, $y) {
    return strcasecmp($x['BillingCountry'], $y['BillingCountry']);
}
function sortByOrder($x, $y) {
    return strcasecmp($x['Name'], $y['Name']);
}

function sortBydisgeo($x, $y) {
    return $y['main_dis'] > $x['main_dis'] ? 1 : -1;
}

add_action("wp_ajax_display_all_facilites", "display_all_facilites_callbabk");
add_action("wp_ajax_nopriv_display_all_facilites", "display_all_facilites_callbabk");

function display_all_facilites_callbabk() {

    $result = wp_cache_get('r2_facilities_curl');
    if (false === $result) {
        set_data_in_cache();
        $response = wp_cache_get('r2_facilities_curl');
    } else {
        $response = wp_cache_get('r2_facilities_curl');
    }
    // if (get_user_meta(1, 'access_token', true) && get_user_meta(1, 'expires', true)) {
    //     $token = get_user_meta(1, 'access_token', true);
    //     $exp = get_user_meta(1, 'expires', true);
    //     $rfc_1123_date = gmdate('D, d M Y H:i:s T', time());
    //     $date1 = date_create($rfc_1123_date);
    //     $date2 = date_create($exp);
    //     $diff = date_diff($date1, $date2);
    //     if ($diff->h <= 1) {
    //         get_access_token_seri();
    //         $token = get_user_meta(1, 'access_token', true);
    //         $exp = get_user_meta(1, 'expires', true);
    //     } else {
    //         $token = get_user_meta(1, 'access_token', true);
    //         $exp = get_user_meta(1, 'expires', true);
    //     }
    // } else {
    //     get_access_token_seri();
    //     $token = get_user_meta(1, 'access_token', true);
    //     $exp = get_user_meta(1, 'expires', true);
    // }
    // $curl = curl_init();
    // curl_setopt_array($curl, array(
    //     CURLOPT_URL => "http://seri.stage.empiricaledge.com/api/sfdata/GetSFData",
    //     CURLOPT_RETURNTRANSFER => true,
    //     CURLOPT_ENCODING => "",
    //     CURLOPT_MAXREDIRS => 10,
    //     CURLOPT_TIMEOUT => 0,
    //     CURLOPT_FOLLOWLOCATION => true,
    //     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    //     CURLOPT_CUSTOMREQUEST => "GET",
    //     CURLOPT_HTTPHEADER => array(
    //         "Authorization: Bearer " . $token,
    //     ),
    // ));
    // $response = curl_exec($curl);
    // curl_close($curl);
    $response = json_decode($response, true);
    $response = $response['records'];
    usort($response, 'sortByOrder');
    $msg = '';
    
    $msg.='<div class="search_by_facility">
            <form name="saerch_by_f_name" id="saerch_by_f_name" method="post">
            <label>Search by facility name :</label>
            <div class="saerch_by_features">
                <input type="text"  name="by_name_alias" id="by_name_alias">
                <input type="submit" name="submit" value="Search" id="search_alias">
            </div>
            </form>
            </div>';
    
    $msg.='<div class="sorting">';
    $msg.= '<a class="scroll_sort" id="sorting_number">#</a>';
    foreach (range('A', 'Z') as $column) {
        $msg.= '<a class="scroll_sort" id="sorting_' . $column . '">' . $column . '</a>';
    }
    $msg.= '<a class="scroll_sort" id="sorting_not">Show All</a>';
    $msg.='</div>';
    $msg.='<div class="facility_table">';
    $msg.='<div class="location_data desktop_view table">';
    
    $msg.='<div class="thead">
      <div class="tr">
        <div class="th">Company</div>
        <div class="th">Address</div>
        <div class="th">Cert Status</div>
        <div class="th">R2 Verstion</div>
      </div>
    </div><div class="table_content">';

    foreach ($response as $recoreds) {
        if (is_numeric($recoreds['Name'][0]) && $is_number != 'e') {
            $msg.='<div class="tr alpha sorting_number" ><div class="td">#</div><div class="td"></div><div class="td"></div><div class="td"></div></div>';
            $is_number = 'e';
        }
        $recent = $recoreds['Name'][0];
        if (strcasecmp($first, $recent) != 0) {
            if (!is_numeric($recent[0])) {
                $msg.='<div class="tr alpha sorting_' . $recent . '" ><div class="td">' . $recent . '</div><div class="td"></div><div class="td"></div><div class="td"></div></div>';
            }
        }

        $msg.='<div class="tr">
        <div class="td">' . $recoreds['Name'] . '</div>
        <div class="td">' . $recoreds['Street'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
        <div class="td">' . $recoreds['CertificationStatus'] . '</div>
        <div class="td">' . $recoreds['CertificationType'] . '</div>
      </div>';
        $first = $recoreds['Name'][0];
        if ($is_number != 'e')
            $is_number = $first;
    }
    $msg.='</div></div>';

    $msg.='<div class="location_data mobile_view table">';

    $msg.='<div class="thead">
      <div class="tr">
        <div class="th">Company Information</div>
       
        <div class="th">Cert Status</div>
       
      </div>
    </div><div class="table_content">';

    foreach ($response as $recoreds) {
        if (is_numeric($recoreds['Name'][0]) && $is_numbers != 'ez') {
            $msg.='<div class="tr alpha sorting_number" ><div class="td">#</div><div class="td"></div></div>';
            $is_numbers = 'ez';
        }
        $recent = $recoreds['Name'][0];
        if (strcasecmp($firsts, $recent) != 0) {
            if (!is_numeric($recent[0])) {
                $msg.='<div class="tr alpha sorting_' . $recent . '" ><div class="td">' . $recent . '</div><div class="td"></div></div>';
            }
        }

        $msg.='<div class="tr">
        <div class="td">
            <div class="c_name">' . $recoreds['Name'] . '</div>
            <div class="address">' . $recoreds['Street'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
        </div>
        <div class="td">' . $recoreds['CertificationStatus'] . '</div>
      </div>';
        $firsts = $recoreds['Name'][0];
        if ($is_numbers != 'ez')
            $is_numbers = $firsts;
    }
    $msg.='</div></div>';
    $msg.='</div>';
    $msg.='<form method="post"><input type="submit" name="submit" value="DOWNLOAD LIST"></form>';
    echo $msg;

    exit();
}

require WP_PLUGIN_DIR .'/find-facilities/vendor/autoload.php';

if (isset($_POST['submit']) && $_POST['submit'] == "DOWNLOAD LIST") {
    $spreadsheet = new PhpOffice\PhpSpreadsheet\Spreadsheet();

    $from = "H1"; // or any value
    $to = "T2"; // or any value

    $spreadsheet->getActiveSheet()->mergeCells('H1:T2');

    $styleArray = [
        'font' => [
            'bold' => true,
        ],
        'alignment' => [
            'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
        ],
    ];

    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->getFont()->setSize(16);
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->applyFromArray($styleArray);
    $sheet = $spreadsheet->getActiveSheet(0);
// add some text
    $spreadsheet->getActiveSheet()->setCellValue('H1', 'All Facilities');


    $t = 4;
    $sheet->setCellValue('A' . $t, 'Sr No.');
    $sheet->setCellValue('B' . $t, 'Company');
    $sheet->setCellValue('C' . $t, 'Address');
    $sheet->setCellValue('D' . $t, 'Website');
    $sheet->setcellValue('E' . $t,'Certified Process Requirements');
    $sheet->setcellValue('F' . $t,'Scope');
    $sheet->setcellValue('G' . $t,'Public drop off location');
    $sheet->setcellValue('H' . $t,'Current Certification status');
    $sheet->setcellValue('I' . $t,'Certification type');
    $sheet->setcellValue('J' . $t,'Campus scheme');
    $sheet->setcellValue('K' . $t,'Certification body');
    $sheet->setcellValue('L' . $t,'Certification number');
    $sheet->setcellValue('M' . $t,'Initial certification date');
    $sheet->setcellValue('N' . $t,'Experation date');
    $sheet->setcellValue('O' . $t,'Last change date');



    $from = "A4"; // or any value
    $to = "P4"; // or any value
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->getFont()->setSize(11);

    if (get_user_meta(1, 'access_token', true) && get_user_meta(1, 'expires', true)) {

        $token = get_user_meta(1, 'access_token', true);
        $exp = get_user_meta(1, 'expires', true);
        $rfc_1123_date = gmdate('D, d M Y H:i:s T', time());
        $date1 = date_create($rfc_1123_date);
        $date2 = date_create($exp);
        $diff = date_diff($date1, $date2);
        if ($diff->h <= 1) {
            get_access_token_seri();
            $token = get_user_meta(1, 'access_token', true);
            $exp = get_user_meta(1, 'expires', true);
        } else {
            $token = get_user_meta(1, 'access_token', true);
            $exp = get_user_meta(1, 'expires', true);
        }
    } else {
        get_access_token_seri();
        $token = get_user_meta(1, 'access_token', true);
        $exp = get_user_meta(1, 'expires', true);
    }

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "http://seriapi.azurewebsites.net/api/sfdata/GetSFData",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer " . $token,
        ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    $response = json_decode($response, true);
    $response = $response['records'];
    usort($response, 'sortByOrder');
    $i = 5;
    $j = 1;
    foreach ($response as $recoreds) {
        $name = $recoreds['Name'];
        $address = $recoreds['Street'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'];
        $type = $recoreds['CertificationType'];
        $cert_status = $recoreds['CertificationStatus'];
        
        
         $output=array();
                
                if($recoreds['AppendixA']==true || $recoreds['AppendixBLogicalErasure']==true || $recoreds['AppendixBPhysicalDest']==true || $recoreds['AppendixC']==true || $recoreds['AppendixD']==true || $recoreds['AppendixE']==true || $recoreds['AppendixF']==true ){
                        if($recoreds['AppendixA']==true){
                            $output[]='A Downstream Recycling chain';
                        }
                        $output[]='B Logical Data Erasure';
                        if($recoreds['AppendixBLogicalErasure']==true){
                            $output[]='B Logical Data Erasure';
                        }
                        if($recoreds['AppendixBPhysicalDest']==true){
                            $output[]='B Physical Destruction';
                        }
                        if($recoreds['AppendixC']==true){
                            $output[]='C Test & Repair';
                        }
                        if($recoreds['AppendixD']==true){
                            $output[]='D Specialty Equipment';
                        }
                        if($recoreds['AppendixE']==true){
                            $output[]='E Materials Recovery';
                        }
                        if($recoreds['AppendixF']==true){
                            $output[]='F Brokering';
                        }
                        
                        $Certified_Processes=implode(',',$output);
                        
                    }
                    else{
                       $Certified_Processes.=''; 
                    }
                
        
        
        
        if($recoreds['DropOff'] == true){
                   $DropOff= $recoreds['DropOff'];
                }
                else{
                    $DropOff= "";
                } 
                
                if($recoreds['CampusCertification'] == true){
                   $CampusCertification= $recoreds['CampusCertification'];
                }
                else{
                    $CampusCertification= "";
                } 
        
       if(!is_null($recoreds['InitialCertificationDate'])){
                   $in_date= date("d/m/Y", strtotime($recoreds['InitialCertificationDate']));
                }
                else{
                    $in_date= "";
                }
                if(!is_null($recoreds['ExpirationDate'])){
                    $exp_d=date("d/m/Y", strtotime($recoreds['ExpirationDate']));
                }
                else{
                    $exp_d= "";
                }
                 if(!is_null($recoreds['LastCertStatusChangeDate'])){
                    $last_d=date("d/m/Y", strtotime($recoreds['LastCertStatusChangeDate']));
                }
                else{
                    $last_d= "";
                }
                $sheet->setCellValue('A' . $i, $j);
                $sheet->setCellValue('B' . $i, $name);
                $sheet->setCellValue('C' . $i, $address);
                $sheet->setCellValue('D' . $i, $recoreds['Website']);
                $sheet->setCellValue('E' . $i, $Certified_Processes);
                //$sheet->setcellValue('F' . $i,"");
                $sheet->setcellValue('F' . $i,$recoreds['R2Scope']);
                $sheet->setcellValue('G' . $i,$DropOff);
                $sheet->setcellValue('H' . $i, $cert_status);
                $sheet->setcellValue('I' . $i, $type);
                $sheet->setcellValue('J' . $i,$CampusCertification);
                $sheet->setcellValue('K' . $i,$recoreds['CertifyingBodyName']);
                $sheet->setcellValue('L' . $i,$recoreds['CertificationNumber']);
                $sheet->setcellValue('M' . $i,$in_date);
                $sheet->setcellValue('N' . $i,$exp_d);
                $sheet->setcellValue('O' . $i,$last_d);
                
                $i++;
                $j++;
    }
    header('Pragma: public');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Cache-Control: private', false);
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename=facilities.xlsx');
    $spreadsheet->setActiveSheetIndex(0);
    $writer = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    $writer->save(WP_PLUGIN_DIR .'/find-facilities/vendor/facilities.xlsx');
    $writer->save('php://output');


    exit();
}

function distance($lat1, $lon1, $lat2, $lon2, $unit) {

    $theta = $lon1 - $lon2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;
    $unit = strtoupper($unit);

    if ($unit == "K") {
        return ($miles * 1.609344);
    } else if ($unit == "N") {
        return ($miles * 0.8684);
    } else {
        return $miles;
    }
}

add_action("wp_ajax_filter_result", "filter_result_callbabk");
add_action("wp_ajax_nopriv_filter_result", "filter_result_callbabk");

function my_js_variables($x) {
    ?>
    <script type="text/javascript">
        var lat_longs = '<?php echo wp_json_encode($x) ?>';
    </script><?php
}

add_action('wp_head', 'my_js_variables');

function facility_variables($x) {
    ?>
    <script type="text/javascript">
        var f_lat_longs = '<?php echo wp_json_encode($x) ?>';
    </script><?php
}

add_action('wp_head', 'facility_variables');

function filter_result_callbabk() {

    $result = wp_cache_get('r2_facilities_curl');
    if (false === $result) {
        set_data_in_cache();
        $response = wp_cache_get('r2_facilities_curl');
    } else {
        $response = wp_cache_get('r2_facilities_curl');
    }

    // if (get_user_meta(1, 'access_token', true) && get_user_meta(1, 'expires', true)) {
    //     $token = get_user_meta(1, 'access_token', true);
    //     $exp = get_user_meta(1, 'expires', true);
    //     $rfc_1123_date = gmdate('D, d M Y H:i:s T', time());
    //     $date1 = date_create($rfc_1123_date);
    //     $date2 = date_create($exp);
    //     $diff = date_diff($date1, $date2);
    //     if ($diff->h <= 1) {
    //         get_access_token_seri();
    //         $token = get_user_meta(1, 'access_token', true);
    //         $exp = get_user_meta(1, 'expires', true);
    //     } else {
    //         $token = get_user_meta(1, 'access_token', true);
    //         $exp = get_user_meta(1, 'expires', true);
    //     }
    // } else {
    //     get_access_token_seri();
    //     $token = get_user_meta(1, 'access_token', true);
    //     $exp = get_user_meta(1, 'expires', true);
    // }
    // $curl = curl_init();
    // $string = 'lat=' . $_POST['latitude'] . '&lon=' . $_POST['longitude'];
    // curl_setopt_array($curl, array(
    //     CURLOPT_URL => "http://seri.stage.empiricaledge.com/api/sfdata/FilterSFData?" . $string,
    //     CURLOPT_RETURNTRANSFER => true,
    //     CURLOPT_ENCODING => "",
    //     CURLOPT_MAXREDIRS => 10,
    //     CURLOPT_TIMEOUT => 0,
    //     CURLOPT_FOLLOWLOCATION => true,
    //     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    //     CURLOPT_CUSTOMREQUEST => "GET",
    //     CURLOPT_HTTPHEADER => array(
    //         "Authorization: Bearer " . $token,
    //     ),
    // ));
    // $response = curl_exec($curl);
    // curl_close($curl);
    $response = json_decode($response, true);
    // print_r($response);
    $msg = '';

    $msg.='<div class="location_data desktop_view table">';
    $msg.='<div class="thead">
      <div class="tr">
        <div class="th select_all"><span class="not_checked">Select All</span></div>
        <div class="th">Company</div>
        <div class="th">Address</div>
        <div class="th">Status, <br/> cert type</div>
        <div class="th">Distance</div>
        <div class="th last_col"></div>
      </div>
    </div><div class="table_content">';
    
    $listing_dis=array();
    foreach ($response['records'] as $recoreds) {
      
        $lat = $recoreds['Latitude'];
        $lang = $recoreds['Longitude'];
        $distance = distance($_POST['latitude'], $_POST['longitude'], $lat, $lang, $_POST['change_m']);
         
        if ($distance <= $_POST['change_mv'] && $recoreds['CertificationStatus'] == 'Active') {
            $placename = $recoreds['Name'];
            $placename = str_replace("'s", '%27', $placename);
            $coords[] = array(
                'lat' => $lat,
                'lng' => $lang,
                'place' => $placename
            );
            
            $listing_dis[]=array('Name'=>$recoreds['Name'],'Address'=>$recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'],'Certificate'=>$recoreds['CertificationStatus'].'<br/>'. $recoreds['CertificationType'],'main_dis'=>number_format((float) $distance, 2, '.', ''),'distance'=>number_format((float) $distance, 2, '.', '') . $_POST['change_m'],'link'=>'<a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=11">More Info</a>');        
            
            
    //         $msg.='<div class="tr">
    //     <div class="td checkbox_box"><input type="checkbox" name="filter_single_loc[]"><span class="checkmark"></span></div>
    //     <div class="td">' . $recoreds['Name'] . '</div>
    //     <div class="td">' . $recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
    //     <div class="td">'  .$recoreds['CertificationStatus'].'<br/>'. $recoreds['CertificationType'].'</div>
    //     <div class="td">' . number_format((float) $distance, 2, '.', '') . $_POST['change_m'] . '</div>
    //     <div class="td last_col"><a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=11">More Info</a></div>
    //   </div>';
        }
    }
    
    //print_r($listing_dis);
   // usort($listing_dis, 'sortBydisgeo');
    usort($listing_dis, function($a, $b) { return $b['main_dis'] < $a['main_dis'] ;});
    foreach($listing_dis as $list){
                  $msg.='<div class="tr">
        <div class="td checkbox_box"><input type="checkbox" name="filter_single_loc[]"><span class="checkmark"></span></div>
        <div class="td">' . $list['Name'] . '</div>
        <div class="td">' . $list['Address']. '</div>
        <div class="td">'  .$list['Certificate'].'</div>
        <div class="td">' . $list['distance']. '</div>
        <div class="td last_col">'.$list['link'].'</div>
      </div>';
    }
    
    
    if (empty($coords)) {
        $msg.='<h2>No records found.</h2>';
    }
    $msg.='</div></div>';


    $msg.='<div class="location_data mobile_view table">';
    $msg.='<div class="thead">
      <div class="tr">
        <div class="th select_all"><span class="not_checked">Select All</span></div>
        <div class="th">Company Information</div>
       
      </div>
    </div><div class="table_content">';
    foreach ($response['records'] as $recoreds) {
        $lat = $recoreds['Latitude'];
        $lang = $recoreds['Longitude'];
        $distance = distance($_POST['latitude'], $_POST['longitude'], $lat, $lang, $_POST['change_m']);
        if ($distance <= $_POST['change_mv'] && $recoreds['CertificationStatus'] == 'Active') {

            $msg.='<div class="tr">
        <div class="td checkbox_box"><input type="checkbox" name="filter_single_loc[]"><span class="checkmark"></span></div>
        <div class="td"><div class="c_name">' . $recoreds['Name'] . '</div>
        <div class="address">' . $recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
        <div class="status">Status: ' . $recoreds['CertificationType'] . '</div>
        <div class="distance">' . number_format((float) $distance, 2, '.', '') . $_POST['change_m'] . '</div>
        <div class="more_info"><a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=11">More Info</a></div>
        </div>
      </div>';
        }
    }
    if (empty($coords)) {
        $msg.='<h2>No records found.</h2>';
    }
    $msg.='</div></div>';


    my_js_variables($coords);
    echo $msg;
    exit;
}

add_action("wp_ajax_filter_by_address", "filter_by_address_callbabk");
add_action("wp_ajax_nopriv_filter_by_address", "filter_by_address_callbabk");

function filter_by_address_callbabk() {
    $result = wp_cache_get('r2_facilities_curl');
    if (false === $result) {
        set_data_in_cache();
        $response = wp_cache_get('r2_facilities_curl');
    } else {
        $response = wp_cache_get('r2_facilities_curl');
    }
    // if (get_user_meta(1, 'access_token', true) && get_user_meta(1, 'expires', true)) {
    //     $token = get_user_meta(1, 'access_token', true);
    //     $exp = get_user_meta(1, 'expires', true);
    //     $rfc_1123_date = gmdate('D, d M Y H:i:s T', time());
    //     $date1 = date_create($rfc_1123_date);
    //     $date2 = date_create($exp);
    //     $diff = date_diff($date1, $date2);
    //     if ($diff->h <= 1) {
    //         get_access_token_seri();
    //         $token = get_user_meta(1, 'access_token', true);
    //         $exp = get_user_meta(1, 'expires', true);
    //     } else {
    //         $token = get_user_meta(1, 'access_token', true);
    //         $exp = get_user_meta(1, 'expires', true);
    //     }
    // } else {
    //     get_access_token_seri();
    //     $token = get_user_meta(1, 'access_token', true);
    //     $exp = get_user_meta(1, 'expires', true);
    // }
    // $curl = curl_init();
    // $string = 'country=' . str_replace(' ','%20',$_POST['country']); . '&state=' . str_replace(' ','%20',$_POST['state']).'&distance='.$_POST['measurements_value'];
    // curl_setopt_array($curl, array(
    //     CURLOPT_URL => "http://seri.stage.empiricaledge.com/api/sfdata/FilterSFData?" . $string,
    //     CURLOPT_RETURNTRANSFER => true,
    //     CURLOPT_ENCODING => "",
    //     CURLOPT_MAXREDIRS => 10,
    //     CURLOPT_TIMEOUT => 0,
    //     CURLOPT_FOLLOWLOCATION => true,
    //     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    //     CURLOPT_CUSTOMREQUEST => "GET",
    //     CURLOPT_HTTPHEADER => array(
    //         "Authorization: Bearer " . $token,
    //     ),
    // ));
    //  $response = curl_exec($curl);
    // curl_close($curl);

    $curl = curl_init();
    $string = str_replace(' ', '+', $_POST['address']) . ',' . str_replace(' ', '+', $_POST['city']) . ',' . str_replace(' ', '+', $_POST['state']) . ',' . str_replace(' ', '+', $_POST['country']);

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://maps.googleapis.com/maps/api/geocode/json?address=$string&key=" . get_option('g_api'),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
    ));

    $response_geo = curl_exec($curl);

    curl_close($curl);
    $response_geo = json_decode($response_geo, true);
// echo '<pre>';
// print_r($response_geo);
    if ($_POST['change_m']) {
        $in_term = $_POST['change_m'];
        $in_range = $_POST['change_mv'];
    } else {
        $in_term = $_POST['measurements'];
        $in_range = $_POST['measurements_value'];
    }
    $lat = $response_geo['results'][0]['geometry']['location']['lat'];
    $long = $response_geo['results'][0]['geometry']['location']['lng'];

    $response = json_decode($response, true);
    //echo "<pre>";
    //print_r($response['records']);
    $msg = '';

    $msg.='<div class="location_data desktop_view table">';
    $msg.='<div class="thead">
      <div class="tr">
        <div class="th select_all"><span class="not_checked">Select All</span></div>
        <div class="th">Company</div>
        <div class="th">Address</div>
        <div class="th">Status, <br/> cert type</div>
        <div class="th">Distance</div>
        <div class="th last_col"></div>
      </div>
    </div><div class="table_content">';
    foreach ($response['records'] as $key=>$recoreds) {

                $distance = distance($lat, $long, $recoreds['Latitude'], $recoreds['Longitude'], $in_term);
                if ($distance <= $in_range && $recoreds['CertificationStatus']=='Active') {
                    $placename = $recoreds['Name'];
                    $placename = str_replace("'", '%27', $placename);
                    $coords[] = array(
                        'lat' => $recoreds['Latitude'],
                        'lng' => $recoreds['Longitude'],
                        'place' => $placename
                    );
                    
                    
                    $offsets [$key]=array(
                        'name'=>$recoreds['Name'],  
                        'street'=>$recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'],
                        'certificate'=>$recoreds['CertificationStatus'].'<br/>'. $recoreds['CertificationType'],
                        'distance'=>number_format((float) $distance, 2, '.', '') . $in_term,
                        'distance_flot'=>number_format((float) $distance, 2, '.', ''),
                        'more_info_url'=>$recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=12',
                    ) ;
                    
                    
                    
                    // $msg.='<div class="tr">
                    //          <div class="td checkbox_box"><input type="checkbox" name="filter_single_loc[]"><span class="checkmark"></span></div>
                    //         <div class="td">' . $recoreds['Name'] . '</div>
                    //         <div class="td">' . $recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
                    //         <div class="td">' .$recoreds['CertificationStatus'].'<br/>'. $recoreds['CertificationType'] . '</div>
                    //         <div class="td">' . number_format((float) $distance, 2, '.', '') . $in_term . '</div>
                    //         <div class="td last_col"><a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=12">More Info</a></div>
                    //       </div>';
                }
               
    }
    
function cmp($a, $b) {
  return $a['distance_flot'] > $b['distance_flot'];
}
usort($offsets, "cmp");

foreach($offsets as $listed_info){
    
    $msg.='<div class="tr">
                             <div class="td checkbox_box"><input type="checkbox" name="filter_single_loc[]"><span class="checkmark"></span></div>
                            <div class="td">' . $listed_info['name'] . '</div>
                            <div class="td">' . $listed_info['street']. '</div>
                            <div class="td">' .$listed_info['certificate'].'</div>
                            <div class="td">' .$listed_info['distance']. '</div>
                            <div class="td last_col"><a class="more_info_click" data-appid="' . $listed_info['more_info_url'] .'">More Info</a></div>
                          </div>'; 
    
}

    //  echo "<pre>";
    //     print_r($offsets);
    
    if (empty($coords)) {
        $msg.='<h2>No records found.</h2>';
    }
    $msg.='</div></div>';


    $msg.='<div class="location_data mobile_view  table">';
    $msg.='<div class="thead">
      <div class="tr">
        <div class="th select_all"><span class="not_checked">Select All</span></div>
        <div class="th">Company Information</div>
      </div>
    </div><div class="table_content">';
    foreach ($response['records'] as $recoreds) {
                $distance = distance($lat, $long, $recoreds['Latitude'], $recoreds['Longitude'], $in_term);
                if ($distance <= $in_range  && $recoreds['CertificationStatus']=='Active') {
                    $msg.='<div class="tr">
                    <div class="td checkbox_box"><input type="checkbox" name="filter_single_loc[]"><span class="checkmark"></span></div>
                    <div class="td"><div class="c_name">' . $recoreds['Name'] . '</div><div class="address">' . $recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
                    <div class="status">Status: ' . $recoreds['CertificationType'] . '</div><div class="distance">Distance: ' . number_format((float) $distance, 2, '.', '') . $in_term . '</div>
                    <div class="more_info"><a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=12">More Info</a></div></div>
                  </div>';
                }
    }
    if (empty($coords)) {
        $msg.='<h2>No records found.</h2>';
    }
    $msg.='</div></div>';
    echo $msg;
    my_js_variables($coords);
    exit;
}

add_action("wp_ajax_display_certified_facility", "display_certified_facility_callbabk");
add_action("wp_ajax_nopriv_display_certified_facility", "display_certified_facility_callbabk");

function display_certified_facility_callbabk() {
    $result = wp_cache_get('r2_facilities_curl');
    if (false === $result) {
        set_data_in_cache();
        $response = wp_cache_get('r2_facilities_curl');
    } else {
        $response = wp_cache_get('r2_facilities_curl');
    }
    $response = json_decode($response, true);
    
    $output = '';
     
      $print_header = get_option('print_header', true);
      $print_header = html_entity_decode($print_header);
      $print_header = stripslashes($print_header);
     $output.='<div class="more_information_print table_content"><div class="print_header" style="display:none;">'.$print_header.'</div>';
//$ab=array_merge(array('HTTP_HOST'=>null, 'REQUEST_URI'=>null, 'HTTP_REFERER'=>null), $_SERVER);


    $url_components = parse_url($_SERVER['HTTP_REFERER']);
    parse_str($url_components['query'], $params);


    $get_allselected_ids = explode(',', $params['appids']);

    foreach ($get_allselected_ids as $s_id) {

        $output.='<div class="facilities_main">';
        foreach ($response['records'] as $result) {
            if ($result['AccountId'] == $s_id) {
                $output.='<div class="address_info">';
                $output.='<b>' . $result['Name'] . '</b>';
                $output.='<p>' . $result['FacilityAlias'] . '</p>';
                $output.='<p>' . $result['Street'] . '</p>';
                $output.='<p>' .$result['City'].', '. $result['State'].', '.$result['PostalCode']. '</p>';
               
                $output.='<p>' . $result['Country'] . '</p>';
                $output.='<p>' . $result['Region'] . '</p>';
                if (substr($result['Website'], 0, 7) == "http://" || substr($result['Website'], 0, 8) == "https://"){
                    $output.='<p><a href="' . $result['Website'] . '">' . $result['Website'] . '</a></p></div>';
                }
                else{
                    $output.='<p><a href="http://' . $result['Website'] . '">' . $result['Website'] . '</a></p></div>';
                }
                

                $output.='<div class="facility_info">';
                $output.='<h4>Facility Info</h4>';
                
                if($result['CertificationType'] == 'R2v3'){
                
                //$output.='<div class="detail_info"><p>Facility specialties :<div class="facilities_info_text">Lorem Ipsum is simply dummy text of the printing and typesetting industry.
               // Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</div></p></div>';
                $output.='<div class="detail_info"><p>Certified Processes :<div class="facilities_info_text process_info">';
                    // if($result['AppendixA']==true || $result['AppendixBLogicalErasure']==true || $result['AppendixBPhysicalDest']==true || $result['AppendixC']==true || $result['AppendixD']==true || $result['AppendixE']==true || $result['AppendixF']==true ){
                        $output.='<div class="certified_process"><label>Appendix</label><label>Certified Processes</label><label>Certified</label></div>';
                        
                        if($result['AppendixA']==true){
                            $output.='<label class="process_name green_status"><font><span class="appendix">A</span> Downstream Recycling chain<span class="appendix">YES<span></font></label>';
                        }else{
                             $output.='<label class="process_name red_status"><font><span class="appendix">A</span> Downstream Recycling chain<span class="appendix">NO<span></font></label>';
                        }
                        if($result['AppendixBLogicalErasure']==true){
                            $output.='<label class="process_name green_status"><font><span class="appendix">B</span> Logical Data Erasure<span class="appendix">Yes<span></font></label>';
                        }else{
                            $output.='<label class="process_name red_status"><font><span class="appendix">B</span> Logical Data Erasure<span class="appendix">NO<span></font></label>';
                        }
                        if($result['AppendixBPhysicalDest']==true){
                            $output.='<label class="process_name green_status"><font><span class="appendix">B</span> Physical Destruction<span class="appendix">Yes<span></font></label>';
                        }else{
                            $output.='<label class="process_name red_status"><font><span class="appendix">B</span> Physical Destruction<span class="appendix">NO<span></font></label>';
                        }
                        if($result['AppendixC']==true){
                            $output.='<label class="process_name green_status"><font><span class="appendix">C</span> Test & Repair<span class="appendix">Yes<span></font></label>';
                        }else{
                            $output.='<label class="process_name red_status"><font><span class="appendix">C</span> Test & Repair<span class="appendix">NO<span></font></label>';
                        }
                        if($result['AppendixD']==true){
                            $output.='<label class="process_name green_status"><font><span class="appendix">D</span> Specialty Equipment<span class="appendix">Yes<span></font></label>';
                        }else{
                            $output.='<label class="process_name red_status"><font><span class="appendix">D</span> Specialty Equipment<span class="appendix">NO<span></font></label>';
                        }
                        if($result['AppendixE']==true){
                            $output.='<label class="process_name green_status"><font><span class="appendix">E</span> Materials Recovery<span class="appendix">Yes<span></font></label>';
                        }else{
                            $output.='<label class="process_name red_status"><font><span class="appendix">E</span> Materials Recovery<span class="appendix">NO<span></font></label>';
                        }
                        if($result['AppendixF']==true){
                            $output.='<label class="process_name green_status"><font><span class="appendix">F</span> Brokering<span class="appendix">Yes<span></font></label>';
                        }else{
                            $output.='<label class="process_name red_status"><font><span class="appendix">F</span> Brokering<span class="appendix">NO<span></font></label>';
                        }
                        
                    // }
                    // else{
                    //   $output.='<p>No records found.</p>'; 
                    // }
                $output.='</div> </p></div>';
                }
                
                if($result['DropOff']==true){
                    $dropoff="True";
                }
                else{
                     $dropoff="False";
                }
                if($result['CampusCertification']==true){
                    $CampusCertification="True";
                }
                else{
                     $CampusCertification="False";
                }
                
                if($result['InitialCertificationDate'] == ''){
                    $InitialCertificationDate='';
                }else{
                    $InitialCertificationDate=date("d/m/Y", strtotime($result['InitialCertificationDate']));
                }
                
                if($result['LastCertStatusChangeDate'] == ''){
                    $last_change_date='';
                }else{
                    $last_change_date=date("d/m/Y", strtotime($result['LastCertStatusChangeDate']));
                }
                
                if($result['ExpirationDate'] == ''){
                    $ExpirationDate='';
                }else{
                    $ExpirationDate=date("d/m/Y", strtotime($result['ExpirationDate']));
                }
                
                
                $output.='<div class="detail_info"><p>Scope :<div class="facilities_info_text">'.$result['R2Scope'].'</div> </p></div>';
                $output.='<div class="detail_info"><p>Public drop off location :<div class="facilities_info_text"> ' . $dropoff . '</div></p></div>';
                $output.='</div>';
                
                $output.='<div class="certification_info">';
                $output.='<h4>Certification Info</h4>';
                $output.='<div class="detail_info"><p>Current Certification status :<div class="facilities_info_text"> ' . $result['CertificationStatus'] . '</div></p></div>';
                $output.='<div class="detail_info"><p>Certification type :<div class="facilities_info_text"> ' . $result['CertificationType'] . '</div></p></div>';
                $output.='<div class="detail_info"><p>Campus scheme :<div class="facilities_info_text">'.$CampusCertification.'</div></p></div>';
                $output.='<div class="detail_info"><p>Certification  body :<div class="facilities_info_text"> ' . $result['CertifyingBodyName'] . '</div></p></div>';
                $output.='<div class="detail_info"><p>Certification number :<div class="facilities_info_text"> ' . $result['CertificationNumber'] . '</div></p></div>';
                $output.='<div class="detail_info"><p>Initial certification  date :<div class="facilities_info_text"> ' . $InitialCertificationDate . '</div></p></div>';
                $output.='<div class="detail_info"><p>Expiration date :<div class="facilities_info_text"> ' . $ExpirationDate . '</div></p></div>';
                $output.='<div class="detail_info"><p>Last change date :<div class="facilities_info_text"> ' . $last_change_date . '</div></p></div>';
                $output.='</div>';
            }
        }
        $output.='</div>';
    }
      $output.='</div>';
    echo $output;
    die;
}

//Dowload list on map page start//


add_action("wp_ajax_download_xls_file", "download_xls_file_callbabk");
add_action("wp_ajax_nopriv_download_xls_file", "download_xls_file_callbabk");

function download_xls_file_callbabk() {
    $spreadsheet = new PhpOffice\PhpSpreadsheet\Spreadsheet();

    $from = "H1"; // or any value
    $to = "T2"; // or any value

    $spreadsheet->getActiveSheet()->mergeCells('H1:T2');

    $styleArray = [
        'font' => [
            'bold' => true,
        ],
        'alignment' => [
            'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
        ],
    ];
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->getFont()->setSize(16);
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->applyFromArray($styleArray);
    $sheet = $spreadsheet->getActiveSheet(0);
    $spreadsheet->getActiveSheet()->setCellValue('H1', 'Company Details');
    $t = 4;
    $sheet->setCellValue('A' . $t, 'Sr No.');
    $sheet->setCellValue('B' . $t, 'Company');
    $sheet->setCellValue('C' . $t, 'Address');
    $sheet->setCellValue('D' . $t, 'Website');
    // $sheet->setCellValue('E' . $t, 'Facility specialties');
    $sheet->setcellValue('E' . $t,'Certified Process Requirements');
    $sheet->setcellValue('F' . $t,'Scope');
    $sheet->setcellValue('G' . $t,'Public drop off location');
    $sheet->setcellValue('H' . $t,'Current Certification status');
    $sheet->setcellValue('I' . $t,'Certification type');
    $sheet->setcellValue('J' . $t,'Campus scheme');
    $sheet->setcellValue('K' . $t,'Certification body');
    $sheet->setcellValue('L' . $t,'Certification number');
    $sheet->setcellValue('M' . $t,'Initial certification date');
    $sheet->setcellValue('N' . $t,'Expiration date');
    $sheet->setcellValue('O' . $t,'Last change date');
    

    $from = "A4"; // or any value
    $to = "P4"; // or any value
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->getFont()->setSize(11);

    $data_ids = explode(',', $_POST['ac_ids']);

    $data_ids = array_unique($data_ids);
    $result = wp_cache_get('r2_facilities_curl');
    if (false === $result) {
        set_data_in_cache();
        $response = wp_cache_get('r2_facilities_curl');
    } else {
        $response = wp_cache_get('r2_facilities_curl');
    }
    $response = json_decode($response, true);

    $i = 5;
    $j = 1;
    foreach ($data_ids as $id) {

        foreach ($response['records'] as $recoreds) {
            if ($id == $recoreds['AccountId']) {
                $name = $recoreds['Name'];
                $address = $recoreds['Street'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'];
                $type = $recoreds['CertificationType'];
                $cert_status = $recoreds['CertificationStatus'];
                
                
                 $output=array();
                
                if($recoreds['AppendixA']==true || $recoreds['AppendixBLogicalErasure']==true || $recoreds['AppendixBPhysicalDest']==true || $recoreds['AppendixC']==true || $recoreds['AppendixD']==true || $recoreds['AppendixE']==true || $recoreds['AppendixF']==true ){
                        if($recoreds['AppendixA']==true){
                            $output[]='A Downstream Recycling chain';
                        }
                        $output[]='B Logical Data Erasure';
                        if($recoreds['AppendixBLogicalErasure']==true){
                            $output[]='B Logical Data Erasure';
                        }
                        if($recoreds['AppendixBPhysicalDest']==true){
                            $output[]='B Physical Destruction';
                        }
                        if($recoreds['AppendixC']==true){
                            $output[]='C Test & Repair';
                        }
                        if($recoreds['AppendixD']==true){
                            $output[]='D Specialty Equipment';
                        }
                        if($recoreds['AppendixE']==true){
                            $output[]='E Materials Recovery';
                        }
                        if($recoreds['AppendixF']==true){
                            $output[]='F Brokering';
                        }
                        
                        $Certified_Processes=implode(',',$output);
                        
                    }
                    else{
                       $Certified_Processes.=''; 
                    }
                
                
                
                
                
                
                if($recoreds['DropOff'] == true){
                   $DropOff= $recoreds['DropOff'];
                }
                else{
                    $DropOff= "";
                } 
                
                if($recoreds['CampusCertification'] == true){
                   $CampusCertification= $recoreds['CampusCertification'];
                }
                else{
                    $CampusCertification= "";
                } 
                
                
                if(!is_null($recoreds['InitialCertificationDate'])){
                   $in_date= date("d/m/Y", strtotime($recoreds['InitialCertificationDate']));
                }
                else{
                    $in_date= "";
                }
                if(!is_null($recoreds['ExpirationDate'])){
                    $exp_d=date("d/m/Y", strtotime($recoreds['ExpirationDate']));
                }
                else{
                    $exp_d= "";
                }
                 if(!is_null($recoreds['LastCertStatusChangeDate'])){
                    $last_d=date("d/m/Y", strtotime($recoreds['LastCertStatusChangeDate']));
                }
                else{
                    $last_d= "";
                }
                $sheet->setCellValue('A' . $i, $j);
                $sheet->setCellValue('B' . $i, $name);
                $sheet->setCellValue('C' . $i, $address);
                $sheet->setCellValue('D' . $i, $recoreds['Website']);
                //$sheet->setCellValue('E' . $i, "");
                $sheet->setcellValue('E' . $i,$Certified_Processes);
                $sheet->setcellValue('F' . $i,$recoreds['R2Scope']);
                $sheet->setcellValue('G' . $i,$DropOff);
                $sheet->setcellValue('H' . $i, $cert_status);
                $sheet->setcellValue('I' . $i, $type);
                $sheet->setcellValue('J' . $i,$CampusCertification);
                $sheet->setcellValue('K' . $i,$recoreds['CertifyingBodyName']);
                $sheet->setcellValue('L' . $i,$recoreds['CertificationNumber']);
                $sheet->setcellValue('M' . $i,$in_date);
                $sheet->setcellValue('N' . $i,$exp_d);
                $sheet->setcellValue('O' . $i,$last_d);
                
                $i++;
                $j++;
            }
        }
    }
    ob_clean();
    header('Pragma: public');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Cache-Control: private', false);
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename=selected-facilities.xlsx');
    $spreadsheet->setActiveSheetIndex(0);
    $writer = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    $writer->save(WP_PLUGIN_DIR .'/find-facilities/vendor/selected-facilities.xlsx');
    $url = FIND_FACILITIES_PLUGIN_URL . '/vendor/selected-facilities.xlsx';
    echo $url;
    exit();
}

add_action('wp_ajax_download_features_xls', 'download_features_xls_callback');
add_action('wp_ajax_nopriv_download_features_xls', 'download_features_xls_callback');

function download_features_xls_callback() {
    $spreadsheet = new PhpOffice\PhpSpreadsheet\Spreadsheet();

    $from = "H1"; // or any value
    $to = "T2"; // or any value

    $spreadsheet->getActiveSheet()->mergeCells('H1:T2');

    $styleArray = [
        'font' => [
            'bold' => true,
        ],
        'alignment' => [
            'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
        ],
    ];
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->getFont()->setSize(16);
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->applyFromArray($styleArray);
    $sheet = $spreadsheet->getActiveSheet(0);
    $spreadsheet->getActiveSheet()->setCellValue('H1', 'Company Details');
    $t = 4;
    $sheet->setCellValue('A' . $t, 'Sr No.');
    $sheet->setCellValue('B' . $t, 'Company');
    $sheet->setCellValue('C' . $t, 'Address');
    $sheet->setCellValue('D' . $t, 'Website');
    // $sheet->setCellValue('E' . $t, 'Facility specialties');
    $sheet->setcellValue('E' . $t,'Certified Process Requirements');
    $sheet->setcellValue('F' . $t,'Scope');
    $sheet->setcellValue('G' . $t,'Public drop off location');
    $sheet->setcellValue('H' . $t,'Current Certification status');
    $sheet->setcellValue('I' . $t,'Certification type');
    $sheet->setcellValue('J' . $t,'Campus scheme');
    $sheet->setcellValue('K' . $t,'Certification body');
    $sheet->setcellValue('L' . $t,'Certification number');
    $sheet->setcellValue('M' . $t,'Initial certification date');
    $sheet->setcellValue('N' . $t,'Expiration date');
    $sheet->setcellValue('O' . $t,'Last change date');

    $from = "A4"; // or any value
    $to = "P4"; // or any value
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->getFont()->setBold(true);
    $spreadsheet->getActiveSheet()->getStyle("$from:$to")->getFont()->setSize(11);

    if (get_user_meta(1, 'access_token', true) && get_user_meta(1, 'expires', true)) {

        $token = get_user_meta(1, 'access_token', true);
        $exp = get_user_meta(1, 'expires', true);
        $rfc_1123_date = gmdate('D, d M Y H:i:s T', time());
        $date1 = date_create($rfc_1123_date);
        $date2 = date_create($exp);
        $diff = date_diff($date1, $date2);
        if ($diff->h <= 1) {
            get_access_token_seri();
            $token = get_user_meta(1, 'access_token', true);
            $exp = get_user_meta(1, 'expires', true);
        } else {
            $token = get_user_meta(1, 'access_token', true);
            $exp = get_user_meta(1, 'expires', true);
        }
    } else {
        get_access_token_seri();
        $token = get_user_meta(1, 'access_token', true);
        $exp = get_user_meta(1, 'expires', true);
    }
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'http://seriapi.azurewebsites.net/api/sfdata/FilterByFacility',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer " . $token,
        ),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $response = json_decode($response, true);
    $data_ids = explode(',', $_POST['ac_ids']);
    $data_ids = array_unique($data_ids);
    
    $i = 5;
    $j = 1;
    foreach ($data_ids as $id) {
        foreach ($response['records'] as $recoreds) {
            if ($id == $recoreds['AccountId']) {
                $name = $recoreds['Name'];
                $address = $recoreds['Street'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'];
                $type = $recoreds['CertificationType'];
                $cert_status = $recoreds['CertificationStatus'];
                $output=array();
                
                if($recoreds['AppendixA']==true || $recoreds['AppendixBLogicalErasure']==true || $recoreds['AppendixBPhysicalDest']==true || $recoreds['AppendixC']==true || $recoreds['AppendixD']==true || $recoreds['AppendixE']==true || $recoreds['AppendixF']==true ){
                        if($recoreds['AppendixA']==true){
                            $output[]='A Downstream Recycling chain';
                        }
                        $output[]='B Logical Data Erasure';
                        if($recoreds['AppendixBLogicalErasure']==true){
                            $output[]='B Logical Data Erasure';
                        }
                        if($recoreds['AppendixBPhysicalDest']==true){
                            $output[]='B Physical Destruction';
                        }
                        if($recoreds['AppendixC']==true){
                            $output[]='C Test & Repair';
                        }
                        if($recoreds['AppendixD']==true){
                            $output[]='D Specialty Equipment';
                        }
                        if($recoreds['AppendixE']==true){
                            $output[]='E Materials Recovery';
                        }
                        if($recoreds['AppendixF']==true){
                            $output[]='F Brokering';
                        }
                        
                        $Certified_Processes=implode(',',$output);
                        
                    }
                    else{
                       $Certified_Processes.=''; 
                    }
                
                
                
                
                
                
                
                if($recoreds['DropOff'] == true){
                   $DropOff= $recoreds['DropOff'];
                }
                else{
                    $DropOff= "";
                } 
                
                if($recoreds['CampusCertification'] == true){
                   $CampusCertification= $recoreds['CampusCertification'];
                }
                else{
                    $CampusCertification= "";
                } 
            

               if(!is_null($recoreds['InitialCertificationDate'])){
                   $in_date= date("d/m/Y", strtotime($recoreds['InitialCertificationDate']));
                }
                else{
                    $in_date= "";
                }
                if(!is_null($recoreds['ExpirationDate'])){
                    $exp_d=date("d/m/Y", strtotime($recoreds['ExpirationDate']));
                }
                else{
                    $exp_d= "";
                }
                 if(!is_null($recoreds['LastCertStatusChangeDate'])){
                    $last_d=date("d/m/Y", strtotime($recoreds['LastCertStatusChangeDate']));
                }
                else{
                    $last_d= "";
                }
                $sheet->setCellValue('A' . $i, $j);
                $sheet->setCellValue('B' . $i, $name);
                $sheet->setCellValue('C' . $i, $address);
                $sheet->setCellValue('D' . $i, $recoreds['Website']);
                $sheet->setCellValue('E' . $i, $Certified_Processes);
                // $sheet->setcellValue('F' . $i,"");
                $sheet->setcellValue('F' . $i,$recoreds['R2Scope']);
                $sheet->setcellValue('G' . $i,$DropOff);
                $sheet->setcellValue('H' . $i, $cert_status);
                $sheet->setcellValue('I' . $i, $type);
                $sheet->setcellValue('J' . $i,$CampusCertification);
                $sheet->setcellValue('K' . $i,$recoreds['CertifyingBodyName']);
                $sheet->setcellValue('L' . $i,$recoreds['CertificationNumber']);
                $sheet->setcellValue('M' . $i,$in_date);
                $sheet->setcellValue('N' . $i,$exp_d);
                $sheet->setcellValue('O' . $i,$last_d);
                
                $i++;
                $j++;
            }
        }
    }
    ob_clean();
    header('Pragma: public');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Cache-Control: private', false);
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename=selected-features.xlsx');
    $spreadsheet->setActiveSheetIndex(0);
    $writer = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    $writer->save(WP_PLUGIN_DIR .'/find-facilities/vendor/selected-features.xlsx');
    $url = FIND_FACILITIES_PLUGIN_URL . '/vendor/selected-features.xlsx';
    echo $url;
    exit();
}

add_action('wp_ajax_get_country', 'get_country_callback');
add_action('wp_ajax_nopriv_get_country', 'get_country_callback');

function get_country_callback() {

    $GetPicklistValues = wp_cache_get('GetPicklistValues');
    if (false === $GetPicklistValues) {
        set_data_in_cache();
        $GetPicklistValues = wp_cache_get('GetPicklistValues');
    } else {
        $GetPicklistValues = wp_cache_get('GetPicklistValues');
    }
    if ($GetPicklistValues) {
        $GetPicklistValues = $GetPicklistValues['records'];
    }
    $html = '';
    $html.='<option value="" disable>Country</option>';
     usort($GetPicklistValues, 'sortByOrder_country');
     
    foreach ($GetPicklistValues as $country) {
        if (!in_array(strtolower($country['BillingCountry']), $country_data)) {
            if ($_POST['country']){
                if ($_POST['country'] == $country['Region__c']) {
                    $country_data[] = strtolower($country['BillingCountry']);
                    $html.='<option value="' . $country['BillingCountry'] . '">' . $country['BillingCountry'] . '</option>';
                    }
                }
            else{
                 $country_data[] = strtolower($country['BillingCountry']);
                $html.='<option value="' . $country['BillingCountry'] . '">' . $country['BillingCountry'] . '</option>';
            }
        }
    }
    echo $html;
    exit();
}

add_action('wp_ajax_getState', 'getStates_callback');
add_action('wp_ajax_nopriv_getState', 'getStates_callback');

function getStates_callback() {
    $GetPicklistValues = wp_cache_get('GetPicklistValues');
    if (false === $GetPicklistValues) {
       
        set_data_in_cache();
        $GetPicklistValues = wp_cache_get('GetPicklistValues');
    } else {
        $GetPicklistValues = wp_cache_get('GetPicklistValues');
    }
    if ($GetPicklistValues) {
        $GetPicklistValues = $GetPicklistValues['records'];
    }
    usort($GetPicklistValues,'sortByOrder_states');
    $html = '';
    $html.='<option value="" disable>State/Province</option>';
    foreach ($GetPicklistValues as $state) {
        if (!in_array(strtolower($state['BillingState']), $state_data)) {
            if ($_POST['country'] == $state['BillingCountry']) {
                $state_data[] = strtolower($state['BillingState']);
                $html.='<option value="' . $state['BillingState'] . '">' . $state['BillingState'] . '</option>';
            }
        }
    }
    echo $html;
    exit();
}

add_action('wp_ajax_getCityTown', 'getCityTown_callback');
add_action('wp_ajax_nopriv_getCityTown', 'getCityTown_callback');

function getCityTown_callback() {
    $GetPicklistValues = wp_cache_get('GetPicklistValues');
    if (false === $GetPicklistValues) {
        set_data_in_cache();
        $GetPicklistValues = wp_cache_get('GetPicklistValues');
    } else {
        $GetPicklistValues = wp_cache_get('GetPicklistValues');
    }
    if ($GetPicklistValues) {
        $GetPicklistValues = $GetPicklistValues['records'];
    }
     usort($GetPicklistValues,'sortByOrder_city');
    $html = '';
    $html.='<option value="" disable>City/Town</option>';
    foreach ($GetPicklistValues as $state) {
        if (!in_array(strtolower($state['BillingCity']), $state_data)) {
            if ($_POST['country'] == $state['BillingState']) {
                $state_data[] = strtolower($state['BillingCity']);
                $html.='<option value="' . $state['BillingCity'] . '">' . $state['BillingCity'] . '</option>';
            }
        }
    }
    echo $html;
    exit();
}

//Dowload list on map page end//
// Get state from country start//
add_action('wp_ajax_get_states', 'get_states_callback');
add_action('wp_ajax_nopriv_get_states', 'get_states_callback');

function get_states_callback() {


    $GetPicklistValues = wp_cache_get('GetPicklistValues');
    if (false === $GetPicklistValues) {
        set_data_in_cache();
        $GetPicklistValues = wp_cache_get('GetPicklistValues');
    } else {
        $GetPicklistValues = wp_cache_get('GetPicklistValues');
    }
    if ($GetPicklistValues) {
        $GetPicklistValues = $GetPicklistValues['records'];
    }
    usort($GetPicklistValues,'sortByOrder_states');
    $html = '';
    $html.='<option value="" disable>State/Province</option>';
    $country_name=$_POST['country'];
    global $wpdb;
    $table_name = $wpdb->prefix . "country_facilities";
    $user_country = $wpdb->get_results( "SELECT state_name FROM $table_name WHERE country_name='$country_name'" );
    $list_state=explode(',',$user_country[0]->state_name);
    foreach($list_state as $state){
        $html.='<option value="' . $state . '">' . $state . '</option>';
    }
    
    $json='{
   "countries": [
      {
         "country": "Afghanistan",
         "states": [
            "Badakhshan",
            "Badghis",
            "Baghlan",
            "Balkh",
            "Bamian",
            "Daykondi",
            "Farah",
            "Faryab",
            "Ghazni",
            "Ghowr",
            "Helmand",
            "Herat",
            "Jowzjan",
            "Kabul",
            "Kandahar",
            "Kapisa",
            "Khost",
            "Konar",
            "Kondoz",
            "Laghman",
            "Lowgar",
            "Nangarhar",
            "Nimruz",
            "Nurestan",
            "Oruzgan",
            "Paktia",
            "Paktika",
            "Panjshir",
            "Parvan",
            "Samangan",
            "Sar-e Pol",
            "Takhar",
            "Vardak",
            "Zabol"
         ]
      },
      {
         "country": "Albania",
         "states": [
            "Berat",
            "Dibres",
            "Durres",
            "Elbasan",
            "Fier",
            "Gjirokastre",
            "Korce",
            "Kukes",
            "Lezhe",
            "Shkoder",
            "Tirane",
            "Vlore"
         ]
      },
      {
         "country": "Algeria",
         "states": [
            "Adrar",
            "Ain Defla",
            "Ain Temouchent",
            "Alger",
            "Annaba",
            "Batna",
            "Bechar",
            "Bejaia",
            "Biskra",
            "Blida",
            "Bordj Bou Arreridj",
            "Bouira",
            "Boumerdes",
            "Chlef",
            "Constantine",
            "Djelfa",
            "El Bayadh",
            "El Oued",
            "El Tarf",
            "Ghardaia",
            "Guelma",
            "Illizi",
            "Jijel",
            "Khenchela",
            "Laghouat",
            "Muaskar",
            "Medea",
            "Mila",
            "Mostaganem",
            "MSila",
            "Naama",
            "Oran",
            "Ouargla",
            "Oum el Bouaghi",
            "Relizane",
            "Saida",
            "Setif",
            "Sidi Bel Abbes",
            "Skikda",
            "Souk Ahras",
            "Tamanghasset",
            "Tebessa",
            "Tiaret",
            "Tindouf",
            "Tipaza",
            "Tissemsilt",
            "Tizi Ouzou",
            "Tlemcen"
         ]
      },
      {
         "country": "Andorra",
         "states": [
            "Andorra la Vella",
            "Canillo",
            "Encamp",
            "Escaldes-Engordany",
            "La Massana",
            "Ordino",
            "Sant Julia de Loria"
         ]
      },
      {
         "country": "Angola",
         "states": [
            "Bengo",
            "Benguela",
            "Bie",
            "Cabinda",
            "Cuando Cubango",
            "Cuanza Norte",
            "Cuanza Sul",
            "Cunene",
            "Huambo",
            "Huila",
            "Luanda",
            "Lunda Norte",
            "Lunda Sul",
            "Malanje",
            "Moxico",
            "Namibe",
            "Uige",
            "Zaire"
         ]
      },
      {
         "country": "Antarctica",
         "states": []
      },
      {
         "country": "Antigua and Barbuda",
         "states": [
            "Barbuda",
            "Redonda",
            "Saint George",
            "Saint John",
            "Saint Mary",
            "Saint Paul",
            "Saint Peter",
            "Saint Philip"
         ]
      },
      {
         "country": "Argentina",
         "states": [
            "Buenos Aires",
            "Buenos Aires Capital",
            "Catamarca",
            "Chaco",
            "Chubut",
            "Cordoba",
            "Corrientes",
            "Entre Rios",
            "Formosa",
            "Jujuy",
            "La Pampa",
            "La Rioja",
            "Mendoza",
            "Misiones",
            "Neuquen",
            "Rio Negro",
            "Salta",
            "San Juan",
            "San Luis",
            "Santa Cruz",
            "Santa Fe",
            "Santiago del Estero",
            "Tierra del Fuego",
            "Tucuman"
         ]
      },
      {
         "country": "Armenia",
         "states": [
            "Aragatsotn",
            "Ararat",
            "Armavir",
            "Gegharkunik",
            "Kotayk",
            "Lorri",
            "Shirak",
            "Syunik",
            "Tavush",
            "Vayots Dzor",
            "Yerevan"
         ]
      },
      {
         "country": "Australia",
         "states": []
      },
      {
         "country": "Austria",
         "states": [
            "Burgenland",
            "Kaernten",
            "Niederoesterreich",
            "Oberoesterreich",
            "Salzburg",
            "Steiermark",
            "Tirol",
            "Vorarlberg",
            "Wien"
         ]
      },
      {
         "country": "Azerbaijan",
         "states": [
            "Abseron Rayonu",
            "Agcabadi Rayonu",
            "Agdam Rayonu",
            "Agdas Rayonu",
            "Agstafa Rayonu",
            "Agsu Rayonu",
            "Astara Rayonu",
            "Balakan Rayonu",
            "Barda Rayonu",
            "Beylaqan Rayonu",
            "Bilasuvar Rayonu",
            "Cabrayil Rayonu",
            "Calilabad Rayonu",
            "Daskasan Rayonu",
            "Davaci Rayonu",
            "Fuzuli Rayonu",
            "Gadabay Rayonu",
            "Goranboy Rayonu",
            "Goycay Rayonu",
            "Haciqabul Rayonu",
            "Imisli Rayonu",
            "Ismayilli Rayonu",
            "Kalbacar Rayonu",
            "Kurdamir Rayonu",
            "Lacin Rayonu",
            "Lankaran Rayonu",
            "Lerik Rayonu",
            "Masalli Rayonu",
            "Neftcala Rayonu",
            "Oguz Rayonu",
            "Qabala Rayonu",
            "Qax Rayonu",
            "Qazax Rayonu",
            "Qobustan Rayonu",
            "Quba Rayonu",
            "Qubadli Rayonu",
            "Qusar Rayonu",
            "Saatli Rayonu",
            "Sabirabad Rayonu",
            "Saki Rayonu",
            "Salyan Rayonu",
            "Samaxi Rayonu",
            "Samkir Rayonu",
            "Samux Rayonu",
            "Siyazan Rayonu",
            "Susa Rayonu",
            "Tartar Rayonu",
            "Tovuz Rayonu",
            "Ucar Rayonu",
            "Xacmaz Rayonu",
            "Xanlar Rayonu",
            "Xizi Rayonu",
            "Xocali Rayonu",
            "Xocavand Rayonu",
            "Yardimli Rayonu",
            "Yevlax Rayonu",
            "Zangilan Rayonu",
            "Zaqatala Rayonu",
            "Zardab Rayonu",
            "Ali Bayramli Sahari",
            "Baki Sahari",
            "Ganca Sahari",
            "Lankaran Sahari",
            "Mingacevir Sahari",
            "Naftalan Sahari",
            "Saki Sahari",
            "Sumqayit Sahari",
            "Susa Sahari",
            "Xankandi Sahari",
            "Yevlax Sahari",
            "Naxcivan Muxtar"
         ]
      },
      {
         "country": "Bahamas",
         "states": [
            "Acklins and Crooked Islands",
            "Bimini",
            "Cat Island",
            "Exuma",
            "Freeport",
            "Fresh Creek",
            "Governors Harbour",
            "Green Turtle Cay",
            "Harbour Island",
            "High Rock",
            "Inagua",
            "Kemps Bay",
            "Long Island",
            "Marsh Harbour",
            "Mayaguana",
            "New Providence",
            "Nichollstown and Berry Islands",
            "Ragged Island",
            "Rock Sound",
            "Sandy Point",
            "San Salvador and Rum Cay"
         ]
      },
      {
         "country": "Bahrain",
         "states": [
            "Al Hadd",
            "Al Manamah",
            "Al Mintaqah al Gharbiyah",
            "Al Mintaqah al Wusta",
            "Al Mintaqah ash Shamaliyah",
            "Al Muharraq",
            "Ar Rifa wa al Mintaqah al Janubiyah",
            "Jidd Hafs",
            "Madinat Hamad",
            "Madinat Isa",
            "Juzur Hawar",
            "Sitrah"
         ]
      },
      {
         "country": "Bangladesh",
         "states": [
            "Barisal",
            "Chittagong",
            "Dhaka",
            "Khulna",
            "Rajshahi",
            "Sylhet"
         ]
      },
      {
         "country": "Barbados",
         "states": [
            "Christ Church",
            "Saint Andrew",
            "Saint George",
            "Saint James",
            "Saint John",
            "Saint Joseph",
            "Saint Lucy",
            "Saint Michael",
            "Saint Peter",
            "Saint Philip",
            "Saint Thomas"
         ]
      },
      {
         "country": "Belarus",
         "states": [
            "Brest",
            "Homyel",
            "Horad Minsk",
            "Hrodna",
            "Mahilyow",
            "Minsk",
            "Vitsyebsk"
         ]
      },
      {
         "country": "Belgium",
         "states": [
            "Antwerpen",
            "Brabant Wallon",
            "Brussels",
            "Flanders",
            "Hainaut",
            "Liege",
            "Limburg",
            "Luxembourg",
            "Namur",
            "Oost-Vlaanderen",
            "Vlaams-Brabant",
            "Wallonia",
            "West-Vlaanderen"
         ]
      },
      {
         "country": "Belize",
         "states": [
            "Belize",
            "Cayo",
            "Corozal",
            "Orange Walk",
            "Stann Creek",
            "Toledo"
         ]
      },
      {
         "country": "Benin",
         "states": [
            "Alibori",
            "Atakora",
            "Atlantique",
            "Borgou",
            "Collines",
            "Donga",
            "Kouffo",
            "Littoral",
            "Mono",
            "Oueme",
            "Plateau",
            "Zou"
         ]
      },
      {
         "country": "Bermuda",
         "states": [
            "Devonshire",
            "Hamilton",
            "Hamilton",
            "Paget",
            "Pembroke",
            "Saint George",
            "Saint Georges",
            "Sandys",
            "Smiths",
            "Southampton",
            "Warwick"
         ]
      },
      {
         "country": "Bhutan",
         "states": [
            "Bumthang",
            "Chukha",
            "Dagana",
            "Gasa",
            "Haa",
            "Lhuntse",
            "Mongar",
            "Paro",
            "Pemagatshel",
            "Punakha",
            "Samdrup Jongkhar",
            "Samtse",
            "Sarpang",
            "Thimphu",
            "Trashigang",
            "Trashiyangste",
            "Trongsa",
            "Tsirang",
            "Wangdue Phodrang",
            "Zhemgang"
         ]
      },
      {
         "country": "Bolivia",
         "states": [
            "Chuquisaca",
            "Cochabamba",
            "Beni",
            "La Paz",
            "Oruro",
            "Pando",
            "Potosi",
            "Santa Cruz",
            "Tarija"
         ]
      },
      {
         "country": "Bosnia and Herzegovina",
         "states": [
            "Una-Sana [Federation]",
            "Posavina [Federation]",
            "Tuzla [Federation]",
            "Zenica-Doboj [Federation]",
            "Bosnian Podrinje [Federation]",
            "Central Bosnia [Federation]",
            "Herzegovina-Neretva [Federation]",
            "West Herzegovina [Federation]",
            "Sarajevo [Federation]",
            " West Bosnia [Federation]",
            "Banja Luka [RS]",
            "Bijeljina [RS]",
            "Doboj [RS]",
            "Fo?a [RS]",
            "Sarajevo-Romanija [RS]",
            "Trebinje [RS]",
            "Vlasenica [RS]"
         ]
      },
      {
         "country": "Botswana",
         "states": [
            "Central",
            "Ghanzi",
            "Kgalagadi",
            "Kgatleng",
            "Kweneng",
            "North East",
            "North West",
            "South East",
            "Southern"
         ]
      },
      {
         "country": "Brazil",
         "states": [
            "Acre",
            "Alagoas",
            "Amapa",
            "Amazonas",
            "Bahia",
            "Ceara",
            "Distrito Federal",
            "Espirito Santo",
            "Goias",
            "Maranhao",
            "Mato Grosso",
            "Mato Grosso do Sul",
            "Minas Gerais",
            "Para",
            "Paraiba",
            "Parana",
            "Pernambuco",
            "Piaui",
            "Rio de Janeiro",
            "Rio Grande do Norte",
            "Rio Grande do Sul",
            "Rondonia",
            "Roraima",
            "Santa Catarina",
            "Sao Paulo",
            "Sergipe",
            "Tocantins"
         ]
      },
      {
         "country": "Brunei",
         "states": [
            "Belait",
            "Brunei and Muara",
            "Temburong",
            "Tutong"
         ]
      },
      {
         "country": "Bulgaria",
         "states": [
            "Blagoevgrad",
            "Burgas",
            "Dobrich",
            "Gabrovo",
            "Khaskovo",
            "Kurdzhali",
            "Kyustendil",
            "Lovech",
            "Montana",
            "Pazardzhik",
            "Pernik",
            "Pleven",
            "Plovdiv",
            "Razgrad",
            "Ruse",
            "Shumen",
            "Silistra",
            "Sliven",
            "Smolyan",
            "Sofiya",
            "Sofiya-Grad",
            "Stara Zagora",
            "Turgovishte",
            "Varna",
            "Veliko Turnovo",
            "Vidin",
            "Vratsa",
            "Yambol"
         ]
      },
      {
         "country": "Burkina Faso",
         "states": [
            "Bale",
            "Bam",
            "Banwa",
            "Bazega",
            "Bougouriba",
            "Boulgou",
            "Boulkiemde",
            "Comoe",
            "Ganzourgou",
            "Gnagna",
            "Gourma",
            "Houet",
            "Ioba",
            "Kadiogo",
            "Kenedougou",
            "Komondjari",
            "Kompienga",
            "Kossi",
            "Koulpelogo",
            "Kouritenga",
            "Kourweogo",
            "Leraba",
            "Loroum",
            "Mouhoun",
            "Namentenga",
            "Nahouri",
            "Nayala",
            "Noumbiel",
            "Oubritenga",
            "Oudalan",
            "Passore",
            "Poni",
            "Sanguie",
            "Sanmatenga",
            "Seno",
            "Sissili",
            "Soum",
            "Sourou",
            "Tapoa",
            "Tuy",
            "Yagha",
            "Yatenga",
            "Ziro",
            "Zondoma",
            "Zoundweogo"
         ]
      },
      {
         "country": "Burma",
         "states": [
            "Ayeyarwady",
            "Bago",
            "Magway",
            "Mandalay",
            "Sagaing",
            "Tanintharyi",
            "Yangon",
            "Chin State",
            "Kachin State",
            "Kayin State",
            "Kayah State",
            "Mon State",
            "Rakhine State",
            "Shan State"
         ]
      },
      {
         "country": "Burundi",
         "states": [
            "Bubanza",
            "Bujumbura Mairie",
            "Bujumbura Rural",
            "Bururi",
            "Cankuzo",
            "Cibitoke",
            "Gitega",
            "Karuzi",
            "Kayanza",
            "Kirundo",
            "Makamba",
            "Muramvya",
            "Muyinga",
            "Mwaro",
            "Ngozi",
            "Rutana",
            "Ruyigi"
         ]
      },
      {
         "country": "Cambodia",
         "states": [
            "Banteay Mean Chey",
            "Batdambang",
            "Kampong Cham",
            "Kampong Chhnang",
            "Kampong Spoe",
            "Kampong Thum",
            "Kampot",
            "Kandal",
            "Koh Kong",
            "Kracheh",
            "Mondol Kiri",
            "Otdar Mean Chey",
            "Pouthisat",
            "Preah Vihear",
            "Prey Veng",
            "Rotanakir",
            "Siem Reab",
            "Stoeng Treng",
            "Svay Rieng",
            "Takao",
            "Keb",
            "Pailin",
            "Phnom Penh",
            "Preah Seihanu"
         ]
      },
      {
         "country": "Cameroon",
         "states": [
            "Adamaoua",
            "Centre",
            "Est",
            "Extreme-Nord",
            "Littoral",
            "Nord",
            "Nord-Ouest",
            "Ouest",
            "Sud",
            "Sud-Ouest"
         ]
      },
      {
         "country": "Canada",
         "states": [
            "Alberta",
            "British Columbia",
            "Manitoba",
            "New Brunswick",
            "Newfoundland and Labrador",
            "Northwest Territories",
            "Nova Scotia",
            "Nunavut",
            "Ontario",
            "Prince Edward Island",
            "Quebec",
            "Saskatchewan",
            "Yukon Territory"
         ]
      },
      {
         "country": "Cape Verde",
         "states": []
      },
      {
         "country": "Central African Republic",
         "states": [
            "Bamingui-Bangoran",
            "Bangui",
            "Basse-Kotto",
            "Haute-Kotto",
            "Haut-Mbomou",
            "Kemo",
            "Lobaye",
            "Mambere-Kadei",
            "Mbomou",
            "Nana-Grebizi",
            "Nana-Mambere",
            "Ombella-Mpoko",
            "Ouaka",
            "Ouham",
            "Ouham-Pende",
            "Sangha-Mbaere",
            "Vakaga"
         ]
      },
      {
         "country": "Chad",
         "states": [
            "Batha",
            "Biltine",
            "Borkou-Ennedi-Tibesti",
            "Chari-Baguirmi",
            "Guéra",
            "Kanem",
            "Lac",
            "Logone Occidental",
            "Logone Oriental",
            "Mayo-Kebbi",
            "Moyen-Chari",
            "Ouaddaï",
            "Salamat",
            "Tandjile"
         ]
      },
      {
         "country": "Chile",
         "states": [
            "Aysen",
            "Antofagasta",
            "Araucania",
            "Atacama",
            "Bio-Bio",
            "Coquimbo",
            "OHiggins",
            "Los Lagos",
            "Magallanes y la Antartica Chilena",
            "Maule",
            "Santiago Region Metropolitana",
            "Tarapaca",
            "Valparaiso"
         ]
      },
      {
         "country": "China",
         "states": [
            "Anhui",
            "Fujian",
            "Gansu",
            "Guangdong",
            "Guizhou",
            "Hainan",
            "Hebei",
            "Heilongjiang",
            "Henan",
            "Hubei",
            "Hunan",
            "Jiangsu",
            "Jiangxi",
            "Jilin",
            "Liaoning",
            "Qinghai",
            "Shaanxi",
            "Shandong",
            "Shanxi",
            "Sichuan",
            "Yunnan",
            "Zhejiang",
            "Guangxi",
            "Nei Mongol",
            "Ningxia",
            "Xinjiang",
            "Xizang (Tibet)",
            "Beijing",
            "Chongqing",
            "Shanghai",
            "Tianjin"
         ]
      },
      {
         "country": "Colombia",
         "states": [
            "Amazonas",
            "Antioquia",
            "Arauca",
            "Atlantico",
            "Bogota District Capital",
            "Bolivar",
            "Boyaca",
            "Caldas",
            "Caqueta",
            "Casanare",
            "Cauca",
            "Cesar",
            "Choco",
            "Cordoba",
            "Cundinamarca",
            "Guainia",
            "Guaviare",
            "Huila",
            "La Guajira",
            "Magdalena",
            "Meta",
            "Narino",
            "Norte de Santander",
            "Putumayo",
            "Quindio",
            "Risaralda",
            "San Andres & Providencia",
            "Santander",
            "Sucre",
            "Tolima",
            "Valle del Cauca",
            "Vaupes",
            "Vichada"
         ]
      },
      {
         "country": "Comoros",
         "states": [
            "Grande Comore (Njazidja)",
            "Anjouan (Nzwani)",
            "Moheli (Mwali)"
         ]
      },
      {
         "country": "Congo, Democratic Republic",
         "states": [
            "Bandundu",
            "Bas-Congo",
            "Equateur",
            "Kasai-Occidental",
            "Kasai-Oriental",
            "Katanga",
            "Kinshasa",
            "Maniema",
            "Nord-Kivu",
            "Orientale",
            "Sud-Kivu"
         ]
      },
      {
         "country": "Congo, Republic of the",
         "states": [
            "Bouenza",
            "Brazzaville",
            "Cuvette",
            "Cuvette-Ouest",
            "Kouilou",
            "Lekoumou",
            "Likouala",
            "Niari",
            "Plateaux",
            "Pool",
            "Sangha"
         ]
      },
      {
         "country": "Costa Rica",
         "states": [
            "Alajuela",
            "Cartago",
            "Guanacaste",
            "Heredia",
            "Limon",
            "Puntarenas",
            "San Jose"
         ]
      },
      {
         "country": "Cote dIvoire",
         "states": []
      },
      {
         "country": "Croatia",
         "states": [
            "Bjelovarsko-Bilogorska",
            "Brodsko-Posavska",
            "Dubrovacko-Neretvanska",
            "Istarska",
            "Karlovacka",
            "Koprivnicko-Krizevacka",
            "Krapinsko-Zagorska",
            "Licko-Senjska",
            "Medimurska",
            "Osjecko-Baranjska",
            "Pozesko-Slavonska",
            "Primorsko-Goranska",
            "Sibensko-Kninska",
            "Sisacko-Moslavacka",
            "Splitsko-Dalmatinska",
            "Varazdinska",
            "Viroviticko-Podravska",
            "Vukovarsko-Srijemska",
            "Zadarska",
            "Zagreb",
            "Zagrebacka"
         ]
      },
      {
         "country": "Cuba",
         "states": [
            "Camaguey",
            "Ciego de Avila",
            "Cienfuegos",
            "Ciudad de La Habana",
            "Granma",
            "Guantanamo",
            "Holguin",
            "Isla de la Juventud",
            "La Habana",
            "Las Tunas",
            "Matanzas",
            "Pinar del Rio",
            "Sancti Spiritus",
            "Santiago de Cuba",
            "Villa Clara"
         ]
      },
      {
         "country": "Cyprus",
         "states": [
            "Famagusta",
            "Kyrenia",
            "Larnaca",
            "Limassol",
            "Nicosia",
            "Paphos"
         ]
      },
      {
         "country": "Czech Republic",
         "states": [
            "Jihocesky Kraj",
            "Jihomoravsky Kraj",
            "Karlovarsky Kraj",
            "Kralovehradecky Kraj",
            "Liberecky Kraj",
            "Moravskoslezsky Kraj",
            "Olomoucky Kraj",
            "Pardubicky Kraj",
            "Plzensky Kraj",
            "Praha",
            "Stredocesky Kraj",
            "Ustecky Kraj",
            "Vysocina",
            "Zlinsky Kraj"
         ]
      },
      {
         "country": "Denmark",
         "states": [
            "Arhus",
            "Bornholm",
            "Frederiksberg",
            "Frederiksborg",
            "Fyn",
            "Kobenhavn",
            "Kobenhavns",
            "Nordjylland",
            "Ribe",
            "Ringkobing",
            "Roskilde",
            "Sonderjylland",
            "Storstrom",
            "Vejle",
            "Vestsjalland",
            "Viborg"
         ]
      },
      {
         "country": "Djibouti",
         "states": [
            "Ali Sabih",
            "Dikhil",
            "Djibouti",
            "Obock",
            "Tadjoura"
         ]
      },
      {
         "country": "Dominica",
         "states": [
            "Saint Andrew",
            "Saint David",
            "Saint George",
            "Saint John",
            "Saint Joseph",
            "Saint Luke",
            "Saint Mark",
            "Saint Patrick",
            "Saint Paul",
            "Saint Peter"
         ]
      },
      {
         "country": "Dominican Republic",
         "states": [
            "Azua",
            "Baoruco",
            "Barahona",
            "Dajabon",
            "Distrito Nacional",
            "Duarte",
            "Elias Pina",
            "El Seibo",
            "Espaillat",
            "Hato Mayor",
            "Independencia",
            "La Altagracia",
            "La Romana",
            "La Vega",
            "Maria Trinidad Sanchez",
            "Monsenor Nouel",
            "Monte Cristi",
            "Monte Plata",
            "Pedernales",
            "Peravia",
            "Puerto Plata",
            "Salcedo",
            "Samana",
            "Sanchez Ramirez",
            "San Cristobal",
            "San Jose de Ocoa",
            "San Juan",
            "San Pedro de Macoris",
            "Santiago",
            "Santiago Rodriguez",
            "Santo Domingo",
            "Valverde"
         ]
      },
      {
         "country": "East Timor",
         "states": [
            "Aileu",
            "Ainaro",
            "Baucau",
            "Bobonaro",
            "Cova-Lima",
            "Dili",
            "Ermera",
            "Lautem",
            "Liquica",
            "Manatuto",
            "Manufahi",
            "Oecussi",
            "Viqueque"
         ]
      },
      {
         "country": "Ecuador",
         "states": [
            "Azuay",
            "Bolivar",
            "Canar",
            "Carchi",
            "Chimborazo",
            "Cotopaxi",
            "El Oro",
            "Esmeraldas",
            "Galapagos",
            "Guayas",
            "Imbabura",
            "Loja",
            "Los Rios",
            "Manabi",
            "Morona-Santiago",
            "Napo",
            "Orellana",
            "Pastaza",
            "Pichincha",
            "Sucumbios",
            "Tungurahua",
            "Zamora-Chinchipe"
         ]
      },
      {
         "country": "Egypt",
         "states": [
            "Ad Daqahliyah",
            "Al Bahr al Ahmar",
            "Al Buhayrah",
            "Al Fayyum",
            "Al Gharbiyah",
            "Al Iskandariyah",
            "Al Ismailiyah",
            "Al Jizah",
            "Al Minufiyah",
            "Al Minya",
            "Al Qahirah",
            "Al Qalyubiyah",
            "Al Wadi al Jadid",
            "Ash Sharqiyah",
            "As Suways",
            "Aswan",
            "Asyut",
            "Bani Suwayf",
            "Bur Said",
            "Dumyat",
            "Janub Sina",
            "Kafr ash Shaykh",
            "Matruh",
            "Qina",
            "Shamal Sina",
            "Suhaj"
         ]
      },
      {
         "country": "El Salvador",
         "states": [
            "Ahuachapan",
            "Cabanas",
            "Chalatenango",
            "Cuscatlan",
            "La Libertad",
            "La Paz",
            "La Union",
            "Morazan",
            "San Miguel",
            "San Salvador",
            "Santa Ana",
            "San Vicente",
            "Sonsonate",
            "Usulutan"
         ]
      },
      {
         "country": "Equatorial Guinea",
         "states": [
            "Annobon",
            "Bioko Norte",
            "Bioko Sur",
            "Centro Sur",
            "Kie-Ntem",
            "Litoral",
            "Wele-Nzas"
         ]
      },
      {
         "country": "Eritrea",
         "states": [
            "Anseba",
            "Debub",
            "Debubawi Keyih Bahri",
            "Gash Barka",
            "Maakel",
            "Semenawi Keyih Bahri"
         ]
      },
      {
         "country": "Estonia",
         "states": [
            "Harjumaa (Tallinn)",
            "Hiiumaa (Kardla)",
            "Ida-Virumaa (Johvi)",
            "Jarvamaa (Paide)",
            "Jogevamaa (Jogeva)",
            "Laanemaa (Haapsalu)",
            "Laane-Virumaa (Rakvere)",
            "Parnumaa (Parnu)",
            "Polvamaa (Polva)",
            "Raplamaa (Rapla)",
            "Saaremaa (Kuressaare)",
            "Tartumaa (Tartu)",
            "Valgamaa (Valga)",
            "Viljandimaa (Viljandi)",
            "Vorumaa (Voru)"
         ]
      },
      {
         "country": "Ethiopia",
         "states": [
            "Addis Ababa",
            "Afar",
            "Amhara",
            "Binshangul Gumuz",
            "Dire Dawa",
            "Gambela Hizboch",
            "Harari",
            "Oromia",
            "Somali",
            "Tigray",
            "Southern Nations, Nationalities, and Peoples Region"
         ]
      },
      {
         "country": "Fiji",
         "states": [
            "Central (Suva)",
            "Eastern (Levuka)",
            "Northern (Labasa)",
            "Rotuma",
            "Western (Lautoka)"
         ]
      },
      {
         "country": "Finland",
         "states": [
            "Aland",
            "Etela-Suomen Laani",
            "Ita-Suomen Laani",
            "Lansi-Suomen Laani",
            "Lappi",
            "Oulun Laani"
         ]
      },
      {
         "country": "France",
         "states": [
            "Alsace",
            "Aquitaine",
            "Auvergne",
            "Basse-Normandie",
            "Bourgogne",
            "Bretagne",
            "Centre",
            "Champagne-Ardenne",
            "Corse",
            "Franche-Comte",
            "Haute-Normandie",
            "Ile-de-France",
            "Languedoc-Roussillon",
            "Limousin",
            "Lorraine",
            "Midi-Pyrenees",
            "Nord-Pas-de-Calais",
            "Pays de la Loire",
            "Picardie",
            "Poitou-Charentes",
            "Provence-Alpes-Cote dAzur",
            "Rhone-Alpes"
         ]
      },
      {
         "country": "Gabon",
         "states": [
            "Estuaire",
            "Haut-Ogooue",
            "Moyen-Ogooue",
            "Ngounie",
            "Nyanga",
            "Ogooue-Ivindo",
            "Ogooue-Lolo",
            "Ogooue-Maritime",
            "Woleu-Ntem"
         ]
      },
      {
         "country": "Gambia",
         "states": [
            "Banjul",
            "Central River",
            "Lower River",
            "North Bank",
            "Upper River",
            "Western"
         ]
      },
      {
         "country": "Georgia",
         "states": []
      },
      {
         "country": "Germany",
         "states": [
            "Baden-Wuerttemberg",
            "Bayern",
            "Berlin",
            "Brandenburg",
            "Bremen",
            "Hamburg",
            "Hessen",
            "Mecklenburg-Vorpommern",
            "Niedersachsen",
            "Nordrhein-Westfalen",
            "Rheinland-Pfalz",
            "Saarland",
            "Sachsen",
            "Sachsen-Anhalt",
            "Schleswig-Holstein",
            "Thueringen"
         ]
      },
      {
         "country": "Ghana",
         "states": [
            "Ashanti",
            "Brong-Ahafo",
            "Central",
            "Eastern",
            "Greater Accra",
            "Northern",
            "Upper East",
            "Upper West",
            "Volta",
            "Western"
         ]
      },
      {
         "country": "Greece",
         "states": [
            "Agion Oros",
            "Achaia",
            "Aitolia kai Akarmania",
            "Argolis",
            "Arkadia",
            "Arta",
            "Attiki",
            "Chalkidiki",
            "Chanion",
            "Chios",
            "Dodekanisos",
            "Drama",
            "Evros",
            "Evrytania",
            "Evvoia",
            "Florina",
            "Fokidos",
            "Fthiotis",
            "Grevena",
            "Ileia",
            "Imathia",
            "Ioannina",
            "Irakleion",
            "Karditsa",
            "Kastoria",
            "Kavala",
            "Kefallinia",
            "Kerkyra",
            "Kilkis",
            "Korinthia",
            "Kozani",
            "Kyklades",
            "Lakonia",
            "Larisa",
            "Lasithi",
            "Lefkas",
            "Lesvos",
            "Magnisia",
            "Messinia",
            "Pella",
            "Pieria",
            "Preveza",
            "Rethynnis",
            "Rodopi",
            "Samos",
            "Serrai",
            "Thesprotia",
            "Thessaloniki",
            "Trikala",
            "Voiotia",
            "Xanthi",
            "Zakynthos"
         ]
      },
      {
         "country": "Greenland",
         "states": [
            "Avannaa (Nordgronland)",
            "Tunu (Ostgronland)",
            "Kitaa (Vestgronland)"
         ]
      },
      {
         "country": "Grenada",
         "states": [
            "Carriacou and Petit Martinique",
            "Saint Andrew",
            "Saint David",
            "Saint George",
            "Saint John",
            "Saint Mark",
            "Saint Patrick"
         ]
      },
      {
         "country": "Guatemala",
         "states": [
            "Alta Verapaz",
            "Baja Verapaz",
            "Chimaltenango",
            "Chiquimula",
            "El Progreso",
            "Escuintla",
            "Guatemala",
            "Huehuetenango",
            "Izabal",
            "Jalapa",
            "Jutiapa",
            "Peten",
            "Quetzaltenango",
            "Quiche",
            "Retalhuleu",
            "Sacatepequez",
            "San Marcos",
            "Santa Rosa",
            "Solola",
            "Suchitepequez",
            "Totonicapan",
            "Zacapa"
         ]
      },
      {
         "country": "Guinea",
         "states": [
            "Beyla",
            "Boffa",
            "Boke",
            "Conakry",
            "Coyah",
            "Dabola",
            "Dalaba",
            "Dinguiraye",
            "Dubreka",
            "Faranah",
            "Forecariah",
            "Fria",
            "Gaoual",
            "Gueckedou",
            "Kankan",
            "Kerouane",
            "Kindia",
            "Kissidougou",
            "Koubia",
            "Koundara",
            "Kouroussa",
            "Labe",
            "Lelouma",
            "Lola",
            "Macenta",
            "Mali",
            "Mamou",
            "Mandiana",
            "Nzerekore",
            "Pita",
            "Siguiri",
            "Telimele",
            "Tougue",
            "Yomou"
         ]
      },
      {
         "country": "Guinea-Bissau",
         "states": [
            "Bafata",
            "Biombo",
            "Bissau",
            "Bolama",
            "Cacheu",
            "Gabu",
            "Oio",
            "Quinara",
            "Tombali"
         ]
      },
      {
         "country": "Guyana",
         "states": [
            "Barima-Waini",
            "Cuyuni-Mazaruni",
            "Demerara-Mahaica",
            "East Berbice-Corentyne",
            "Essequibo Islands-West Demerara",
            "Mahaica-Berbice",
            "Pomeroon-Supenaam",
            "Potaro-Siparuni",
            "Upper Demerara-Berbice",
            "Upper Takutu-Upper Essequibo"
         ]
      },
      {
         "country": "Haiti",
         "states": [
            "Artibonite",
            "Centre",
            "Grand Anse",
            "Nord",
            "Nord-Est",
            "Nord-Ouest",
            "Ouest",
            "Sud",
            "Sud-Est"
         ]
      },
      {
         "country": "Honduras",
         "states": [
            "Atlantida",
            "Choluteca",
            "Colon",
            "Comayagua",
            "Copan",
            "Cortes",
            "El Paraiso",
            "Francisco Morazan",
            "Gracias a Dios",
            "Intibuca",
            "Islas de la Bahia",
            "La Paz",
            "Lempira",
            "Ocotepeque",
            "Olancho",
            "Santa Barbara",
            "Valle",
            "Yoro"
         ]
      },
      {
         "country": "Hong Kong",
         "states": []
      },
      {
         "country": "Hungary",
         "states": [
            "Bacs-Kiskun",
            "Baranya",
            "Bekes",
            "Borsod-Abauj-Zemplen",
            "Csongrad",
            "Fejer",
            "Gyor-Moson-Sopron",
            "Hajdu-Bihar",
            "Heves",
            "Jasz-Nagykun-Szolnok",
            "Komarom-Esztergom",
            "Nograd",
            "Pest",
            "Somogy",
            "Szabolcs-Szatmar-Bereg",
            "Tolna",
            "Vas",
            "Veszprem",
            "Zala",
            "Bekescsaba",
            "Debrecen",
            "Dunaujvaros",
            "Eger",
            "Gyor",
            "Hodmezovasarhely",
            "Kaposvar",
            "Kecskemet",
            "Miskolc",
            "Nagykanizsa",
            "Nyiregyhaza",
            "Pecs",
            "Sopron",
            "Szeged",
            "Szekesfehervar",
            "Szolnok",
            "Szombathely",
            "Tatabanya",
            "Veszprem",
            "Zalaegerszeg"
         ]
      },
      {
         "country": "Iceland",
         "states": [
            "Austurland",
            "Hofudhborgarsvaedhi",
            "Nordhurland Eystra",
            "Nordhurland Vestra",
            "Sudhurland",
            "Sudhurnes",
            "Vestfirdhir",
            "Vesturland"
         ]
      },
      {
         "country": "India",
         "states": [
            "Andaman and Nicobar Islands",
            "Andhra Pradesh",
            "Arunachal Pradesh",
            "Assam",
            "Bihar",
            "Chandigarh",
            "Chhattisgarh",
            "Dadra and Nagar Haveli",
            "Daman and Diu",
            "Delhi",
            "Goa",
            "Gujarat",
            "Haryana",
            "Himachal Pradesh",
            "Jammu and Kashmir",
            "Jharkhand",
            "Karnataka",
            "Kerala",
            "Lakshadweep",
            "Madhya Pradesh",
            "Maharashtra",
            "Manipur",
            "Meghalaya",
            "Mizoram",
            "Nagaland",
            "Orissa",
            "Pondicherry",
            "Punjab",
            "Rajasthan",
            "Sikkim",
            "Tamil Nadu",
            "Tripura",
            "Uttaranchal",
            "Uttar Pradesh",
            "West Bengal"
         ]
      },
      {
         "country": "Indonesia",
         "states": [
            "Aceh",
            "Bali",
            "Banten",
            "Bengkulu",
            "Gorontalo",
            "Irian Jaya Barat",
            "Jakarta Raya",
            "Jambi",
            "Jawa Barat",
            "Jawa Tengah",
            "Jawa Timur",
            "Kalimantan Barat",
            "Kalimantan Selatan",
            "Kalimantan Tengah",
            "Kalimantan Timur",
            "Kepulauan Bangka Belitung",
            "Kepulauan Riau",
            "Lampung",
            "Maluku",
            "Maluku Utara",
            "Nusa Tenggara Barat",
            "Nusa Tenggara Timur",
            "Papua",
            "Riau",
            "Sulawesi Barat",
            "Sulawesi Selatan",
            "Sulawesi Tengah",
            "Sulawesi Tenggara",
            "Sulawesi Utara",
            "Sumatera Barat",
            "Sumatera Selatan",
            "Sumatera Utara",
            "Yogyakarta"
         ]
      },
      {
         "country": "Iran",
         "states": [
            "Ardabil",
            "Azarbayjan-e Gharbi",
            "Azarbayjan-e Sharqi",
            "Bushehr",
            "Chahar Mahall va Bakhtiari",
            "Esfahan",
            "Fars",
            "Gilan",
            "Golestan",
            "Hamadan",
            "Hormozgan",
            "Ilam",
            "Kerman",
            "Kermanshah",
            "Khorasan-e Janubi",
            "Khorasan-e Razavi",
            "Khorasan-e Shemali",
            "Khuzestan",
            "Kohgiluyeh va Buyer Ahmad",
            "Kordestan",
            "Lorestan",
            "Markazi",
            "Mazandaran",
            "Qazvin",
            "Qom",
            "Semnan",
            "Sistan va Baluchestan",
            "Tehran",
            "Yazd",
            "Zanjan"
         ]
      },
      {
         "country": "Iraq",
         "states": [
            "Al Anbar",
            "Al Basrah",
            "Al Muthanna",
            "Al Qadisiyah",
            "An Najaf",
            "Arbil",
            "As Sulaymaniyah",
            "At Tamim",
            "Babil",
            "Baghdad",
            "Dahuk",
            "Dhi Qar",
            "Diyala",
            "Karbala",
            "Maysan",
            "Ninawa",
            "Salah ad Din",
            "Wasit"
         ]
      },
      {
         "country": "Ireland",
         "states": [
            "Carlow",
            "Cavan",
            "Clare",
            "Cork",
            "Donegal",
            "Dublin",
            "Galway",
            "Kerry",
            "Kildare",
            "Kilkenny",
            "Laois",
            "Leitrim",
            "Limerick",
            "Longford",
            "Louth",
            "Mayo",
            "Meath",
            "Monaghan",
            "Offaly",
            "Roscommon",
            "Sligo",
            "Tipperary",
            "Waterford",
            "Westmeath",
            "Wexford",
            "Wicklow"
         ]
      },
      {
         "country": "Israel",
         "states": [
            "Central",
            "Haifa",
            "Jerusalem",
            "Northern",
            "Southern",
            "Tel Aviv"
         ]
      },
      {
         "country": "Italy",
         "states": [
            "Abruzzo",
            "Basilicata",
            "Calabria",
            "Campania",
            "Emilia-Romagna",
            "Friuli-Venezia Giulia",
            "Lazio",
            "Liguria",
            "Lombardia",
            "Marche",
            "Molise",
            "Piemonte",
            "Puglia",
            "Sardegna",
            "Sicilia",
            "Toscana",
            "Trentino-Alto Adige",
            "Umbria",
            "Valle dAosta",
            "Veneto"
         ]
      },
      {
         "country": "Jamaica",
         "states": [
            "Clarendon",
            "Hanover",
            "Kingston",
            "Manchester",
            "Portland",
            "Saint Andrew",
            "Saint Ann",
            "Saint Catherine",
            "Saint Elizabeth",
            "Saint James",
            "Saint Mary",
            "Saint Thomas",
            "Trelawny",
            "Westmoreland"
         ]
      },
      {
         "country": "Japan",
         "states": [
            "Aichi",
            "Akita",
            "Aomori",
            "Chiba",
            "Ehime",
            "Fukui",
            "Fukuoka",
            "Fukushima",
            "Gifu",
            "Gumma",
            "Hiroshima",
            "Hokkaido",
            "Hyogo",
            "Ibaraki",
            "Ishikawa",
            "Iwate",
            "Kagawa",
            "Kagoshima",
            "Kanagawa",
            "Kochi",
            "Kumamoto",
            "Kyoto",
            "Mie",
            "Miyagi",
            "Miyazaki",
            "Nagano",
            "Nagasaki",
            "Nara",
            "Niigata",
            "Oita",
            "Okayama",
            "Okinawa",
            "Osaka",
            "Saga",
            "Saitama",
            "Shiga",
            "Shimane",
            "Shizuoka",
            "Tochigi",
            "Tokushima",
            "Tokyo",
            "Tottori",
            "Toyama",
            "Wakayama",
            "Yamagata",
            "Yamaguchi",
            "Yamanashi"
         ]
      },
      {
         "country": "Jordan",
         "states": [
            "Ajlun",
            "Al Aqabah",
            "Al Balqa",
            "Al Karak",
            "Al Mafraq",
            "Amman",
            "At Tafilah",
            "Az Zarqa",
            "Irbid",
            "Jarash",
            "Maan",
            "Madaba"
         ]
      },
      {
         "country": "Kazakhstan",
         "states": [
            "Almaty Oblysy",
            "Almaty Qalasy",
            "Aqmola Oblysy",
            "Aqtobe Oblysy",
            "Astana Qalasy",
            "Atyrau Oblysy",
            "Batys Qazaqstan Oblysy",
            "Bayqongyr Qalasy",
            "Mangghystau Oblysy",
            "Ongtustik Qazaqstan Oblysy",
            "Pavlodar Oblysy",
            "Qaraghandy Oblysy",
            "Qostanay Oblysy",
            "Qyzylorda Oblysy",
            "Shyghys Qazaqstan Oblysy",
            "Soltustik Qazaqstan Oblysy",
            "Zhambyl Oblysy"
         ]
      },
      {
         "country": "Kenya",
         "states": [
            "Central",
            "Coast",
            "Eastern",
            "Nairobi Area",
            "North Eastern",
            "Nyanza",
            "Rift Valley",
            "Western"
         ]
      },
      {
         "country": "Kiribati",
         "states": []
      },
      {
         "country": "Korea North",
         "states": [
            "Chagang",
            "North Hamgyong",
            "South Hamgyong",
            "North Hwanghae",
            "South Hwanghae",
            "Kangwon",
            "North Pyongan",
            "South Pyongan",
            "Yanggang",
            "Kaesong",
            "Najin",
            "Nampo",
            "Pyongyang"
         ]
      },
      {
         "country": "Korea South",
         "states": [
            "Seoul",
            "Busan City",
            "Daegu City",
            "Incheon City",
            "Gwangju City",
            "Daejeon City",
            "Ulsan",
            "Gyeonggi Province",
            "Gangwon Province",
            "North Chungcheong Province",
            "South Chungcheong Province",
            "North Jeolla Province",
            "South Jeolla Province",
            "North Gyeongsang Province",
            "South Gyeongsang Province",
            "Jeju"
         ]
      },
      {
         "country": "Kuwait",
         "states": [
            "Al Ahmadi",
            "Al Farwaniyah",
            "Al Asimah",
            "Al Jahra",
            "Hawalli",
            "Mubarak Al-Kabeer"
         ]
      },
      {
         "country": "Kyrgyzstan",
         "states": [
            "Batken Oblasty",
            "Bishkek Shaary",
            "Chuy Oblasty",
            "Jalal-Abad Oblasty",
            "Naryn Oblasty",
            "Osh Oblasty",
            "Talas Oblasty",
            "Ysyk-Kol Oblasty"
         ]
      },
      {
         "country": "Laos",
         "states": [
            "Attapu",
            "Bokeo",
            "Bolikhamxai",
            "Champasak",
            "Houaphan",
            "Khammouan",
            "Louangnamtha",
            "Louangphrabang",
            "Oudomxai",
            "Phongsali",
            "Salavan",
            "Savannakhet",
            "Viangchan",
            "Viangchan",
            "Xaignabouli",
            "Xaisomboun",
            "Xekong",
            "Xiangkhoang"
         ]
      },
      {
         "country": "Latvia",
         "states": [
            "Aizkraukles Rajons",
            "Aluksnes Rajons",
            "Balvu Rajons",
            "Bauskas Rajons",
            "Cesu Rajons",
            "Daugavpils",
            "Daugavpils Rajons",
            "Dobeles Rajons",
            "Gulbenes Rajons",
            "Jekabpils Rajons",
            "Jelgava",
            "Jelgavas Rajons",
            "Jurmala",
            "Kraslavas Rajons",
            "Kuldigas Rajons",
            "Liepaja",
            "Liepajas Rajons",
            "Limbazu Rajons",
            "Ludzas Rajons",
            "Madonas Rajons",
            "Ogres Rajons",
            "Preilu Rajons",
            "Rezekne",
            "Rezeknes Rajons",
            "Riga",
            "Rigas Rajons",
            "Saldus Rajons",
            "Talsu Rajons",
            "Tukuma Rajons",
            "Valkas Rajons",
            "Valmieras Rajons",
            "Ventspils",
            "Ventspils Rajons"
         ]
      },
      {
         "country": "Lebanon",
         "states": [
            "Beyrouth",
            "Beqaa",
            "Liban-Nord",
            "Liban-Sud",
            "Mont-Liban",
            "Nabatiye"
         ]
      },
      {
         "country": "Lesotho",
         "states": [
            "Berea",
            "Butha-Buthe",
            "Leribe",
            "Mafeteng",
            "Maseru",
            "Mohales Hoek",
            "Mokhotlong",
            "Qachas Nek",
            "Quthing",
            "Thaba-Tseka"
         ]
      },
      {
         "country": "Liberia",
         "states": [
            "Bomi",
            "Bong",
            "Gbarpolu",
            "Grand Bassa",
            "Grand Cape Mount",
            "Grand Gedeh",
            "Grand Kru",
            "Lofa",
            "Margibi",
            "Maryland",
            "Montserrado",
            "Nimba",
            "River Cess",
            "River Gee",
            "Sinoe"
         ]
      },
      {
         "country": "Libya",
         "states": [
            "Ajdabiya",
            "Al Aziziyah",
            "Al Fatih",
            "Al Jabal al Akhdar",
            "Al Jufrah",
            "Al Khums",
            "Al Kufrah",
            "An Nuqat al Khams",
            "Ash Shati",
            "Awbari",
            "Az Zawiyah",
            "Banghazi",
            "Darnah",
            "Ghadamis",
            "Gharyan",
            "Misratah",
            "Murzuq",
            "Sabha",
            "Sawfajjin",
            "Surt",
            "Tarabulus",
            "Tarhunah",
            "Tubruq",
            "Yafran",
            "Zlitan"
         ]
      },
      {
         "country": "Liechtenstein",
         "states": [
            "Balzers",
            "Eschen",
            "Gamprin",
            "Mauren",
            "Planken",
            "Ruggell",
            "Schaan",
            "Schellenberg",
            "Triesen",
            "Triesenberg",
            "Vaduz"
         ]
      },
      {
         "country": "Lithuania",
         "states": [
            "Alytaus",
            "Kauno",
            "Klaipedos",
            "Marijampoles",
            "Panevezio",
            "Siauliu",
            "Taurages",
            "Telsiu",
            "Utenos",
            "Vilniaus"
         ]
      },
      {
         "country": "Luxembourg",
         "states": [
            "Diekirch",
            "Grevenmacher",
            "Luxembourg"
         ]
      },
      {
         "country": "Macedonia",
         "states": [
            "Aerodrom",
            "Aracinovo",
            "Berovo",
            "Bitola",
            "Bogdanci",
            "Bogovinje",
            "Bosilovo",
            "Brvenica",
            "Butel",
            "Cair",
            "Caska",
            "Centar",
            "Centar Zupa",
            "Cesinovo",
            "Cucer-Sandevo",
            "Debar",
            "Debartsa",
            "Delcevo",
            "Demir Hisar",
            "Demir Kapija",
            "Dojran",
            "Dolneni",
            "Drugovo",
            "Gazi Baba",
            "Gevgelija",
            "Gjorce Petrov",
            "Gostivar",
            "Gradsko",
            "Ilinden",
            "Jegunovce",
            "Karbinci",
            "Karpos",
            "Kavadarci",
            "Kicevo",
            "Kisela Voda",
            "Kocani",
            "Konce",
            "Kratovo",
            "Kriva Palanka",
            "Krivogastani",
            "Krusevo",
            "Kumanovo",
            "Lipkovo",
            "Lozovo",
            "Makedonska Kamenica",
            "Makedonski Brod",
            "Mavrovo i Rastusa",
            "Mogila",
            "Negotino",
            "Novaci",
            "Novo Selo",
            "Ohrid",
            "Oslomej",
            "Pehcevo",
            "Petrovec",
            "Plasnica",
            "Prilep",
            "Probistip",
            "Radovis",
            "Rankovce",
            "Resen",
            "Rosoman",
            "Saraj",
            "Skopje",
            "Sopiste",
            "Staro Nagoricane",
            "Stip",
            "Struga",
            "Strumica",
            "Studenicani",
            "Suto Orizari",
            "Sveti Nikole",
            "Tearce",
            "Tetovo",
            "Valandovo",
            "Vasilevo",
            "Veles",
            "Vevcani",
            "Vinica",
            "Vranestica",
            "Vrapciste",
            "Zajas",
            "Zelenikovo",
            "Zelino",
            "Zrnovci"
         ]
      },
      {
         "country": "Madagascar",
         "states": [
            "Antananarivo",
            "Antsiranana",
            "Fianarantsoa",
            "Mahajanga",
            "Toamasina",
            "Toliara"
         ]
      },
      {
         "country": "Malawi",
         "states": [
            "Balaka",
            "Blantyre",
            "Chikwawa",
            "Chiradzulu",
            "Chitipa",
            "Dedza",
            "Dowa",
            "Karonga",
            "Kasungu",
            "Likoma",
            "Lilongwe",
            "Machinga",
            "Mangochi",
            "Mchinji",
            "Mulanje",
            "Mwanza",
            "Mzimba",
            "Ntcheu",
            "Nkhata Bay",
            "Nkhotakota",
            "Nsanje",
            "Ntchisi",
            "Phalombe",
            "Rumphi",
            "Salima",
            "Thyolo",
            "Zomba"
         ]
      },
      {
         "country": "Malaysia",
         "states": [
            "Johor",
            "Kedah",
            "Kelantan",
            "Kuala Lumpur",
            "Labuan",
            "Malacca",
            "Negeri Sembilan",
            "Pahang",
            "Perak",
            "Perlis",
            "Penang",
            "Sabah",
            "Sarawak",
            "Selangor",
            "Terengganu"
         ]
      },
      {
         "country": "Maldives",
         "states": [
            "Alifu",
            "Baa",
            "Dhaalu",
            "Faafu",
            "Gaafu Alifu",
            "Gaafu Dhaalu",
            "Gnaviyani",
            "Haa Alifu",
            "Haa Dhaalu",
            "Kaafu",
            "Laamu",
            "Lhaviyani",
            "Maale",
            "Meemu",
            "Noonu",
            "Raa",
            "Seenu",
            "Shaviyani",
            "Thaa",
            "Vaavu"
         ]
      },
      {
         "country": "Mali",
         "states": [
            "Bamako (Capital)",
            "Gao",
            "Kayes",
            "Kidal",
            "Koulikoro",
            "Mopti",
            "Segou",
            "Sikasso",
            "Tombouctou"
         ]
      },
      {
         "country": "Malta",
         "states": []
      },
      {
         "country": "Marshall Islands",
         "states": []
      },
      {
         "country": "Mauritania",
         "states": [
            "Adrar",
            "Assaba",
            "Brakna",
            "Dakhlet Nouadhibou",
            "Gorgol",
            "Guidimaka",
            "Hodh Ech Chargui",
            "Hodh El Gharbi",
            "Inchiri",
            "Nouakchott",
            "Tagant",
            "Tiris Zemmour",
            "Trarza"
         ]
      },
      {
         "country": "Mauritius",
         "states": [
            "Agalega Islands",
            "Black River",
            "Cargados Carajos Shoals",
            "Flacq",
            "Grand Port",
            "Moka",
            "Pamplemousses",
            "Plaines Wilhems",
            "Port Louis",
            "Riviere du Rempart",
            "Rodrigues",
            "Savanne"
         ]
      },
      {
         "country": "Mexico",
         "states": [
            "Aguascalientes",
            "Baja California",
            "Baja California Sur",
            "Campeche",
            "Chiapas",
            "Chihuahua",
            "Coahuila de Zaragoza",
            "Colima",
            "Distrito Federal",
            "Durango",
            "Guanajuato",
            "Guerrero",
            "Hidalgo",
            "Jalisco",
            "Mexico",
            "Michoacan de Ocampo",
            "Morelos",
            "Nayarit",
            "Nuevo Leon",
            "Oaxaca",
            "Puebla",
            "Queretaro de Arteaga",
            "Quintana Roo",
            "San Luis Potosi",
            "Sinaloa",
            "Sonora",
            "Tabasco",
            "Tamaulipas",
            "Tlaxcala",
            "Veracruz-Llave",
            "Yucatan",
            "Zacatecas"
         ]
      },
      {
         "country": "Micronesia",
         "states": []
      },
      {
         "country": "Moldova",
         "states": [
            "Anenii Noi",
            "Basarabeasca",
            "Briceni",
            "Cahul",
            "Cantemir",
            "Calarasi",
            "Causeni",
            "Cimislia",
            "Criuleni",
            "Donduseni",
            "Drochia",
            "Dubasari",
            "Edinet",
            "Falesti",
            "Floresti",
            "Glodeni",
            "Hincesti",
            "Ialoveni",
            "Leova",
            "Nisporeni",
            "Ocnita",
            "Orhei",
            "Rezina",
            "Riscani",
            "Singerei",
            "Soldanesti",
            "Soroca",
            "Stefan-Voda",
            "Straseni",
            "Taraclia",
            "Telenesti",
            "Ungheni",
            "Balti",
            "Bender",
            "Chisinau",
            "Gagauzia",
            "Stinga Nistrului"
         ]
      },
      {
         "country": "Mongolia",
         "states": [
            "Arhangay",
            "Bayanhongor",
            "Bayan-Olgiy",
            "Bulgan",
            "Darhan Uul",
            "Dornod",
            "Dornogovi",
            "Dundgovi",
            "Dzavhan",
            "Govi-Altay",
            "Govi-Sumber",
            "Hentiy",
            "Hovd",
            "Hovsgol",
            "Omnogovi",
            "Orhon",
            "Ovorhangay",
            "Selenge",
            "Suhbaatar",
            "Tov",
            "Ulaanbaatar",
            "Uvs"
         ]
      },
      {
         "country": "Morocco",
         "states": [
            "Agadir",
            "Al Hoceima",
            "Azilal",
            "Beni Mellal",
            "Ben Slimane",
            "Boulemane",
            "Casablanca",
            "Chaouen",
            "El Jadida",
            "El Kelaa des Sraghna",
            "Er Rachidia",
            "Essaouira",
            "Fes",
            "Figuig",
            "Guelmim",
            "Ifrane",
            "Kenitra",
            "Khemisset",
            "Khenifra",
            "Khouribga",
            "Laayoune",
            "Larache",
            "Marrakech",
            "Meknes",
            "Nador",
            "Ouarzazate",
            "Oujda",
            "Rabat-Sale",
            "Safi",
            "Settat",
            "Sidi Kacem",
            "Tangier",
            "Tan-Tan",
            "Taounate",
            "Taroudannt",
            "Tata",
            "Taza",
            "Tetouan",
            "Tiznit"
         ]
      },
      {
         "country": "Monaco",
         "states": []
      },
      {
         "country": "Mozambique",
         "states": [
            "Cabo Delgado",
            "Gaza",
            "Inhambane",
            "Manica",
            "Maputo",
            "Cidade de Maputo",
            "Nampula",
            "Niassa",
            "Sofala",
            "Tete",
            "Zambezia"
         ]
      },
      {
         "country": "Namibia",
         "states": [
            "Caprivi",
            "Erongo",
            "Hardap",
            "Karas",
            "Khomas",
            "Kunene",
            "Ohangwena",
            "Okavango",
            "Omaheke",
            "Omusati",
            "Oshana",
            "Oshikoto",
            "Otjozondjupa"
         ]
      },
      {
         "country": "Nauru",
         "states": []
      },
      {
         "country": "Nepal",
         "states": [
            "Bagmati",
            "Bheri",
            "Dhawalagiri",
            "Gandaki",
            "Janakpur",
            "Karnali",
            "Kosi",
            "Lumbini",
            "Mahakali",
            "Mechi",
            "Narayani",
            "Rapti",
            "Sagarmatha",
            "Seti"
         ]
      },
      {
         "country": "Netherlands",
         "states": [
            "Drenthe",
            "Flevoland",
            "Friesland",
            "Gelderland",
            "Groningen",
            "Limburg",
            "Noord-Brabant",
            "Noord-Holland",
            "Overijssel",
            "Utrecht",
            "Zeeland",
            "Zuid-Holland"
         ]
      },
      {
         "country": "New Zealand",
         "states": [
            "Auckland",
            "Bay of Plenty",
            "Canterbury",
            "Chatham Islands",
            "Gisborne",
            "Hawkes Bay",
            "Manawatu-Wanganui",
            "Marlborough",
            "Nelson",
            "Northland",
            "Otago",
            "Southland",
            "Taranaki",
            "Tasman",
            "Waikato",
            "Wellington",
            "West Coast"
         ]
      },
      {
         "country": "Nicaragua",
         "states": [
            "Atlantico Norte",
            "Atlantico Sur",
            "Boaco",
            "Carazo",
            "Chinandega",
            "Chontales",
            "Esteli",
            "Granada",
            "Jinotega",
            "Leon",
            "Madriz",
            "Managua",
            "Masaya",
            "Matagalpa",
            "Nueva Segovia",
            "Rio San Juan",
            "Rivas"
         ]
      },
      {
         "country": "Niger",
         "states": [
            "Agadez",
            "Diffa",
            "Dosso",
            "Maradi",
            "Niamey",
            "Tahoua",
            "Tillaberi",
            "Zinder"
         ]
      },
      {
         "country": "Nigeria",
         "states": [
            "Abia",
            "Abuja Federal Capital",
            "Adamawa",
            "Akwa Ibom",
            "Anambra",
            "Bauchi",
            "Bayelsa",
            "Benue",
            "Borno",
            "Cross River",
            "Delta",
            "Ebonyi",
            "Edo",
            "Ekiti",
            "Enugu",
            "Gombe",
            "Imo",
            "Jigawa",
            "Kaduna",
            "Kano",
            "Katsina",
            "Kebbi",
            "Kogi",
            "Kwara",
            "Lagos",
            "Nassarawa",
            "Niger",
            "Ogun",
            "Ondo",
            "Osun",
            "Oyo",
            "Plateau",
            "Rivers",
            "Sokoto",
            "Taraba",
            "Yobe",
            "Zamfara"
         ]
      },
      {
         "country": "Norway",
         "states": [
            "Akershus",
            "Aust-Agder",
            "Buskerud",
            "Finnmark",
            "Hedmark",
            "Hordaland",
            "More og Romsdal",
            "Nordland",
            "Nord-Trondelag",
            "Oppland",
            "Oslo",
            "Ostfold",
            "Rogaland",
            "Sogn og Fjordane",
            "Sor-Trondelag",
            "Telemark",
            "Troms",
            "Vest-Agder",
            "Vestfold"
         ]
      },
      {
         "country": "Oman",
         "states": [
            "Ad Dakhiliyah",
            "Al Batinah",
            "Al Wusta",
            "Ash Sharqiyah",
            "Az Zahirah",
            "Masqat",
            "Musandam",
            "Dhofar"
         ]
      },
      {
         "country": "Pakistan",
         "states": [
            "Balochistan",
            "North-West Frontier Province",
            "Punjab",
            "Sindh",
            "Islamabad Capital Territory",
            "Federally Administered Tribal Areas"
         ]
      },
      {
         "country": "Panama",
         "states": [
            "Bocas del Toro",
            "Chiriqui",
            "Cocle",
            "Colon",
            "Darien",
            "Herrera",
            "Los Santos",
            "Panama",
            "San Blas",
            "Veraguas"
         ]
      },
      {
         "country": "Papua New Guinea",
         "states": [
            "Bougainville",
            "Central",
            "Chimbu",
            "Eastern Highlands",
            "East New Britain",
            "East Sepik",
            "Enga",
            "Gulf",
            "Madang",
            "Manus",
            "Milne Bay",
            "Morobe",
            "National Capital",
            "New Ireland",
            "Northern",
            "Sandaun",
            "Southern Highlands",
            "Western",
            "Western Highlands",
            "West New Britain"
         ]
      },
      {
         "country": "Paraguay",
         "states": [
            "Alto Paraguay",
            "Alto Parana",
            "Amambay",
            "Asuncion",
            "Boqueron",
            "Caaguazu",
            "Caazapa",
            "Canindeyu",
            "Central",
            "Concepcion",
            "Cordillera",
            "Guaira",
            "Itapua",
            "Misiones",
            "Neembucu",
            "Paraguari",
            "Presidente Hayes",
            "San Pedro"
         ]
      },
      {
         "country": "Peru",
         "states": [
            "Amazonas",
            "Ancash",
            "Apurimac",
            "Arequipa",
            "Ayacucho",
            "Cajamarca",
            "Callao",
            "Cusco",
            "Huancavelica",
            "Huanuco",
            "Ica",
            "Junin",
            "La Libertad",
            "Lambayeque",
            "Lima",
            "Loreto",
            "Madre de Dios",
            "Moquegua",
            "Pasco",
            "Piura",
            "Puno",
            "San Martin",
            "Tacna",
            "Tumbes",
            "Ucayali"
         ]
      },
      {
         "country": "Philippines",
         "states": [
            "Abra",
            "Agusan del Norte",
            "Agusan del Sur",
            "Aklan",
            "Albay",
            "Antique",
            "Apayao",
            "Aurora",
            "Basilan",
            "Bataan",
            "Batanes",
            "Batangas",
            "Biliran",
            "Benguet",
            "Bohol",
            "Bukidnon",
            "Bulacan",
            "Cagayan",
            "Camarines Norte",
            "Camarines Sur",
            "Camiguin",
            "Capiz",
            "Catanduanes",
            "Cavite",
            "Cebu",
            "Compostela",
            "Davao del Norte",
            "Davao del Sur",
            "Davao Oriental",
            "Eastern Samar",
            "Guimaras",
            "Ifugao",
            "Ilocos Norte",
            "Ilocos Sur",
            "Iloilo",
            "Isabela",
            "Kalinga",
            "Laguna",
            "Lanao del Norte",
            "Lanao del Sur",
            "La Union",
            "Leyte",
            "Maguindanao",
            "Marinduque",
            "Masbate",
            "Mindoro Occidental",
            "Mindoro Oriental",
            "Misamis Occidental",
            "Misamis Oriental",
            "Mountain Province",
            "Negros Occidental",
            "Negros Oriental",
            "North Cotabato",
            "Northern Samar",
            "Nueva Ecija",
            "Nueva Vizcaya",
            "Palawan",
            "Pampanga",
            "Pangasinan",
            "Quezon",
            "Quirino",
            "Rizal",
            "Romblon",
            "Samar",
            "Sarangani",
            "Siquijor",
            "Sorsogon",
            "South Cotabato",
            "Southern Leyte",
            "Sultan Kudarat",
            "Sulu",
            "Surigao del Norte",
            "Surigao del Sur",
            "Tarlac",
            "Tawi-Tawi",
            "Zambales",
            "Zamboanga del Norte",
            "Zamboanga del Sur",
            "Zamboanga Sibugay"
         ]
      },
      {
         "country": "Poland",
         "states": [
            "Greater Poland (Wielkopolskie)",
            "Kuyavian-Pomeranian (Kujawsko-Pomorskie)",
            "Lesser Poland (Malopolskie)",
            "Lodz (Lodzkie)",
            "Lower Silesian (Dolnoslaskie)",
            "Lublin (Lubelskie)",
            "Lubusz (Lubuskie)",
            "Masovian (Mazowieckie)",
            "Opole (Opolskie)",
            "Podlasie (Podlaskie)",
            "Pomeranian (Pomorskie)",
            "Silesian (Slaskie)",
            "Subcarpathian (Podkarpackie)",
            "Swietokrzyskie (Swietokrzyskie)",
            "Warmian-Masurian (Warminsko-Mazurskie)",
            "West Pomeranian (Zachodniopomorskie)"
         ]
      },
      {
         "country": "Portugal",
         "states": [
            "Aveiro",
            "Acores",
            "Beja",
            "Braga",
            "Braganca",
            "Castelo Branco",
            "Coimbra",
            "Evora",
            "Faro",
            "Guarda",
            "Leiria",
            "Lisboa",
            "Madeira",
            "Portalegre",
            "Porto",
            "Santarem",
            "Setubal",
            "Viana do Castelo",
            "Vila Real",
            "Viseu"
         ]
      },
      {
         "country": "Qatar",
         "states": [
            "Ad Dawhah",
            "Al Ghuwayriyah",
            "Al Jumayliyah",
            "Al Khawr",
            "Al Wakrah",
            "Ar Rayyan",
            "Jarayan al Batinah",
            "Madinat ash Shamal",
            "Umm Said",
            "Umm Salal"
         ]
      },
      {
         "country": "Romania",
         "states": [
            "Alba",
            "Arad",
            "Arges",
            "Bacau",
            "Bihor",
            "Bistrita-Nasaud",
            "Botosani",
            "Braila",
            "Brasov",
            "Bucuresti",
            "Buzau",
            "Calarasi",
            "Caras-Severin",
            "Cluj",
            "Constanta",
            "Covasna",
            "Dimbovita",
            "Dolj",
            "Galati",
            "Gorj",
            "Giurgiu",
            "Harghita",
            "Hunedoara",
            "Ialomita",
            "Iasi",
            "Ilfov",
            "Maramures",
            "Mehedinti",
            "Mures",
            "Neamt",
            "Olt",
            "Prahova",
            "Salaj",
            "Satu Mare",
            "Sibiu",
            "Suceava",
            "Teleorman",
            "Timis",
            "Tulcea",
            "Vaslui",
            "Vilcea",
            "Vrancea"
         ]
      },
      {
         "country": "Russia",
         "states": [
            "Amur",
            "Arkhangelsk",
            "Astrakhan",
            "Belgorod",
            "Bryansk",
            "Chelyabinsk",
            "Chita",
            "Irkutsk",
            "Ivanovo",
            "Kaliningrad",
            "Kaluga",
            "Kamchatka",
            "Kemerovo",
            "Kirov",
            "Kostroma",
            "Kurgan",
            "Kursk",
            "Leningrad",
            "Lipetsk",
            "Magadan",
            "Moscow",
            "Murmansk",
            "Nizhniy Novgorod",
            "Novgorod",
            "Novosibirsk",
            "Omsk",
            "Orenburg",
            "Orel",
            "Penza",
            "Perm",
            "Pskov",
            "Rostov",
            "Ryazan",
            "Sakhalin",
            "Samara",
            "Saratov",
            "Smolensk",
            "Sverdlovsk",
            "Tambov",
            "Tomsk",
            "Tula",
            "Tver",
            "Tyumen",
            "Ulyanovsk",
            "Vladimir",
            "Volgograd",
            "Vologda",
            "Voronezh",
            "Yaroslavl",
            "Adygeya",
            "Altay",
            "Bashkortostan",
            "Buryatiya",
            "Chechnya",
            "Chuvashiya",
            "Dagestan",
            "Ingushetiya",
            "Kabardino-Balkariya",
            "Kalmykiya",
            "Karachayevo-Cherkesiya",
            "Kareliya",
            "Khakasiya",
            "Komi",
            "Mariy-El",
            "Mordoviya",
            "Sakha",
            "North Ossetia",
            "Tatarstan",
            "Tyva",
            "Udmurtiya",
            "Aga Buryat",
            "Chukotka",
            "Evenk",
            "Khanty-Mansi",
            "Komi-Permyak",
            "Koryak",
            "Nenets",
            "Taymyr",
            "Ust-Orda Buryat",
            "Yamalo-Nenets",
            "Altay",
            "Khabarovsk",
            "Krasnodar",
            "Krasnoyarsk",
            "Primorskiy",
            "Stavropol",
            "Moscow",
            "St. Petersburg",
            "Yevrey"
         ]
      },
      {
         "country": "Rwanda",
         "states": [
            "Butare",
            "Byumba",
            "Cyangugu",
            "Gikongoro",
            "Gisenyi",
            "Gitarama",
            "Kibungo",
            "Kibuye",
            "Kigali Rurale",
            "Kigali-ville",
            "Umutara",
            "Ruhengeri"
         ]
      },
      {
         "country": "Samoa",
         "states": [
            "Aana",
            "Aiga-i-le-Tai",
            "Atua",
            "Faasaleleaga",
            "Gagaemauga",
            "Gagaifomauga",
            "Palauli",
            "Satupaitea",
            "Tuamasaga",
            "Vaa-o-Fonoti",
            "Vaisigano"
         ]
      },
      {
         "country": "San Marino",
         "states": [
            "Acquaviva",
            "Borgo Maggiore",
            "Chiesanuova",
            "Domagnano",
            "Faetano",
            "Fiorentino",
            "Montegiardino",
            "San Marino Citta",
            "Serravalle"
         ]
      },
      {
         "country": "Sao Tome",
         "states": []
      },
      {
         "country": "Saudi Arabia",
         "states": [
            "Al Bahah",
            "Al Hudud ash Shamaliyah",
            "Al Jawf",
            "Al Madinah",
            "Al Qasim",
            "Ar Riyad",
            "Ash Sharqiyah",
            "Asir",
            "Hail",
            "Jizan",
            "Makkah",
            "Najran",
            "Tabuk"
         ]
      },
      {
         "country": "Senegal",
         "states": [
            "Dakar",
            "Diourbel",
            "Fatick",
            "Kaolack",
            "Kolda",
            "Louga",
            "Matam",
            "Saint-Louis",
            "Tambacounda",
            "Thies",
            "Ziguinchor"
         ]
      },
      {
         "country": "Serbia and Montenegro",
         "states": [
            "Kosovo",
            "Montenegro",
            "Serbia",
            "Vojvodina"
         ]
      },
      {
         "country": "Seychelles",
         "states": [
            "Anse aux Pins",
            "Anse Boileau",
            "Anse Etoile",
            "Anse Louis",
            "Anse Royale",
            "Baie Lazare",
            "Baie Sainte Anne",
            "Beau Vallon",
            "Bel Air",
            "Bel Ombre",
            "Cascade",
            "Glacis",
            "Grand Anse",
            "Grand Anse",
            "La Digue",
            "La Riviere Anglaise",
            "Mont Buxton",
            "Mont Fleuri",
            "Plaisance",
            "Pointe La Rue",
            "Port Glaud",
            "Saint Louis",
            "Takamaka"
         ]
      },
      {
         "country": "Sierra Leone",
         "states": []
      },
      {
         "country": "Singapore",
         "states": []
      },
      {
         "country": "Slovakia",
         "states": [
            "Banskobystricky",
            "Bratislavsky",
            "Kosicky",
            "Nitriansky",
            "Presovsky",
            "Trenciansky",
            "Trnavsky",
            "Zilinsky"
         ]
      },
      {
         "country": "Slovenia",
         "states": [
            "Ajdovscina",
            "Beltinci",
            "Benedikt",
            "Bistrica ob Sotli",
            "Bled",
            "Bloke",
            "Bohinj",
            "Borovnica",
            "Bovec",
            "Braslovce",
            "Brda",
            "Brezice",
            "Brezovica",
            "Cankova",
            "Celje",
            "Cerklje na Gorenjskem",
            "Cerknica",
            "Cerkno",
            "Cerkvenjak",
            "Crensovci",
            "Crna na Koroskem",
            "Crnomelj",
            "Destrnik",
            "Divaca",
            "Dobje",
            "Dobrepolje",
            "Dobrna",
            "Dobrova-Horjul-Polhov Gradec",
            "Dobrovnik-Dobronak",
            "Dolenjske Toplice",
            "Dol pri Ljubljani",
            "Domzale",
            "Dornava",
            "Dravograd",
            "Duplek",
            "Gorenja Vas-Poljane",
            "Gorisnica",
            "Gornja Radgona",
            "Gornji Grad",
            "Gornji Petrovci",
            "Grad",
            "Grosuplje",
            "Hajdina",
            "Hoce-Slivnica",
            "Hodos-Hodos",
            "Horjul",
            "Hrastnik",
            "Hrpelje-Kozina",
            "Idrija",
            "Ig",
            "Ilirska Bistrica",
            "Ivancna Gorica",
            "Izola-Isola",
            "Jesenice",
            "Jezersko",
            "Jursinci",
            "Kamnik",
            "Kanal",
            "Kidricevo",
            "Kobarid",
            "Kobilje",
            "Kocevje",
            "Komen",
            "Komenda",
            "Koper-Capodistria",
            "Kostel",
            "Kozje",
            "Kranj",
            "Kranjska Gora",
            "Krizevci",
            "Krsko",
            "Kungota",
            "Kuzma",
            "Lasko",
            "Lenart",
            "Lendava-Lendva",
            "Litija",
            "Ljubljana",
            "Ljubno",
            "Ljutomer",
            "Logatec",
            "Loska Dolina",
            "Loski Potok",
            "Lovrenc na Pohorju",
            "Luce",
            "Lukovica",
            "Majsperk",
            "Maribor",
            "Markovci",
            "Medvode",
            "Menges",
            "Metlika",
            "Mezica",
            "Miklavz na Dravskem Polju",
            "Miren-Kostanjevica",
            "Mirna Pec",
            "Mislinja",
            "Moravce",
            "Moravske Toplice",
            "Mozirje",
            "Murska Sobota",
            "Muta",
            "Naklo",
            "Nazarje",
            "Nova Gorica",
            "Novo Mesto",
            "Odranci",
            "Oplotnica",
            "Ormoz",
            "Osilnica",
            "Pesnica",
            "Piran-Pirano",
            "Pivka",
            "Podcetrtek",
            "Podlehnik",
            "Podvelka",
            "Polzela",
            "Postojna",
            "Prebold",
            "Preddvor",
            "Prevalje",
            "Ptuj",
            "Puconci",
            "Race-Fram",
            "Radece",
            "Radenci",
            "Radlje ob Dravi",
            "Radovljica",
            "Ravne na Koroskem",
            "Razkrizje",
            "Ribnica",
            "Ribnica na Pohorju",
            "Rogasovci",
            "Rogaska Slatina",
            "Rogatec",
            "Ruse",
            "Salovci",
            "Selnica ob Dravi",
            "Semic",
            "Sempeter-Vrtojba",
            "Sencur",
            "Sentilj",
            "Sentjernej",
            "Sentjur pri Celju",
            "Sevnica",
            "Sezana",
            "Skocjan",
            "Skofja Loka",
            "Skofljica",
            "Slovenj Gradec",
            "Slovenska Bistrica",
            "Slovenske Konjice",
            "Smarje pri Jelsah",
            "Smartno ob Paki",
            "Smartno pri Litiji",
            "Sodrazica",
            "Solcava",
            "Sostanj",
            "Starse",
            "Store",
            "Sveta Ana",
            "Sveti Andraz v Slovenskih Goricah",
            "Sveti Jurij",
            "Tabor",
            "Tisina",
            "Tolmin",
            "Trbovlje",
            "Trebnje",
            "Trnovska Vas",
            "Trzic",
            "Trzin",
            "Turnisce",
            "Velenje",
            "Velika Polana",
            "Velike Lasce",
            "Verzej",
            "Videm",
            "Vipava",
            "Vitanje",
            "Vodice",
            "Vojnik",
            "Vransko",
            "Vrhnika",
            "Vuzenica",
            "Zagorje ob Savi",
            "Zalec",
            "Zavrc",
            "Zelezniki",
            "Zetale",
            "Ziri",
            "Zirovnica",
            "Zuzemberk",
            "Zrece"
         ]
      },
      {
         "country": "Solomon Islands",
         "states": [
            "Central",
            "Choiseul",
            "Guadalcanal",
            "Honiara",
            "Isabel",
            "Makira",
            "Malaita",
            "Rennell and Bellona",
            "Temotu",
            "Western"
         ]
      },
      {
         "country": "Somalia",
         "states": [
            "Awdal",
            "Bakool",
            "Banaadir",
            "Bari",
            "Bay",
            "Galguduud",
            "Gedo",
            "Hiiraan",
            "Jubbada Dhexe",
            "Jubbada Hoose",
            "Mudug",
            "Nugaal",
            "Sanaag",
            "Shabeellaha Dhexe",
            "Shabeellaha Hoose",
            "Sool",
            "Togdheer",
            "Woqooyi Galbeed"
         ]
      },
      {
         "country": "South Africa",
         "states": [
            "Eastern Cape",
            "Free State",
            "Gauteng",
            "KwaZulu-Natal",
            "Limpopo",
            "Mpumalanga",
            "North-West",
            "Northern Cape",
            "Western Cape"
         ]
      },
      {
         "country": "Spain",
         "states": [
            "Andalucia",
            "Aragon",
            "Asturias",
            "Baleares",
            "Ceuta",
            "Canarias",
            "Cantabria",
            "Castilla-La Mancha",
            "Castilla y Leon",
            "Cataluna",
            "Comunidad Valenciana",
            "Extremadura",
            "Galicia",
            "La Rioja",
            "Madrid",
            "Melilla",
            "Murcia",
            "Navarra",
            "Pais Vasco"
         ]
      },
      {
         "country": "Sri Lanka",
         "states": [
            "Central",
            "North Central",
            "North Eastern",
            "North Western",
            "Sabaragamuwa",
            "Southern",
            "Uva",
            "Western"
         ]
      },
      {
         "country": "Sudan",
         "states": [
            "Aali an Nil",
            "Al Bahr al Ahmar",
            "Al Buhayrat",
            "Al Jazirah",
            "Al Khartum",
            "Al Qadarif",
            "Al Wahdah",
            "An Nil al Abyad",
            "An Nil al Azraq",
            "Ash Shamaliyah",
            "Bahr al Jabal",
            "Gharb al Istiwaiyah",
            "Gharb Bahr al Ghazal",
            "Gharb Darfur",
            "Gharb Kurdufan",
            "Janub Darfur",
            "Janub Kurdufan",
            "Junqali",
            "Kassala",
            "Nahr an Nil",
            "Shamal Bahr al Ghazal",
            "Shamal Darfur",
            "Shamal Kurdufan",
            "Sharq al Istiwaiyah",
            "Sinnar",
            "Warab"
         ]
      },
      {
         "country": "Suriname",
         "states": [
            "Brokopondo",
            "Commewijne",
            "Coronie",
            "Marowijne",
            "Nickerie",
            "Para",
            "Paramaribo",
            "Saramacca",
            "Sipaliwini",
            "Wanica"
         ]
      },
      {
         "country": "Swaziland",
         "states": [
            "Hhohho",
            "Lubombo",
            "Manzini",
            "Shiselweni"
         ]
      },
      {
         "country": "Sweden",
         "states": [
            "Blekinge",
            "Dalarnas",
            "Gavleborgs",
            "Gotlands",
            "Hallands",
            "Jamtlands",
            "Jonkopings",
            "Kalmar",
            "Kronobergs",
            "Norrbottens",
            "Orebro",
            "Ostergotlands",
            "Skane",
            "Sodermanlands",
            "Stockholms",
            "Uppsala",
            "Varmlands",
            "Vasterbottens",
            "Vasternorrlands",
            "Vastmanlands",
            "Vastra Gotalands"
         ]
      },
      {
         "country": "Switzerland",
         "states": [
            "Aargau",
            "Appenzell Ausser-Rhoden",
            "Appenzell Inner-Rhoden",
            "Basel-Landschaft",
            "Basel-Stadt",
            "Bern",
            "Fribourg",
            "Geneve",
            "Glarus",
            "Graubunden",
            "Jura",
            "Luzern",
            "Neuchatel",
            "Nidwalden",
            "Obwalden",
            "Sankt Gallen",
            "Schaffhausen",
            "Schwyz",
            "Solothurn",
            "Thurgau",
            "Ticino",
            "Uri",
            "Valais",
            "Vaud",
            "Zug",
            "Zurich"
         ]
      },
      {
         "country": "Syria",
         "states": [
            "Al Hasakah",
            "Al Ladhiqiyah",
            "Al Qunaytirah",
            "Ar Raqqah",
            "As Suwayda",
            "Dara",
            "Dayr az Zawr",
            "Dimashq",
            "Halab",
            "Hamah",
            "Hims",
            "Idlib",
            "Rif Dimashq",
            "Tartus"
         ]
      },
      {
         "country": "Taiwan",
         "states": [
            "Chang-hua",
            "Chia-i",
            "Hsin-chu",
            "Hua-lien",
            "I-lan",
            "Kao-hsiung",
            "Kin-men",
            "Lien-chiang",
            "Miao-li",
            "Nan-tou",
            "Peng-hu",
            "Ping-tung",
            "Tai-chung",
            "Tai-nan",
            "Tai-pei",
            "Tai-tung",
            "Tao-yuan",
            "Yun-lin",
            "Chia-i",
            "Chi-lung",
            "Hsin-chu",
            "Tai-chung",
            "Tai-nan",
            "Kao-hsiung city",
            "Tai-pei city"
         ]
      },
      {
         "country": "Tajikistan",
         "states": []
      },
      {
         "country": "Tanzania",
         "states": [
            "Arusha",
            "Dar es Salaam",
            "Dodoma",
            "Iringa",
            "Kagera",
            "Kigoma",
            "Kilimanjaro",
            "Lindi",
            "Manyara",
            "Mara",
            "Mbeya",
            "Morogoro",
            "Mtwara",
            "Mwanza",
            "Pemba North",
            "Pemba South",
            "Pwani",
            "Rukwa",
            "Ruvuma",
            "Shinyanga",
            "Singida",
            "Tabora",
            "Tanga",
            "Zanzibar Central/South",
            "Zanzibar North",
            "Zanzibar Urban/West"
         ]
      },
      {
         "country": "Thailand",
         "states": [
            "Amnat Charoen",
            "Ang Thong",
            "Buriram",
            "Chachoengsao",
            "Chai Nat",
            "Chaiyaphum",
            "Chanthaburi",
            "Chiang Mai",
            "Chiang Rai",
            "Chon Buri",
            "Chumphon",
            "Kalasin",
            "Kamphaeng Phet",
            "Kanchanaburi",
            "Khon Kaen",
            "Krabi",
            "Krung Thep Mahanakhon",
            "Lampang",
            "Lamphun",
            "Loei",
            "Lop Buri",
            "Mae Hong Son",
            "Maha Sarakham",
            "Mukdahan",
            "Nakhon Nayok",
            "Nakhon Pathom",
            "Nakhon Phanom",
            "Nakhon Ratchasima",
            "Nakhon Sawan",
            "Nakhon Si Thammarat",
            "Nan",
            "Narathiwat",
            "Nong Bua Lamphu",
            "Nong Khai",
            "Nonthaburi",
            "Pathum Thani",
            "Pattani",
            "Phangnga",
            "Phatthalung",
            "Phayao",
            "Phetchabun",
            "Phetchaburi",
            "Phichit",
            "Phitsanulok",
            "Phra Nakhon Si Ayutthaya",
            "Phrae",
            "Phuket",
            "Prachin Buri",
            "Prachuap Khiri Khan",
            "Ranong",
            "Ratchaburi",
            "Rayong",
            "Roi Et",
            "Sa Kaeo",
            "Sakon Nakhon",
            "Samut Prakan",
            "Samut Sakhon",
            "Samut Songkhram",
            "Sara Buri",
            "Satun",
            "Sing Buri",
            "Sisaket",
            "Songkhla",
            "Sukhothai",
            "Suphan Buri",
            "Surat Thani",
            "Surin",
            "Tak",
            "Trang",
            "Trat",
            "Ubon Ratchathani",
            "Udon Thani",
            "Uthai Thani",
            "Uttaradit",
            "Yala",
            "Yasothon"
         ]
      },
      {
         "country": "Togo",
         "states": [
            "Kara",
            "Plateaux",
            "Savanes",
            "Centrale",
            "Maritime"
         ]
      },
      {
         "country": "Tonga",
         "states": []
      },
      {
         "country": "Trinidad and Tobago",
         "states": [
            "Couva",
            "Diego Martin",
            "Mayaro",
            "Penal",
            "Princes Town",
            "Sangre Grande",
            "San Juan",
            "Siparia",
            "Tunapuna",
            "Port-of-Spain",
            "San Fernando",
            "Arima",
            "Point Fortin",
            "Chaguanas",
            "Tobago"
         ]
      },
      {
         "country": "Tunisia",
         "states": [
            "Ariana (Aryanah)",
            "Beja (Bajah)",
            "Ben Arous (Bin Arus)",
            "Bizerte (Banzart)",
            "Gabes (Qabis)",
            "Gafsa (Qafsah)",
            "Jendouba (Jundubah)",
            "Kairouan (Al Qayrawan)",
            "Kasserine (Al Qasrayn)",
            "Kebili (Qibili)",
            "Kef (Al Kaf)",
            "Mahdia (Al Mahdiyah)",
            "Manouba (Manubah)",
            "Medenine (Madanin)",
            "Monastir (Al Munastir)",
            "Nabeul (Nabul)",
            "Sfax (Safaqis)",
            "Sidi Bou Zid (Sidi Bu Zayd)",
            "Siliana (Silyanah)",
            "Sousse (Susah)",
            "Tataouine (Tatawin)",
            "Tozeur (Tawzar)",
            "Tunis",
            "Zaghouan (Zaghwan)"
         ]
      },
      {
         "country": "Turkey",
         "states": [
            "Adana",
            "Adiyaman",
            "Afyonkarahisar",
            "Agri",
            "Aksaray",
            "Amasya",
            "Ankara",
            "Antalya",
            "Ardahan",
            "Artvin",
            "Aydin",
            "Balikesir",
            "Bartin",
            "Batman",
            "Bayburt",
            "Bilecik",
            "Bingol",
            "Bitlis",
            "Bolu",
            "Burdur",
            "Bursa",
            "Canakkale",
            "Cankiri",
            "Corum",
            "Denizli",
            "Diyarbakir",
            "Duzce",
            "Edirne",
            "Elazig",
            "Erzincan",
            "Erzurum",
            "Eskisehir",
            "Gaziantep",
            "Giresun",
            "Gumushane",
            "Hakkari",
            "Hatay",
            "Igdir",
            "Isparta",
            "Istanbul",
            "Izmir",
            "Kahramanmaras",
            "Karabuk",
            "Karaman",
            "Kars",
            "Kastamonu",
            "Kayseri",
            "Kilis",
            "Kirikkale",
            "Kirklareli",
            "Kirsehir",
            "Kocaeli",
            "Konya",
            "Kutahya",
            "Malatya",
            "Manisa",
            "Mardin",
            "Mersin",
            "Mugla",
            "Mus",
            "Nevsehir",
            "Nigde",
            "Ordu",
            "Osmaniye",
            "Rize",
            "Sakarya",
            "Samsun",
            "Sanliurfa",
            "Siirt",
            "Sinop",
            "Sirnak",
            "Sivas",
            "Tekirdag",
            "Tokat",
            "Trabzon",
            "Tunceli",
            "Usak",
            "Van",
            "Yalova",
            "Yozgat",
            "Zonguldak"
         ]
      },
      {
         "country": "Turkmenistan",
         "states": [
            "Ahal Welayaty (Ashgabat)",
            "Balkan Welayaty (Balkanabat)",
            "Dashoguz Welayaty",
            "Lebap Welayaty (Turkmenabat)",
            "Mary Welayaty"
         ]
      },
      {
         "country": "Uganda",
         "states": [
            "Adjumani",
            "Apac",
            "Arua",
            "Bugiri",
            "Bundibugyo",
            "Bushenyi",
            "Busia",
            "Gulu",
            "Hoima",
            "Iganga",
            "Jinja",
            "Kabale",
            "Kabarole",
            "Kaberamaido",
            "Kalangala",
            "Kampala",
            "Kamuli",
            "Kamwenge",
            "Kanungu",
            "Kapchorwa",
            "Kasese",
            "Katakwi",
            "Kayunga",
            "Kibale",
            "Kiboga",
            "Kisoro",
            "Kitgum",
            "Kotido",
            "Kumi",
            "Kyenjojo",
            "Lira",
            "Luwero",
            "Masaka",
            "Masindi",
            "Mayuge",
            "Mbale",
            "Mbarara",
            "Moroto",
            "Moyo",
            "Mpigi",
            "Mubende",
            "Mukono",
            "Nakapiripirit",
            "Nakasongola",
            "Nebbi",
            "Ntungamo",
            "Pader",
            "Pallisa",
            "Rakai",
            "Rukungiri",
            "Sembabule",
            "Sironko",
            "Soroti",
            "Tororo",
            "Wakiso",
            "Yumbe"
         ]
      },
      {
         "country": "Ukraine",
         "states": [
            "Cherkasy",
            "Chernihiv",
            "Chernivtsi",
            "Crimea",
            "Dnipropetrovsk",
            "Donetsk",
            "Ivano-Frankivsk",
            "Kharkiv",
            "Kherson",
            "Khmelnytskyy",
            "Kirovohrad",
            "Kiev",
            "Kyyiv",
            "Luhansk",
            "Lviv",
            "Mykolayiv",
            "Odesa",
            "Poltava",
            "Rivne",
            "Sevastopol",
            "Sumy",
            "Ternopil",
            "Vinnytsya",
            "Volyn",
            "Zakarpattya",
            "Zaporizhzhya",
            "Zhytomyr"
         ]
      },
      {
         "country": "United Arab Emirates",
         "states": [
            "Abu Dhabi",
            "Ajman",
            "Al Fujayrah",
            "Sharjah",
            "Dubai",
            "Ras al Khaymah",
            "Umm al Qaywayn"
         ]
      },
      {
         "country": "United Kingdom",
         "states": []
      },
      {
         "country": "United States",
         "states": [
            "Alabama",
            "Alaska",
            "Arizona",
            "Arkansas",
            "California",
            "Colorado",
            "Connecticut",
            "Delaware",
            "District of Columbia",
            "Florida",
            "Georgia",
            "Hawaii",
            "Idaho",
            "Illinois",
            "Indiana",
            "Iowa",
            "Kansas",
            "Kentucky",
            "Louisiana",
            "Maine",
            "Maryland",
            "Massachusetts",
            "Michigan",
            "Minnesota",
            "Mississippi",
            "Missouri",
            "Montana",
            "Nebraska",
            "Nevada",
            "New Hampshire",
            "New Jersey",
            "New Mexico",
            "New York",
            "North Carolina",
            "North Dakota",
            "Ohio",
            "Oklahoma",
            "Oregon",
            "Pennsylvania",
            "Rhode Island",
            "South Carolina",
            "South Dakota",
            "Tennessee",
            "Texas",
            "Utah",
            "Vermont",
            "Virginia",
            "Washington",
            "West Virginia",
            "Wisconsin",
            "Wyoming"
         ]
      },
      {
         "country": "Uruguay",
         "states": [
            "Artigas",
            "Canelones",
            "Cerro Largo",
            "Colonia",
            "Durazno",
            "Flores",
            "Florida",
            "Lavalleja",
            "Maldonado",
            "Montevideo",
            "Paysandu",
            "Rio Negro",
            "Rivera",
            "Rocha",
            "Salto",
            "San Jose",
            "Soriano",
            "Tacuarembo",
            "Treinta y Tres"
         ]
      },
      {
         "country": "Uzbekistan",
         "states": [
            "Andijon Viloyati",
            "Buxoro Viloyati",
            "Fargona Viloyati",
            "Jizzax Viloyati",
            "Namangan Viloyati",
            "Navoiy Viloyati",
            "Qashqadaryo Viloyati",
            "Qaraqalpogiston Respublikasi",
            "Samarqand Viloyati",
            "Sirdaryo Viloyati",
            "Surxondaryo Viloyati",
            "Toshkent Shahri",
            "Toshkent Viloyati",
            "Xorazm Viloyati"
         ]
      },
      {
         "country": "Vanuatu",
         "states": [
            "Malampa",
            "Penama",
            "Sanma",
            "Shefa",
            "Tafea",
            "Torba"
         ]
      },
      {
         "country": "Venezuela",
         "states": [
            "Amazonas",
            "Anzoategui",
            "Apure",
            "Aragua",
            "Barinas",
            "Bolivar",
            "Carabobo",
            "Cojedes",
            "Delta Amacuro",
            "Dependencias Federales",
            "Distrito Federal",
            "Falcon",
            "Guarico",
            "Lara",
            "Merida",
            "Miranda",
            "Monagas",
            "Nueva Esparta",
            "Portuguesa",
            "Sucre",
            "Tachira",
            "Trujillo",
            "Vargas",
            "Yaracuy",
            "Zulia"
         ]
      },
      {
         "country": "Vietnam",
         "states": [
            "An Giang",
            "Bac Giang",
            "Bac Kan",
            "Bac Lieu",
            "Bac Ninh",
            "Ba Ria-Vung Tau",
            "Ben Tre",
            "Binh Dinh",
            "Binh Duong",
            "Binh Phuoc",
            "Binh Thuan",
            "Ca Mau",
            "Cao Bang",
            "Dac Lak",
            "Dac Nong",
            "Dien Bien",
            "Dong Nai",
            "Dong Thap",
            "Gia Lai",
            "Ha Giang",
            "Hai Duong",
            "Ha Nam",
            "Ha Tay",
            "Ha Tinh",
            "Hau Giang",
            "Hoa Binh",
            "Hung Yen",
            "Khanh Hoa",
            "Kien Giang",
            "Kon Tum",
            "Lai Chau",
            "Lam Dong",
            "Lang Son",
            "Lao Cai",
            "Long An",
            "Nam Dinh",
            "Nghe An",
            "Ninh Binh",
            "Ninh Thuan",
            "Phu Tho",
            "Phu Yen",
            "Quang Binh",
            "Quang Nam",
            "Quang Ngai",
            "Quang Ninh",
            "Quang Tri",
            "Soc Trang",
            "Son La",
            "Tay Ninh",
            "Thai Binh",
            "Thai Nguyen",
            "Thanh Hoa",
            "Thua Thien-Hue",
            "Tien Giang",
            "Tra Vinh",
            "Tuyen Quang",
            "Vinh Long",
            "Vinh Phuc",
            "Yen Bai",
            "Can Tho",
            "Da Nang",
            "Hai Phong",
            "Hanoi",
            "Ho Chi Minh"
         ]
      },
      {
         "country": "Yemen",
         "states": [
            "Abyan",
            "Adan",
            "Ad Dali",
            "Al Bayda",
            "Al Hudaydah",
            "Al Jawf",
            "Al Mahrah",
            "Al Mahwit",
            "Amran",
            "Dhamar",
            "Hadramawt",
            "Hajjah",
            "Ibb",
            "Lahij",
            "Marib",
            "Sadah",
            "Sana",
            "Shabwah",
            "Taizz"
         ]
      },
      {
         "country": "Zambia",
         "states": [
            "Central",
            "Copperbelt",
            "Eastern",
            "Luapula",
            "Lusaka",
            "Northern",
            "North-Western",
            "Southern",
            "Western"
         ]
      },
      {
         "country": "Zimbabwe",
         "states": [
            "Bulawayo",
            "Harare",
            "Manicaland",
            "Mashonaland Central",
            "Mashonaland East",
            "Mashonaland West",
            "Masvingo",
            "Matabeleland North",
            "Matabeleland South",
            "Midlands"
         ]
      }
   ]
}';






 $array=json_decode($json);   
 foreach($array->countries as $abc){
     //echo $abc->country.' : '.implode(',',$abc->states).'<br>';
    //  $wpdb->insert("wp_country_facilities", array(
    //   "country_name" => $abc->country,
    //       "state_name" => implode(',',$abc->states),
    //  ));
         
 }   
//    die;
    
    
    // foreach ($GetPicklistValues as $state) {
    //     if (!in_array(strtolower($state['BillingState']), $state_data)) {
    //         if ($_POST['country'] == $state['BillingCountry']) {
    //             $state_data[] = strtolower($state['BillingState']);
    //             $html.='<option value="' . $state['BillingState'] . '">' . $state['BillingState'] . '</option>';
    //         }
    //     }
    // }
    echo $html;
    exit();
}

// Get state from country end//
// ---- Filter by facility start---- //
add_action('wp_ajax_filter_by_facility', 'filter_by_facility_callback');
add_action('wp_ajax_nopriv_filter_by_facility', 'filter_by_facility_callback');

function filter_by_facility_callback() {
    $saerch_tag = $_POST['by_name_alias'];
    
    $current_tab = $_POST['current_tab'];
    
    if($current_tab == 'disp_facility'){
       $current_tab = 3; 
    }else{
       $current_tab = 2;
    }
    

    $check_status = '';
    if (isset($_POST['certificate'])) {
        $check_status = $_POST['certificate'];
          $check_status = str_replace(' ', '%20', $check_status);
          $check_status = str_replace(',', '%2C', $check_status);
          $check_status = str_replace('/', '%2F', $check_status);
         
    }
    setcookie('certificate', 'asd', time() + (86400 * 30), "/"); 
    
    
    $check_bussiness = '';
    if (isset($_POST['workflow'])) {
        $check_bussiness = $_POST['workflow'];
        $check_bussiness = str_replace(' ', '%20', $check_bussiness);
        $check_bussiness = str_replace(',', '%2C', $check_bussiness);
        $check_bussiness = str_replace('/', '%2F', $check_bussiness);
    }

    $pro_req = '';
    if (isset($_POST['process_require'])) {
        $pro_req = $_POST['process_require'];
        $pro_req = str_replace(' ', '%20', $pro_req);
        $pro_req = str_replace(',', '%2C', $pro_req);
        $pro_req = str_replace('/', '%2F', $pro_req);
    }
        
        //print_r($pro_req);

    $version = '';
    if (isset($_POST['versions'])) {
     //  $version_main= $_POST['versions'];
        $ver_data=explode(",",$_POST['versions']);
         if(in_array("All", $ver_data)){
            $version_main = '';
         }else{
             $version_main=$_POST['versions'];
         }
        // else{
        //     if($_POST['versions']=='All'){
        //         $version = '';
        //     }
        //     else{
        //     $version=str_replace(':','%3A',$version);
        //     }
        // }
         $version = str_replace(' ', '%20', $version_main);
         $version = str_replace(',', '%2C', $version_main);
         $version = str_replace('/', '%2F', $version_main);
    }

// print_r($_POST['versions']);
// die;

        if($_POST['drop_off']=='No'){
            $drop='false';
        }else if($_POST['drop_off']=='Yes'){
            $drop='true';
        }else{
            $drop='';
        }
        
    
    
    // print_r($drop);
    // die;

    $days=$_POST['day_number'];

    $region = '';
    if (isset($_POST['regions']) && $_POST['regions']!='null') {
        $region = $_POST['regions'];
        $region = str_replace(' ', '%20', $region);
    }
    $country = '';
    if (isset($_POST['country_features']) && $_POST['country_features']!='null') {
        $country = $_POST['country_features'];
        $country = str_replace(' ', '%20', $country);
    }
    $state_features='';
    if (isset($_POST['state_features']) && $_POST['state_features']!='null') {
        $state_features = $_POST['state_features'];
        $state_features = str_replace(' ', '%20', $state_features);
    }
     $city = '';
    if (isset($_POST['city_town_features']) && $_POST['city_town_features']!='null') {
        $city = $_POST['city_town_features'];
        $city = str_replace(' ', '%20', $city);
    }
    if (get_user_meta(1, 'access_token', true) && get_user_meta(1, 'expires', true)) {

        $token = get_user_meta(1, 'access_token', true);
        $exp = get_user_meta(1, 'expires', true);
        $rfc_1123_date = gmdate('D, d M Y H:i:s T', time());
        $date1 = date_create($rfc_1123_date);
        $date2 = date_create($exp);
        $diff = date_diff($date1, $date2);
        if ($diff->h <= 1) {
            get_access_token_seri();
            $token = get_user_meta(1, 'access_token', true);
            $exp = get_user_meta(1, 'expires', true);
        } else {
            $token = get_user_meta(1, 'access_token', true);
            $exp = get_user_meta(1, 'expires', true);
        }
    } else {
        get_access_token_seri();
        $token = get_user_meta(1, 'access_token', true);
        $exp = get_user_meta(1, 'expires', true);
    }
    $curl = curl_init();


    if ($saerch_tag) {
        $url = "http://seriapi.azurewebsites.net/api/sfdata/FilterByFacility";
    } else {
        if($days != ''){
            $url = "http://seriapi.azurewebsites.net/api/sfdata/FilterByFacility?Status=$check_status&R2Version=$version&Dropoff=$drop&days=$days&Region=$region&Country=$country&State=$state_features&Appendix=$pro_req&Workflow=$check_bussiness&City=$city";        
        }else{
            $url = "http://seriapi.azurewebsites.net/api/sfdata/FilterByFacility?Status=$check_status&R2Version=$version&Dropoff=$drop&Region=$region&Country=$country&State=$state_features&Appendix=$pro_req&Workflow=$check_bussiness&City=$city";    
        }
    }

    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer " . $token,
        ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);

    $response = json_decode($response, true);
   
    
   
    $msg = '';
    
    
    
    $msg.='<div class="features_data desktop_view table">';
    $msg.='<div class="thead">
      <div class="tr">
        <div class="th select_all_facility"><span class="not_checked">Select All</span></div>
        <div class="th">Company</div>
        <div class="th">Address</div>
        <div class="th">Status, <br/> cert type</div>
      
        <div class="th last_col"></div>
      </div>
    </div><div class="table_content">';
    uasort($response['records'], 'compare_lastname');
    if ($saerch_tag) {
        foreach ($response['records'] as $recoreds) {
            //if (strpos($recoreds['Name'], $saerch_tag) !== false && strpos($recoreds['Name'], $saerch_tag)==0) {
              if (stripos($recoreds['Name'], $saerch_tag) !== false || stripos($recoreds['FacilityAlias'], $saerch_tag) !== false) {
                  
                  
                $placename = $recoreds['Name'];
                $placename = str_replace("'", '%27', $placename);
                $coords[] = array(
                    'lat' => $recoreds['Latitude'],
                    'lng' => $recoreds['Longitude'],
                    'place' => $placename
                );
                $msg.='<div class="tr">
                             <div class="td checkbox_box"><input type="checkbox" name="filter_single_facility[]"><span class="checkmark"></span></div>
                            <div class="td">' . $recoreds['Name'] . '</div>
                            <div class="td">' . $recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
                            <div class="td">' . $recoreds['CertificationStatus']. '<br/>'. $recoreds['CertificationType'] . '</div>
                            <div class="td last_col"><a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab='.$current_tab.'">More Info</a></div>
                          </div>';
            }
        }
    } else {
         $main_array=explode(',',$_POST['process_app']);
        //   echo "<pre>";
        //     print_r($response['records']);
        //     die;
            
    
    
        foreach ($response['records'] as $recoreds) {
        //   if($recoreds['DropOff'] == false){ 
        //     echo $count.')'.$recoreds['Name'].' : '.$recoreds['DropOff'].'<br>';
        //     $count++;        
        //   }
    //if($recoreds['AppendixA'] == true || $recoreds['AppendixC'] == true  || $recoreds['AppendixD'] == true || $recoreds['AppendixE'] == true){
    //   if (in_array("AppendixA", $main_array)) {
    //       if($recoreds['AppendixA'] == true){
    //          $placename = $recoreds['Name'];
    //             $placename = str_replace("'", '%27', $placename);
    //             $coords[] = array(
    //                 'lat' => $recoreds['Latitude'],
    //                 'lng' => $recoreds['Longitude'],
    //                 'place' => $placename
    //             );
    //              $msg.='<div class="tr">
    //                              <div class="td checkbox_box"><input type="checkbox" name="filter_single_facility[]"><span class="checkmark"></span></div>
    //                             <div class="td">' . $recoreds['Name'] . '</div>
    //                             <div class="td">' . $recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
    //                             <div class="td">' .$recoreds['CertificationStatus'].'<br/>'. $recoreds['CertificationType'].'</div>
    //                             <div class="td last_col"><a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=2">More Info</a></div>
               
    //                          </div>';
    //         }      
    //   }
     
    
            $placename = $recoreds['Name'];
            $placename = str_replace("'", '%27', $placename);
            $coords[] = array(
                'lat' => $recoreds['Latitude'],
                'lng' => $recoreds['Longitude'],
                'place' => $placename
            );
            
            
            
             $msg.='<div class="tr">
                             <div class="td checkbox_box"><input type="checkbox" name="filter_single_facility[]"><span class="checkmark"></span></div>
                            <div class="td">' . $recoreds['Name'] . '</div>
                            <div class="td">' . $recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
                            <div class="td">' .$recoreds['CertificationStatus'].'<br/>'. $recoreds['CertificationType'].'</div>
                            <div class="td last_col"><a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=2">More Info</a></div>
           
                         </div>';

        }
    }
    if (empty($coords)) {
        $msg.='<h2>No records found.</h2>';
    }

    $msg.='</div></div>';

    $msg.='<div class="features_data mobile_view table">';
    $msg.='<div class="thead">
      <div class="tr">
        <div class="th select_all_facility"><span class="not_checked">Select All</span></div>
        <div class="th">Company Information</div>
      </div>
    </div><div class="table_content">';
 if ($saerch_tag) {
        foreach ($response['records'] as $recoreds) {
            if (strpos($recoreds['Name'], $saerch_tag) !== false && strpos($recoreds['Name'], $saerch_tag)==0) {
                 $msg.='<div class="tr">
                    <div class="td checkbox_box"><input type="checkbox" name="filter_single_facility[]"><span class="checkmark"></span></div>
                    <div class="td"><div class="c_name">' . $recoreds['Name'] . '</div>
                    <div class="address">' . $recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
                    <div class="status">Status: ' . $recoreds['CertificationType'] . '</div>
            
                    <div class="more_info"><a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=2">More Info</a></div></div>
                  </div>';
                // $msg.='<div class="tr">
                //              <div class="td checkbox_box"><input type="checkbox" name="filter_single_facility[]"><span class="checkmark"></span></div>
                //             <div class="td">' . $recoreds['Name'] . '</div>
                //             <div class="td">' . $recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
                //             <div class="td">' . $recoreds['CertificationType'] . '</div>
                //             <div class="td last_col"><a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=2">More Info</a></div>
                //           </div>';
            }
        }
    } else {
        foreach ($response['records'] as $recoreds) {
            $msg.='<div class="tr">
                    <div class="td checkbox_box"><input type="checkbox" name="filter_single_facility[]"><span class="checkmark"></span></div>
                    <div class="td"><div class="c_name">' . $recoreds['Name'] . '</div>
                    <div class="address">' . $recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
                    <div class="status">Status: ' . $recoreds['CertificationType'] . '</div>
                    <div class="more_info"><a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=2">More Info</a></div></div>
                  </div>';
            // $msg.='<div class="tr">
            //                  <div class="td checkbox_box"><input type="checkbox" name="filter_single_facility[]"><span class="checkmark"></span></div>
            //                 <div class="td">' . $recoreds['Name'] . '</div>
            //                 <div class="td">' . $recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
            //                 <div class="td">' . $recoreds['CertificationType'] . '</div>
            //                 <div class="td last_col"><a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=2">More Info</a></div>
            //               </div>';
        }
    }

    if (empty($coords)) {
        $msg.='<h2>No records found.</h2>';
    }
    $msg.='</div></div>';
    echo $msg;
    facility_variables($coords);
    exit;
}

// ---- Filter by facility end -----//
// Filter by AREA Start//
add_action('wp_ajax_filter_by_area', 'filter_by_area_callback');
add_action('wp_ajax_nopriv_filter_by_area', 'filter_by_area_callback');
 
function filter_by_area_callback() {
    $result = wp_cache_get('r2_facilities_curl');
    if (false === $result) {
        set_data_in_cache();
        $response = wp_cache_get('r2_facilities_curl');
    } else {
        $response = wp_cache_get('r2_facilities_curl');
    }
    $response = json_decode($response, true);
    uasort($response['records'], 'compare_lastname');
   
    
    
   
    $curl = curl_init();
    $string = str_replace(' ', '+', $_POST['city_town']) . ',' . str_replace(' ', '+', $_POST['State/Province']) . ',' . str_replace(' ', '+', $_POST['country_name']). ',' . str_replace(' ', '+', $_POST['region']);
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://maps.googleapis.com/maps/api/geocode/json?address=$string&key=" . get_option('g_api'),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
    ));

    $response_geo = curl_exec($curl);

    curl_close($curl);
    $response_geo = json_decode($response_geo, true);

    $lat = $response_geo['results'][0]['geometry']['location']['lat'];
    $long = $response_geo['results'][0]['geometry']['location']['lng'];

    $msg = '';
   $in_term = 'M';
   
    $msg.='<div class="location_data desktop_view table">';
    $msg.='<div class="thead">
      <div class="tr">
        <div class="th select_all"><span class="not_checked">Select All</span></div>
        <div class="th">Company</div>
        <div class="th">Address</div>
        <div class="th">Status, <br/> cert type</div>
        <div class="th last_col"></div>
      </div>
    </div><div class="table_content">';
    
    
    foreach ($response['records'] as $recoreds) {
        
      $distance = distance($lat, $long, $recoreds['Latitude'], $recoreds['Longitude'], $in_term);
      if(!empty($_POST['city_town']) && !empty($_POST['State/Province']) && !empty($_POST['country_name']) && !empty($_POST['region'])){
          $query=($_POST['city_town']==$recoreds['City'] && $_POST['State/Province']==$recoreds['State'] && $_POST['country_name']==$recoreds['Country'] && $_POST['region']==$recoreds['Region']);
      }
      elseif(!empty($_POST['country_name']) && !empty($_POST['State/Province']) && !empty($_POST['city_town'])){
          $query=($_POST['country_name']==$recoreds['Country'] && $_POST['State/Province']==$recoreds['State'] && $_POST['city_town']==$recoreds['City']);
      }
       elseif(!empty($_POST['country_name']) && !empty($_POST['State/Province'])){
          $query=($_POST['country_name']==$recoreds['Country'] && $_POST['State/Province']==$recoreds['State']);
      }
      elseif(!empty($_POST['country_name']) && !empty($_POST['region'])){
          $query=($_POST['country_name']==$recoreds['Country'] && $_POST['region']==$recoreds['Region']);
      }
      elseif(!empty($_POST['country_name'])){
          $query=($_POST['country_name']==$recoreds['Country']);
      }
      elseif(!empty($_POST['region'])){
          $query=($_POST['region']==$recoreds['Region']);
      }
          if($query)
          { 
             if($recoreds['CertificationStatus']=='Active'){
            $placename = $recoreds['Name'];
            $placename = str_replace("'", '%27', $placename);
            $coords[] = array(
                'lat' => $recoreds['Latitude'],
                'lng' => $recoreds['Longitude'],
                'place' => $placename
            );
            $msg.='<div class="tr">
                            <div class="td checkbox_box"><input type="checkbox" name="filter_single_loc[]"><span class="checkmark"></span></div>
                            <div class="td">' . $recoreds['Name'] . '</div>
                            <div class="td">' . $recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
                            <div class="td">'.$recoreds['CertificationStatus'].'<br/>'. $recoreds['CertificationType'].'</div>
                            <div class="td last_col"><a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=13">More Info</a></div>
                          </div>';
          }
          }
    
    }
    if (empty($coords)) {
        $msg.='<h2>No records found.</h2>';
    }
    $msg.='</div></div>';


    $msg.='<div class="location_data mobile_view  table">';
    $msg.='<div class="thead">
      <div class="tr">
        <div class="th select_all"><span class="not_checked">Select All</span></div>
        <div class="th">Company Information</div>
      </div>
    </div><div class="table_content">';
    foreach ($response['records'] as $recoreds) {
        $distance = distance($lat, $long, $recoreds['Latitude'], $recoreds['Longitude'], $in_term);
        if(!empty($_POST['city_town']) && !empty($_POST['State/Province']) && !empty($_POST['country_name']) && !empty($_POST['region'])){
          $query=($_POST['city_town']==$recoreds['City'] && $_POST['State/Province']==$recoreds['State'] && $_POST['country_name']==$recoreds['Country'] && $_POST['region']==$recoreds['Region']);
      }
      elseif(!empty($_POST['country_name']) && !empty($_POST['State/Province']) && !empty($_POST['city_town'])){
          $query=($_POST['country_name']==$recoreds['Country'] && $_POST['State/Province']==$recoreds['State'] && $_POST['city_town']==$recoreds['City']);
      }
       elseif(!empty($_POST['country_name']) && !empty($_POST['State/Province'])){
          $query=($_POST['country_name']==$recoreds['Country'] && $_POST['State/Province']==$recoreds['State']);
      }
      elseif(!empty($_POST['country_name']) && !empty($_POST['region'])){
          $query=($_POST['country_name']==$recoreds['Country'] && $_POST['region']==$recoreds['Region']);
      }
       elseif(!empty($_POST['country_name'])){
          $query=($_POST['country_name']==$recoreds['Country']);
      }
      elseif(!empty($_POST['region'])){
          $query=($_POST['region']==$recoreds['Region']);
      }
          if($query)
          {
              if($recoreds['CertificationStatus']=='Active'){
      
            $msg.='<div class="tr">
                    <div class="td checkbox_box"><input type="checkbox" name="filter_single_loc[]"><span class="checkmark"></span></div>
                    <div class="td"><div class="c_name">' . $recoreds['Name'] . '</div><div class="address">' . $recoreds['Street'] . ', ' . $recoreds['Region'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'] . '</div>
                    <div class="status">Status: ' . $recoreds['CertificationType'] . '</div>
                    <div class="more_info"><a class="more_info_click" data-appid="' . $recoreds['AccountId'] . '" href="'.get_permalink().'?appids=' . $recoreds['AccountId'] . '&tab=13">More Info</a></div></div>
                  </div>';
              }
          }
    }
    if (empty($coords)) {
        $msg.='<h2>No records found.</h2>';
    }
    $msg.='</div></div>';
    echo $msg;
    my_js_variables($coords);
    exit;
}

// Filter by AREA End//

// Print page on listing start//
add_action('wp_ajax_print_from_list','print_from_list_callback');
add_action('wp_ajax_nopriv_print_from_list','print_from_list_callback');
function print_from_list_callback(){
    $data_ids = explode(',', $_POST['ac_ids']);
    $result = wp_cache_get('r2_facilities_curl');
    if (false === $result) {
        set_data_in_cache();
        $response = wp_cache_get('r2_facilities_curl');
    } else {
        $response = wp_cache_get('r2_facilities_curl');
    }
    $response = json_decode($response, true);
    $html='';
     $html.='<table>
  <thead>
    <tr>
      <th>Company</th>
      <th>Address</th>
      <th>Status cert type</th>
      <th>Distance</th>
    </tr>
  </thead>';
  $html.='<tbody>';
  
     
      foreach ($data_ids as $id) {

        foreach ($response['records'] as $recoreds) {
            if ($id == $recoreds['AccountId']) {
              
                $name = $recoreds['Name'];
                $address = $recoreds['Street'] . ', ' . $recoreds['City'] . ', ' . $recoreds['State'] . ', ' . $recoreds['Country'];
                $type = $recoreds['CertificationType'];
                $cert_status = $recoreds['CertificationStatus'];
                      $html.='<tr><td>'.$name.'</td><td>'.$address.'</td><td>'.$type.'</td></tr>';
                $i++;
                $j++;
            }
        }
    }
    $html.='</tbody>';
    $html.='</table>';
}
//print page on listing end //