<?php

/*
 * Description : Main file to manage function
 */


/*
 *  Menu management
 */

function facilities_menu_setup() {

    add_menu_page('R2 Certified Faculties', 'R2 Certified Faculties', 'manage_options', 'find_facilities', 'find_facilities_callback');

}

add_action('admin_menu', 'facilities_menu_setup');

add_action('wp_enqueue_scripts', 'load_custom_wp_front_style');

function load_custom_wp_front_style() {
  global $post;

  if ( (is_a( $post, 'WP_Post' ) && strpos($post->post_content, 'W2Rpc3BsYXlfYWxsX2ZhY2lsaXRpZXNd')) ||   (is_a( $post, 'WP_Post' ) && strpos($post->post_content, '[display_all_facilities]'))) 
  {
   $key=get_option('g_api');
  wp_enqueue_style('select2-css','https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.css', '', '', 'all');
  wp_enqueue_style('mCustomScrollbar-style', FIND_FACILITIES_PLUGIN_URL . '/css/jquery.mCustomScrollbar.css');
  wp_enqueue_style('bootstrap-min-css',FIND_FACILITIES_PLUGIN_URL. '/css/bootstrap.min.css');
	wp_enqueue_style('front-custom-style', FIND_FACILITIES_PLUGIN_URL . '/css/front_style.css?v=2', '', '', 'all');
  wp_enqueue_style('responsive-css', FIND_FACILITIES_PLUGIN_URL . '/css/front_responsive.css','', '', 'all');
	
	//wp_enqueue_script('min-js',"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js", array('jquery'), '', 'all');
  wp_enqueue_script('jquery-ui-min','https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js');
  wp_enqueue_script('bootstrap-min-js',FIND_FACILITIES_PLUGIN_URL . '/js/bootstrap.min.js',array('jquery'), '', 'all');
  wp_enqueue_script('map-api-js','https://maps.googleapis.com/maps/api/js?key='.$key.'&callback=myMap');
  wp_enqueue_script('select2','https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js', array('jquery'), '', 'all');
  wp_enqueue_script('mCustomScrollbar-js', FIND_FACILITIES_PLUGIN_URL . '/js/jquery.mCustomScrollbar.js', array('jquery'), '', 'all');
     wp_register_script('front-custom-js', FIND_FACILITIES_PLUGIN_URL . '/js/front-custom.js', array('jquery'), '', 'all');
     $localize = array(
       'ajax_url' => admin_url('admin-ajax.php'),
       'ajax_nonce' => wp_create_nonce('_check__ajax_100'),
       'home_url' => site_url()
   );
    wp_localize_script('front-custom-js', 'r2_config', $localize);
    wp_enqueue_script('front-custom-js');
  }
    
}
add_action('admin_enqueue_scripts', 'load_custom_wp_admin_style');

function load_custom_wp_admin_style() {
    wp_enqueue_style('admin-custom-style', FIND_FACILITIES_PLUGIN_URL . '/css/admin_style.css', '', '', 'all');
    wp_register_script('admin-custom-js', FIND_FACILITIES_PLUGIN_URL . '/js/admin-custom.js', array('jquery'), '', 'all');
      $localize = array(
       'ajax_url' => admin_url('admin-ajax.php'),
       'ajax_nonce' => wp_create_nonce('_check__ajax_100')
   );
    wp_localize_script('admin-custom-js', 'r2_config', $localize);
    wp_enqueue_script('admin-custom-js');
}
function find_facilities_callback() {
    include_once( plugin_dir_path(__FILE__) . '/admin/load-facilities.php' );
}


