<h1>FIND R2 CERTIFIED FACILITIES PAGE SETTINGS</h1>
<?php
$key=get_option('g_api');
?>
<form action="" class="booked-settings-form" method="post">
    <h2>Add Google Map API key</h2>
    <input type="text" name="api_key" value="<?php echo $key; ?>">
    <h2>Select cron job time: <label>(if not set it will be by default 2 hr)</label></h2>
    <select name="cron_job">
        <option value="">-Select-</option>
        <option value="1800" <?php if(get_option('cron_set',true)==1800){echo 'selected';}?>>30 Min</option>
        <option value="3600" <?php if(get_option('cron_set',true)==3600){echo 'selected';}?>>1 Hour</option>
        <option value="7200" <?php if(get_option('cron_set',true)==7200){echo 'selected';}?>>2 Hour</option>
    </select>
    <h2>Add Header Content.</h2>
<?php
$default_content=get_option('header_before_tabs');
$editor_id = 'header_before_tabs';
$option_name='header_before_tabs';
$default_content=html_entity_decode($default_content);
$default_content=stripslashes($default_content);
wp_editor( $default_content, $editor_id,array('textarea_name' => $option_name,'media_buttons' => true,'editor_height' => 350,'teeny' => true)  );
?>
<h2>Add Footer Content.</h2>
<?php
$default_content=get_option('footer_after_tabs');
$editor_id = 'footer_after_tabs';
$option_name='footer_after_tabs';
$default_content=html_entity_decode($default_content);
$default_content=stripslashes($default_content);
wp_editor( $default_content, $editor_id,array('textarea_name' => $option_name,'media_buttons' => true,'editor_height' => 350,'teeny' => true)  );


$default_content=get_option('print_header');
$editor_id = 'print_header';
$option_name='print_header';
$default_content=html_entity_decode($default_content);
$default_content=stripslashes($default_content);
wp_editor( $default_content, $editor_id,array('textarea_name' => $option_name,'media_buttons' => true,'editor_height' => 350,'teeny' => true)  );

submit_button( __( 'Save Settings', 'textdomain' ), 'primary', 'wpdocs-save-settings' );
?>
</form>
<?php

if(isset($_POST['wpdocs-save-settings']) && $_POST['wpdocs-save-settings']=='Save Settings' ){
        $getcron=get_option('cron_set');
         
        if($getcron!=$_POST['cron_job'] || empty($getcron)){
            wp_cache_flush();
            update_option('cron_set',$_POST['cron_job']);
            wp_cache_delete('r2_facilities_curl');
            set_data_in_cache();
        }
        
        $header_before_tabs=htmlentities(wpautop($_POST['header_before_tabs']));
        update_option('header_before_tabs', $header_before_tabs);
        
        $footer_after_tabs=htmlentities(wpautop($_POST['footer_after_tabs']));
        update_option('footer_after_tabs', $footer_after_tabs);
        
        $print_header=htmlentities(wpautop($_POST['print_header']));
         update_option('print_header', $print_header);
         
        update_option('g_api', $_POST['api_key']);
        
        $url = admin_url('admin.php').'?page=find_facilities';
        echo '<script>window.location.href="' . $url . '"</script>';
        exit;
}
